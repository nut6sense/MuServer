	PreCreateString_0		= GetSStringInfo(LAN_NSUCCEESS)

	PreCreateString_1		= GetSStringInfo(LAN_NFAILED)

	PreCreateString_2		= GetSStringInfo(LAN_NOT_DUPLICATE_CHECK)

	PreCreateString_3		= GetSStringInfo(LAN_DUPLICATE_MSG)

	PreCreateString_4		= GetSStringInfo(LAN_EMPTY_MESSAGE)

	PreCreateString_5		= GetSStringInfo(LAN_USE_ABLE)

	PreCreateString_6		= GetSStringInfo(LAN_CLUB_NOT_ACCEPT_CLUBUSER)

	PreCreateString_7		= GetSStringInfo(LAN_CLUB_NOT_ACCEPT_EMBLEM)

	PreCreateString_8		= GetSStringInfo(LAN_LOW_CHARACTER_LEVEL)

	PreCreateString_9		= GetSStringInfo(LAN_SHORT_MONEY)

	PreCreateString_10		= GetSStringInfo(LAN_CLUB_ALEADY_ACCEPT_CLUBUSER)

	PreCreateString_11		= GetSStringInfo(LAN_CLUB_NOT_EXIST)

	PreCreateString_12		= GetSStringInfo(LAN_CLUB_FULL_MEMBER)

	PreCreateString_13		= GetSStringInfo(LAN_OFFLINE_USER)

	PreCreateString_14		= GetSStringInfo(LAN_CLUB_ACCEPT_INVITE)

	PreCreateString_15		= GetSStringInfo(LAN_CLUB_REFUSE)

	PreCreateString_16		= GetSStringInfo(LAN_RANK_NOT_FINDNAME)

	PreCreateString_17		= GetSStringInfo(LAN_RANK_OUT_USER)

	PreCreateString_18		= GetSStringInfo(LAN_NOT_EMPTY_SEAT)

	PreCreateString_19		= GetSStringInfo(LAN_NOT_EXIST_ROOM)

	PreCreateString_20		= GetSStringInfo(LAN_DIFFERENT_PASSWORD)

	PreCreateString_21		= GetSStringInfo(LAN_NEED_PASSWORD)

	PreCreateString_22		= GetSStringInfo(LAN_ACADE_ROOM)

	PreCreateString_23		= GetSStringInfo(LAN_CONNECTED_ROOM)

	PreCreateString_24		= GetSStringInfo(LAN_REFUSE_INVITE)

	PreCreateString_25		= GetSStringInfo(LAN_NOT_SUPPORT_GAMEMODE)

	PreCreateString_26		= GetSStringInfo(LAN_NOT_EXIST_CHARACTERSLOT)

	PreCreateString_27		= GetSStringInfo(LAN_NOT_EXIST_CHARACTER)

	PreCreateString_28		= GetSStringInfo(LAN_DUPLICATE_SETTLEUP)

	PreCreateString_29		= GetSStringInfo(LAN_FULL_TOTALBUY)

	PreCreateString_30		= GetSStringInfo(LAN_FULL_PRODUCTBUY)

	PreCreateString_31		= GetSStringInfo(LAN_PERVADE_REBUY)

	PreCreateString_32		= GetSStringInfo(LAN_NOT_EVENTITEM)

	PreCreateString_33		= GetSStringInfo(LAN_LOTTO)

	PreCreateString_34		= GetSStringInfo(LAN_NOT_CART)

	PreCreateString_35		= GetSStringInfo(LAN_LIMIT_USEGAME)

	PreCreateString_36		= GetSStringInfo(LAN_LIMIT_TOTALSALENUM)

	PreCreateString_37		= GetSStringInfo(LAN_LIMIT_ORDERNUM)

	PreCreateString_38		= GetSStringInfo(LAN_NOT_REORDER)

	PreCreateString_39		= GetSStringInfo(LAN_ALREADY_USE_COOPON)

	PreCreateString_40		= GetSStringInfo(LAN_TERMINATE_PERIOD)

	PreCreateString_41		= GetSStringInfo(LAN_NOTUSE_COOPON)

	PreCreateString_42		= GetSStringInfo(LAN_NOT_HARMONYGAME)

	PreCreateString_43		= GetSStringInfo(LAN_ERROR_NISMS_COOPON)

	PreCreateString_44		= GetSStringInfo(LAN_CHECK_ERROR_USE_COOPON)

	PreCreateString_45		= GetSStringInfo(LAN_INSERT_ERROR_USE_COOPON)

	PreCreateString_46		= GetSStringInfo(LAN_ERROR_ETC)

	PreCreateString_47		= GetSStringInfo(LAN_MAINTENANCE)

	PreCreateString_48		= GetSStringInfo(LAN_NOT_AVAILABLE_PCCOOPON)

	PreCreateString_49		= GetSStringInfo(LAN_NOT_USE_PCCOOPON)

	PreCreateString_50		= GetSStringInfo(LAN_NOT_TERMINATE_PCCOOPON)

	PreCreateString_51		= GetSStringInfo(LAN_NOT_CANCEL_PCCOOPON)

	PreCreateString_52		= GetSStringInfo(LAN_NOT_PRESENTITEM)

	PreCreateString_53		= GetSStringInfo(LAN_NOT_WAITROOM)

	PreCreateString_54		= GetSStringInfo(LAN_NOT_READYUSER)

	PreCreateString_55		= GetSStringInfo(LAN_SHORT_USER)

	PreCreateString_56		= GetSStringInfo(LAN_NOT_TEAMUSERNUM)

	PreCreateString_57		= GetSStringInfo(LAN_NOT_LOADING)

	PreCreateString_58		= GetSStringInfo(LAN_SHORT_INDEX)

	PreCreateString_59		= GetSStringInfo(LAN_BIG_INDEX)

	PreCreateString_60		= GetSStringInfo(LAN_NOT_LEAVED_CHARACTER)

	PreCreateString_61		= GetSStringInfo(LAN_ALREADY_OUTUSER)

	PreCreateString_62		= GetSStringInfo(LAN_NOT_LEAVE_CAPTAIN)

	PreCreateString_63		= GetSStringInfo(LAN_NOT_EXIST_CAPTAIN)

	PreCreateString_64		= GetSStringInfo(LAN_AVAILABLE_LEAVE_CAPTAIN)

	PreCreateString_65		= GetSStringInfo(LAN_NOT_OUT)

	PreCreateString_66		= GetSStringInfo(LAN_NOT_TEAMMODE)

	PreCreateString_67		= GetSStringInfo(LAN_NOT_MOVETEAM)

	PreCreateString_68		= GetSStringInfo(LAN_AFTER_CHANGE_TEAM)

	PreCreateString_69		= GetSStringInfo(LAN_LOGIN_TIMEOUT)

	PreCreateString_70		= GetSStringInfo(LAN_AVAILABLE_MORE_12AGE)

	PreCreateString_71		= GetSStringInfo(LAN_FAILED_NEXONLOGIN)

	PreCreateString_72		= GetSStringInfo(LAN_LONG_IDSTRING)

	PreCreateString_73		= GetSStringInfo(LAN_SHORT_IDSTRING)

	PreCreateString_74		= GetSStringInfo(LAN_FAILED_ACCEPTUSER)

	PreCreateString_75		= GetSStringInfo(LAN_STAY_OHTERSERVER_USER)

	PreCreateString_76		= GetSStringInfo(LAN_FAIELD_LOADINGCHARACTER)

	PreCreateString_77		= GetSStringInfo(LAN_SUCCESS_CONNECT)

	PreCreateString_78		= GetSStringInfo(LAN_SHORT_CHARACNAME)

	PreCreateString_79		= GetSStringInfo(LAN_SELECT_CHARACTER)

	PreCreateString_80		= GetSStringInfo(LAN_MORE_CHANNEL_MAXUSER)

	PreCreateString_81		= GetSStringInfo(LAN_ENTER_CHANNEL)

	PreCreateString_82		= GetSStringInfo(LAN_ALREADY_ENTER_CHANNEL)

	PreCreateString_83		= GetSStringInfo(LAN_NOT_ROOMTO_CHANNEL)

	PreCreateString_84		= GetSStringInfo(LAN_NOT_CHATTING)

	PreCreateString_85		= GetSStringInfo(LAN_NOT_PAPER_CHATTING)

	PreCreateString_86		= GetSStringInfo(LAN_BLANK_NAME)

	PreCreateString_87		= GetSStringInfo(LAN_LONG_CHARACNAME)

	PreCreateString_88		= GetSStringInfo(LAN_NOT_CREATE_CHARACTER)

	PreCreateString_89		= GetSStringInfo(LAN_ALREADY_SELECTEDCHARACTER)

	PreCreateString_90		= GetSStringInfo(LAN_SUCCESS_CREATECHARACTER)

	PreCreateString_91		= GetSStringInfo(LAN_FAIELD_DELETE_CHARACTER)

	PreCreateString_92		= GetSStringInfo(LAN_NOT_BUYITEM_ROOM)

	PreCreateString_93		= GetSStringInfo(LAN_NOT_FINDITEM)

	PreCreateString_94		= GetSStringInfo(LAN_SELECT_ITEM)

	PreCreateString_95		= GetSStringInfo(LAN_SHORT_CASH)

	PreCreateString_96		= GetSStringInfo(LAN_SHORT_GRANG)

	PreCreateString_97		= GetSStringInfo(LAN_NOT_DESTROY_BASEITEM)

	PreCreateString_98		= GetSStringInfo(LAN_ALREADY_WEAR)

	PreCreateString_99		= GetSStringInfo(LAN_ALREADY_DESTROY_ITEM)

	PreCreateString_100		= GetSStringInfo(LAN_ONLY_ROOMMSG)

	PreCreateString_101		= GetSStringInfo(LAN_NOT_BUYITEM)

	PreCreateString_102		= GetSStringInfo(LAN_SHORT_COIN)

	PreCreateString_103		= GetSStringInfo(LAN_LOW_CHARACLEVEL)

	PreCreateString_104		= GetSStringInfo(LAN_ALREADY_CHANGE_WORK)

	PreCreateString_105		= GetSStringInfo(LAN_NOT_CHANGE_WORK_TYPE)

	PreCreateString_106		= GetSStringInfo(LAN_NOT_CHANGE_WORKITEM)

	PreCreateString_107		= GetSStringInfo(LAN_ALREADY_CONTRACT_PARTY)

	PreCreateString_108		= GetSStringInfo(LAN_NOT_EXIST_PARTY)

	PreCreateString_109		= GetSStringInfo(LAN_FULL_PARTY)

	PreCreateString_110		= GetSStringInfo(LAN_NOT_CONTRACT_PARTY)

	PreCreateString_111		= GetSStringInfo(LAN_OTHERUSER)

	PreCreateString_112		= GetSStringInfo(LAN_NOT_FIND_CHARACTER)

	PreCreateString_113		= GetSStringInfo(LAN_OBEY_WHISPER)

	PreCreateString_114		= GetSStringInfo(LAN_NOT_PARTY_CAPTAIN)

	PreCreateString_115		= GetSStringInfo(LAN_NOT_INCLUDE_PARTYUSER)

	PreCreateString_116		= GetSStringInfo(LAN_NOT_BAN_PARTY_CAPTAIN)

	PreCreateString_200		= GetSStringInfo(LAN_GRAN)

	PreCreateString_1001		= GetSStringInfo(LAN_FONT_HY_HEADLINE)

	PreCreateString_1002		= GetSStringInfo(LAN_FONT_GODIC)

	PreCreateString_1003		= GetSStringInfo(LAN_FONT_GULIMCHE)

	PreCreateString_1004		= GetSStringInfo(LAN_FONT_GULIM)

	PreCreateString_1005		= GetSStringInfo(LAN_FONT_DODUM)

	PreCreateString_1006		= GetSStringInfo(LAN_FONT_DODUMCHE)

	PreCreateString_1007		= GetSStringInfo(LAN_LUA_ARCADESHOP_1)

	PreCreateString_1008		= GetSStringInfo(LAN_LUA_ARCADESHOP_2)

	PreCreateString_1009		= GetSStringInfo(LAN_LUA_ARCADESHOP_3)

	PreCreateString_1010		= GetSStringInfo(LAN_LUA_ARCADESHOP_4)

	PreCreateString_1011		= GetSStringInfo(LAN_LUA_ARCADESHOP_5)

	PreCreateString_1012		= GetSStringInfo(LAN_LUA_ARCADESHOP_6)

	PreCreateString_1013		= GetSStringInfo(LAN_LUA_ARCADESHOP_7)

	PreCreateString_1014		= GetSStringInfo(LAN_LUA_ARCADESHOP_8)

	PreCreateString_1015		= GetSStringInfo(LAN_LUA_ARCADESHOP_9)

	PreCreateString_1016		= GetSStringInfo(LAN_LUA_BTNPAGEMOVE_1)

	PreCreateString_1017		= GetSStringInfo(LAN_LUA_BTNPAGEMOVE_2)

	PreCreateString_1018		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_1)

	PreCreateString_1019		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_2)

	PreCreateString_1020		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_3)

	PreCreateString_1021		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_4)

	PreCreateString_1022		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_5)

	PreCreateString_1023		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_6)

	PreCreateString_1024		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_7)

	PreCreateString_1025		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_8)

	PreCreateString_1026		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_9)

	PreCreateString_1027		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_10)

	PreCreateString_1028		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_11)

	PreCreateString_1029		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_12)

	PreCreateString_1030		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_13)

	PreCreateString_1031		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_14)

	PreCreateString_1032		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_15)

	PreCreateString_1033		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_16)

	PreCreateString_1034		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_17)

	PreCreateString_1035		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_18)

	PreCreateString_1036		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_19)

	PreCreateString_1037		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_20)

	PreCreateString_1038		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_21)

	PreCreateString_1039		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_22)

	PreCreateString_1040		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_23)

	PreCreateString_1041		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_24)

	PreCreateString_1042		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_25)

	PreCreateString_1043		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_26)

	PreCreateString_1044		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_27)

	PreCreateString_1045		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_28)

	PreCreateString_1046		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_29)

	PreCreateString_1047		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_30)

	PreCreateString_1048		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_31)

	PreCreateString_1049		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_32)

	PreCreateString_1050		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_33)

	PreCreateString_1051		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_34)

	PreCreateString_1052		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_35)

	PreCreateString_1053		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_36)

	PreCreateString_1054		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_37)

	PreCreateString_1055		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_38)

	PreCreateString_1056		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_39)

	PreCreateString_1057		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_40)

	PreCreateString_1058		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_1)

	PreCreateString_1059		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_2)

	PreCreateString_1060		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_3)

	PreCreateString_1061		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_4)

	PreCreateString_1062		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_5)

	PreCreateString_1063		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_6)

	PreCreateString_1064		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_7)

	PreCreateString_1065		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_8)

	PreCreateString_1066		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_9)

	PreCreateString_1067		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_10)

	PreCreateString_1068		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_11)

	PreCreateString_1069		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_12)

	PreCreateString_1070		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_13)

	PreCreateString_1071		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_14)

	PreCreateString_1072		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_15)

	PreCreateString_1073		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_16)

	PreCreateString_1074		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_17)

	PreCreateString_1075		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_18)

	PreCreateString_1076		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_19)

	PreCreateString_1077		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_20)

	PreCreateString_1078		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_DESIGNER_21)

	PreCreateString_1079		= GetSStringInfo(LAN_LUA_CHANGEJOB_1)

	PreCreateString_1080		= GetSStringInfo(LAN_LUA_CHANGEJOB_2)

	PreCreateString_1081		= GetSStringInfo(LAN_LUA_CHANGEJOB_3)

	PreCreateString_1082		= GetSStringInfo(LAN_LUA_CHANGEJOB_4)

	PreCreateString_1083		= GetSStringInfo(LAN_LUA_CHANGEJOB_5)

	PreCreateString_1084		= GetSStringInfo(LAN_LUA_CHANGEJOB_6)

	PreCreateString_1085		= GetSStringInfo(LAN_LUA_CHANGEJOB_7)

	PreCreateString_1086		= GetSStringInfo(LAN_LUA_CHANGEJOB_8)

	PreCreateString_1087		= GetSStringInfo(LAN_LUA_CHANGEJOB_9)

	PreCreateString_1088		= GetSStringInfo(LAN_LUA_COMMON_1)

	PreCreateString_1089		= GetSStringInfo(LAN_LUA_COMMON_AB_1)

	PreCreateString_1090		= GetSStringInfo(LAN_LUA_COMMON_AB_2)

	PreCreateString_1091		= GetSStringInfo(LAN_LUA_COMMON_AB_3)

	PreCreateString_1092		= GetSStringInfo(LAN_LUA_COMMON_AB_4)

	PreCreateString_1093		= GetSStringInfo(LAN_LUA_DLG_INVITE_1)

	PreCreateString_1094		= GetSStringInfo(LAN_LUA_DLG_INVITE_2)

	PreCreateString_1095		= GetSStringInfo(LAN_LUA_DLG_INVITE_3)

	PreCreateString_1096		= GetSStringInfo(LAN_LUA_FIGHT_CLUB_1)

	PreCreateString_1097		= GetSStringInfo(LAN_LUA_NOTIFY_MB_1)

	PreCreateString_1098		= GetSStringInfo(LAN_LUA_NOTIFY_MB_2)

	PreCreateString_1099		= GetSStringInfo(LAN_LUA_NOTIFY_MB_3)

	PreCreateString_1100		= GetSStringInfo(LAN_LUA_PARTY_MATCH_1)

	PreCreateString_1101		= GetSStringInfo(LAN_LUA_PARTY_MATCH_2)

	PreCreateString_1102		= GetSStringInfo(LAN_LUA_PARTY_MATCH_3)

	PreCreateString_1103		= GetSStringInfo(LAN_LUA_PARTY_MATCH_4)

	PreCreateString_1104		= GetSStringInfo(LAN_LUA_PARTY_MATCH_5)

	PreCreateString_1105		= GetSStringInfo(LAN_LUA_PARTY_MATCH_6)

	PreCreateString_1106		= GetSStringInfo(LAN_LUA_PARTY_MATCH_7)

	PreCreateString_1107		= GetSStringInfo(LAN_LUA_PARTY_MATCH_8)

	PreCreateString_1108		= GetSStringInfo(LAN_LUA_PARTY_MATCH_9)

	PreCreateString_1109		= GetSStringInfo(LAN_LUA_PARTY_MATCH_10)

	PreCreateString_1110		= GetSStringInfo(LAN_LUA_PARTY_MATCH_11)

	PreCreateString_1111		= GetSStringInfo(LAN_LUA_PARTY_MATCH_12)

	PreCreateString_1112		= GetSStringInfo(LAN_LUA_PARTY_MATCH_13)

	PreCreateString_1113		= GetSStringInfo(LAN_LUA_PARTY_MATCH_14)

	PreCreateString_1114		= GetSStringInfo(LAN_LUA_PARTY_MATCH_15)

	PreCreateString_1115		= GetSStringInfo(LAN_LUA_PARTY_MATCH_16)

	PreCreateString_1116		= GetSStringInfo(LAN_LUA_PARTY_MATCH_17)

	PreCreateString_1117		= GetSStringInfo(LAN_LUA_PARTY_MATCH_18)

	PreCreateString_1118		= GetSStringInfo(LAN_LUA_PARTY_MATCH_19)

	PreCreateString_1119		= GetSStringInfo(LAN_LUA_PARTY_MANAGER_1)

	PreCreateString_1120		= GetSStringInfo(LAN_LUA_SHOP_COMMON_1)

	PreCreateString_1121		= GetSStringInfo(LAN_LUA_SHOP_COMMON_2)

	PreCreateString_1122		= GetSStringInfo(LAN_LUA_SHOP_COMMON_3)

	PreCreateString_1123		= GetSStringInfo(LAN_LUA_SHOP_COMMON_4)

	PreCreateString_1124		= GetSStringInfo(LAN_LUA_SHOP_COMMON_5)

	PreCreateString_1125		= GetSStringInfo(LAN_LUA_SHOP_COMMON_6)

	PreCreateString_1126		= GetSStringInfo(LAN_LUA_SHOP_COMMON_7)

	PreCreateString_1127		= GetSStringInfo(LAN_LUA_SHOP_COMMON_8)

	PreCreateString_1128		= GetSStringInfo(LAN_LUA_WND_BATTLEROOM_1)

	PreCreateString_1129		= GetSStringInfo(LAN_LUA_WND_BATTLEROOM_2)

	PreCreateString_1130		= GetSStringInfo(LAN_LUA_WND_BATTLEROOM_3)

	PreCreateString_1131		= GetSStringInfo(LAN_LUA_WND_BATTLEROOM_4)

	PreCreateString_1132		= GetSStringInfo(LAN_LUA_WND_BATTLEROOM_5)

	PreCreateString_1133		= GetSStringInfo(LAN_LUA_WND_BATTLEROOM_6)

	PreCreateString_1134		= GetSStringInfo(LAN_LUA_WND_BR_INVITE_1)

	PreCreateString_1135		= GetSStringInfo(LAN_LUA_WND_BR_INVITE_2)

	PreCreateString_1136		= GetSStringInfo(LAN_LUA_WND_BR_INVITE_3)

	PreCreateString_1137		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_1)

	PreCreateString_1138		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_2)

	PreCreateString_1139		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_3)

	PreCreateString_1140		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_4)

	PreCreateString_1141		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_5)

	PreCreateString_1142		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_6)

	PreCreateString_1143		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_7)

	PreCreateString_1144		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_8)

	PreCreateString_1145		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_9)

	PreCreateString_1146		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_10)

	PreCreateString_1147		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_11)

	PreCreateString_1148		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_12)

	PreCreateString_1149		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_13)

	PreCreateString_1150		= GetSStringInfo(LAN_LUA_WND_COMMON_SHOP_14)

	PreCreateString_1151		= GetSStringInfo(LAN_LUA_WND_GAME_1)

	PreCreateString_1152		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_1)

	PreCreateString_1153		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_2)

	PreCreateString_1154		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_3)

	PreCreateString_1155		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_4)

	PreCreateString_1156		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_5)

	PreCreateString_1157		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_6)

	PreCreateString_1158		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_7)

	PreCreateString_1159		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_8)

	PreCreateString_1160		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_9)

	PreCreateString_1161		= GetSStringInfo(LAN_LUA_WND_LOBBY_1)

	PreCreateString_1162		= GetSStringInfo(LAN_LUA_WND_LOBBY_2)

	PreCreateString_1163		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_1)

	PreCreateString_1164		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_2)

	PreCreateString_1165		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_3)

	PreCreateString_1166		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_4)

	PreCreateString_1167		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_5)

	PreCreateString_1168		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_6)

	PreCreateString_1169		= GetSStringInfo(LAN_LUA_WND_MESSENGER_1)

	PreCreateString_1170		= GetSStringInfo(LAN_LUA_WND_MESSENGER_2)

	PreCreateString_1171		= GetSStringInfo(LAN_LUA_WND_MESSENGER_3)

	PreCreateString_1172		= GetSStringInfo(LAN_LUA_WND_MESSENGER_4)

	PreCreateString_1173		= GetSStringInfo(LAN_LUA_WND_MESSENGER_5)

	PreCreateString_1174		= GetSStringInfo(LAN_LUA_WND_MESSENGER_6)

	PreCreateString_1175		= GetSStringInfo(LAN_LUA_WND_MESSENGER_7)

	PreCreateString_1176		= GetSStringInfo(LAN_LUA_WND_MESSENGER_8)

	PreCreateString_1177		= GetSStringInfo(LAN_LUA_WND_MESSENGER_9)

	PreCreateString_1178		= GetSStringInfo(LAN_LUA_WND_MESSENGER_10)

	PreCreateString_1179		= GetSStringInfo(LAN_LUA_WND_MESSENGER_11)

	PreCreateString_1180		= GetSStringInfo(LAN_LUA_WND_MESSENGER_12)

	PreCreateString_1181		= GetSStringInfo(LAN_LUA_WND_MESSENGER_13)

	PreCreateString_1182		= GetSStringInfo(LAN_LUA_WND_MESSENGER_14)

	PreCreateString_1183		= GetSStringInfo(LAN_LUA_WND_MESSENGER_15)

	PreCreateString_1184		= GetSStringInfo(LAN_LUA_WND_MESSENGER_16)

	PreCreateString_1185		= GetSStringInfo(LAN_LUA_WND_MESSENGER_17)

	PreCreateString_1186		= GetSStringInfo(LAN_LUA_WND_MESSENGER_18)

	PreCreateString_1187		= GetSStringInfo(LAN_LUA_WND_MESSENGER_19)

	PreCreateString_1188		= GetSStringInfo(LAN_LUA_WND_MESSENGER_20)

	PreCreateString_1189		= GetSStringInfo(LAN_LUA_WND_MESSENGER_21)

	PreCreateString_1190		= GetSStringInfo(LAN_LUA_WND_MESSENGER_22)

	PreCreateString_1191		= GetSStringInfo(LAN_LUA_WND_MESSENGER_23)

	PreCreateString_1192		= GetSStringInfo(LAN_LUA_WND_MESSENGER_24)

	PreCreateString_1193		= GetSStringInfo(LAN_LUA_WND_MYINFO_1)

	PreCreateString_1194		= GetSStringInfo(LAN_LUA_WND_MYINFO_2)

	PreCreateString_1195		= GetSStringInfo(LAN_LUA_WND_MYINFO_3)

	PreCreateString_1196		= GetSStringInfo(LAN_LUA_WND_MYINFO_4)

	PreCreateString_1197		= GetSStringInfo(LAN_LUA_WND_MYINFO_5)

	PreCreateString_1198		= GetSStringInfo(LAN_LUA_WND_MYINFO_6)

	PreCreateString_1199		= GetSStringInfo(LAN_LUA_WND_MYINFO_7)

	PreCreateString_1200		= GetSStringInfo(LAN_LUA_WND_MYINFO_8)

	PreCreateString_1201		= GetSStringInfo(LAN_LUA_WND_MYINFO_9)

	PreCreateString_1202		= GetSStringInfo(LAN_LUA_WND_MYINFO_10)

	PreCreateString_1203		= GetSStringInfo(LAN_LUA_WND_MYINFO_11)

	PreCreateString_1204		= GetSStringInfo(LAN_LUA_WND_MYINFO_12)

	PreCreateString_1205		= GetSStringInfo(LAN_LUA_WND_MYINFO_13)

	PreCreateString_1206		= GetSStringInfo(LAN_LUA_WND_MYINFO_14)

	PreCreateString_1207		= GetSStringInfo(LAN_LUA_WND_MYINFO_15)

	PreCreateString_1208		= GetSStringInfo(LAN_LUA_WND_MYINFO_16)

	PreCreateString_1209		= GetSStringInfo(LAN_LUA_WND_MYINFO_17)

	PreCreateString_1210		= GetSStringInfo(LAN_LUA_WND_MYINFO_18)

	PreCreateString_1211		= GetSStringInfo(LAN_LUA_WND_MYINFO_19)

	PreCreateString_1212		= GetSStringInfo(LAN_LUA_WND_MYINFO_20)

	PreCreateString_1213		= GetSStringInfo(LAN_LUA_WND_MYINFO_21)

	PreCreateString_1214		= GetSStringInfo(LAN_LUA_WND_MYINFO_22)

	PreCreateString_1215		= GetSStringInfo(LAN_LUA_WND_MYINFO_23)

	PreCreateString_1216		= GetSStringInfo(LAN_LUA_WND_MYINFO_24)

	PreCreateString_1217		= GetSStringInfo(LAN_LUA_WND_MYINFO_25)

	PreCreateString_1218		= GetSStringInfo(LAN_LUA_WND_MYINFO_26)

	PreCreateString_1219		= GetSStringInfo(LAN_LUA_WND_MYINFO_27)

	PreCreateString_1220		= GetSStringInfo(LAN_LUA_WND_MYINFO_28)

	PreCreateString_1221		= GetSStringInfo(LAN_LUA_WND_MYINFO_29)

	PreCreateString_1222		= GetSStringInfo(LAN_LUA_WND_MYINFO_30)

	PreCreateString_1223		= GetSStringInfo(LAN_LUA_WND_MYINFO_31)

	PreCreateString_1224		= GetSStringInfo(LAN_LUA_WND_MYINFO_32)

	PreCreateString_1225		= GetSStringInfo(LAN_LUA_WND_MYINFO_33)

	PreCreateString_1226		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_1)

	PreCreateString_1227		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_2)

	PreCreateString_1228		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_3)

	PreCreateString_1229		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_4)

	PreCreateString_1230		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_1)

	PreCreateString_1231		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_2)

	PreCreateString_1232		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_3)

	PreCreateString_1233		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_4)

	PreCreateString_1234		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_5)

	PreCreateString_1235		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_6)

	PreCreateString_1236		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_7)

	PreCreateString_1237		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_8)

	PreCreateString_1238		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_9)

	PreCreateString_1239		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_10)

	PreCreateString_1240		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_11)

	PreCreateString_1241		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_12)

	PreCreateString_1242		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_13)

	PreCreateString_1243		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_14)

	PreCreateString_1244		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_15)

	PreCreateString_1245		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_16)

	PreCreateString_1246		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_17)

	PreCreateString_1247		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_18)

	PreCreateString_1248		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_19)

	PreCreateString_1249		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_20)

	PreCreateString_1250		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_21)

	PreCreateString_1251		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_22)

	PreCreateString_1252		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_23)

	PreCreateString_1253		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_24)

	PreCreateString_1254		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_25)

	PreCreateString_1255		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_26)

	PreCreateString_1256		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_27)

	PreCreateString_1257		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_28)

	PreCreateString_1258		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_29)

	PreCreateString_1259		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_30)

	PreCreateString_1260		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_31)

	PreCreateString_1261		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_32)

	PreCreateString_1262		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_33)

	PreCreateString_1263		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_34)

	PreCreateString_1264		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_35)

	PreCreateString_1265		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_36)

	PreCreateString_1266		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_37)

	PreCreateString_1267		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_38)

	PreCreateString_1268		= GetSStringInfo(LAN_LUA_WND_OPTION_1)

	PreCreateString_1269		= GetSStringInfo(LAN_LUA_WND_OPTION_2)

	PreCreateString_1270		= GetSStringInfo(LAN_LUA_WND_OPTION_3)

	PreCreateString_1271		= GetSStringInfo(LAN_LUA_WND_OPTION_4)

	PreCreateString_1272		= GetSStringInfo(LAN_LUA_WND_POPUP_1)

	PreCreateString_1273		= GetSStringInfo(LAN_LUA_WND_POPUP_2)

	PreCreateString_1274		= GetSStringInfo(LAN_LUA_WND_PRACTICE_1)

	PreCreateString_1275		= GetSStringInfo(LAN_LUA_WND_PRACTICE_2)

	PreCreateString_1276		= GetSStringInfo(LAN_LUA_WND_PRACTICE_3)

	PreCreateString_1277		= GetSStringInfo(LAN_LUA_WND_PRACTICE_4)

	PreCreateString_1278		= GetSStringInfo(LAN_LUA_WND_PRACTICE_5)

	PreCreateString_1279		= GetSStringInfo(LAN_LUA_WND_PRACTICE_6)

	PreCreateString_1280		= GetSStringInfo(LAN_LUA_WND_PRACTICE_7)

	PreCreateString_1281		= GetSStringInfo(LAN_LUA_WND_PRACTICE_8)

	PreCreateString_1282		= GetSStringInfo(LAN_LUA_WND_PRACTICE_9)

	PreCreateString_1283		= GetSStringInfo(LAN_LUA_WND_PRACTICE_10)

	PreCreateString_1284		= GetSStringInfo(LAN_LUA_WND_PRACTICE_11)

	PreCreateString_1285		= GetSStringInfo(LAN_LUA_WND_PRACTICE_12)

	PreCreateString_1286		= GetSStringInfo(LAN_LUA_WND_PRACTICE_13)

	PreCreateString_1287		= GetSStringInfo(LAN_LUA_WND_PRACTICE_14)

	PreCreateString_1288		= GetSStringInfo(LAN_LUA_WND_PRACTICE_15)

	PreCreateString_1289		= GetSStringInfo(LAN_LUA_WND_PRACTICE_16)

	PreCreateString_1290		= GetSStringInfo(LAN_LUA_WND_PRACTICE_17)

	PreCreateString_1291		= GetSStringInfo(LAN_LUA_WND_PRACTICE_18)

	PreCreateString_1292		= GetSStringInfo(LAN_LUA_WND_PRACTICE_19)

	PreCreateString_1293		= GetSStringInfo(LAN_LUA_WND_PRACTICE_20)

	PreCreateString_1294		= GetSStringInfo(LAN_LUA_WND_PRACTICE_21)

	PreCreateString_1295		= GetSStringInfo(LAN_LUA_WND_PRACTICE_22)

	PreCreateString_1296		= GetSStringInfo(LAN_LUA_WND_PRACTICE_23)

	PreCreateString_1297		= GetSStringInfo(LAN_LUA_WND_PRACTICE_24)

	PreCreateString_1298		= GetSStringInfo(LAN_LUA_WND_PRACTICE_25)

	PreCreateString_1299		= GetSStringInfo(LAN_LUA_WND_PRACTICE_26)

	PreCreateString_1300		= GetSStringInfo(LAN_LUA_WND_PRACTICE_27)

	PreCreateString_1301		= GetSStringInfo(LAN_LUA_WND_PRACTICE_28)

	PreCreateString_1302		= GetSStringInfo(LAN_LUA_WND_PRACTICE_29)

	PreCreateString_1303		= GetSStringInfo(LAN_LUA_WND_PRACTICE_30)

	PreCreateString_1304		= GetSStringInfo(LAN_LUA_WND_PRACTICE_31)

	PreCreateString_1305		= GetSStringInfo(LAN_LUA_WND_PRACTICE_32)

	PreCreateString_1306		= GetSStringInfo(LAN_LUA_WND_PRACTICE_33)

	PreCreateString_1307		= GetSStringInfo(LAN_LUA_WND_PRACTICE_34)

	PreCreateString_1308		= GetSStringInfo(LAN_LUA_WND_PRACTICE_35)

	PreCreateString_1309		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_1)

	PreCreateString_1310		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_2)

	PreCreateString_1311		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_3)

	PreCreateString_1312		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_4)

	PreCreateString_1313		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_5)

	PreCreateString_1314		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_6)

	PreCreateString_1315		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_7)

	PreCreateString_1316		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_8)

	PreCreateString_1317		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_9)

	PreCreateString_1318		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_10)

	PreCreateString_1319		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_11)

	PreCreateString_1320		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_12)

	PreCreateString_1321		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_13)

	PreCreateString_1322		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_14)

	PreCreateString_1323		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_15)

	PreCreateString_1324		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_16)

	PreCreateString_1325		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_17)

	PreCreateString_1326		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_18)

	PreCreateString_1327		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_19)

	PreCreateString_1328		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_20)

	PreCreateString_1329		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_21)

	PreCreateString_1330		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_22)

	PreCreateString_1331		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_23)

	PreCreateString_1332		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_24)

	PreCreateString_1333		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_25)

	PreCreateString_1334		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_26)

	PreCreateString_1335		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_27)

	PreCreateString_1336		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_28)

	PreCreateString_1337		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_29)

	PreCreateString_1338		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_30)

	PreCreateString_1339		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_31)

	PreCreateString_1340		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_32)

	PreCreateString_1341		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_33)

	PreCreateString_1342		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_34)

	PreCreateString_1343		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_35)

	PreCreateString_1344		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_36)

	PreCreateString_1345		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_37)

	PreCreateString_1346		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_38)

	PreCreateString_1347		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_39)

	PreCreateString_1348		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_40)

	PreCreateString_1349		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_41)

	PreCreateString_1350		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_42)

	PreCreateString_1351		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_43)

	PreCreateString_1352		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_44)

	PreCreateString_1353		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_45)

	PreCreateString_1354		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_46)

	PreCreateString_1355		= GetSStringInfo(LAN_LUA_WND_QUEST_RESULT_1)

	PreCreateString_1356		= GetSStringInfo(LAN_LUA_WND_QUEST_RESULT_2)

	PreCreateString_1357		= GetSStringInfo(LAN_LUA_WND_QUEST_RESULT_3)

	PreCreateString_1358		= GetSStringInfo(LAN_LUA_WND_QUEST_RESULT_4)

	PreCreateString_1359		= GetSStringInfo(LAN_LUA_WND_QUEST_RESULT_5)

	PreCreateString_1360		= GetSStringInfo(LAN_LUA_WND_QUEST_RESULT_6)

	PreCreateString_1361		= GetSStringInfo(LAN_LUA_WND_QUEST_RESULT_7)

	PreCreateString_1362		= GetSStringInfo(LAN_LUA_WND_QUEST_ROOM_1)

	PreCreateString_1363		= GetSStringInfo(LAN_LUA_WND_QUEST_ROOM_2)

	PreCreateString_1364		= GetSStringInfo(LAN_LUA_WND_QUEST_ROOM_3)

	PreCreateString_1365		= GetSStringInfo(LAN_LUA_WND_QUEST_ROOM_4)

	PreCreateString_1366		= GetSStringInfo(LAN_LUA_WND_SKILL_SHOP_1)

	PreCreateString_1367		= GetSStringInfo(LAN_LUA_WND_SKILL_SHOP_2)

	PreCreateString_1368		= GetSStringInfo(LAN_LUA_WND_SKILL_SHOP_3)

	PreCreateString_1369		= GetSStringInfo(LAN_LUA_WND_VILLAGE_1)

	PreCreateString_1370		= GetSStringInfo(LAN_LUA_WND_VILLAGE_2)

	PreCreateString_1371		= GetSStringInfo(LAN_LUA_WND_VILLAGE_3)

	PreCreateString_1372		= GetSStringInfo(LAN_LUA_WND_VILLAGE_4)

	PreCreateString_1373		= GetSStringInfo(LAN_LUA_WND_VILLAGE_5)

	PreCreateString_1374		= GetSStringInfo(LAN_LUA_WND_VILLAGE_6)

	PreCreateString_1375		= GetSStringInfo(LAN_LUA_WND_VILLAGE_7)

	PreCreateString_1376		= GetSStringInfo(LAN_LUA_WND_VILLAGE_8)

	PreCreateString_1377		= GetSStringInfo(LAN_LUA_WND_VILLAGE_9)

	PreCreateString_1378		= GetSStringInfo(LAN_LUA_WND_VILLAGE_10)

	PreCreateString_1379		= GetSStringInfo(LAN_LUA_WND_VILLAGE_11)

	PreCreateString_1380		= GetSStringInfo(LAN_LUA_WND_VILLAGE_12)

	PreCreateString_1381		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_1)

	PreCreateString_1382		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_2)

	PreCreateString_1383		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_3)

	PreCreateString_1384		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_4)

	PreCreateString_1385		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_5)

	PreCreateString_1386		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_6)

	PreCreateString_1387		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_7)

	PreCreateString_1388		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_8)

	PreCreateString_1389		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_9)

	PreCreateString_1390		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_10)

	PreCreateString_1391		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_11)

	PreCreateString_1392		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_12)

	PreCreateString_1393		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_13)

	PreCreateString_1394		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_14)

	PreCreateString_1395		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_15)

	PreCreateString_1396		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_16)

	PreCreateString_1397		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_17)

	PreCreateString_1398		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_18)

	PreCreateString_1399		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_19)

	PreCreateString_1400		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_20)

	PreCreateString_1401		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_21)

	PreCreateString_1402		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_22)

	PreCreateString_1403		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_23)

	PreCreateString_1404		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_24)

	PreCreateString_1405		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_25)

	PreCreateString_1406		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_26)

	PreCreateString_1407		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_27)

	PreCreateString_1408		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_28)

	PreCreateString_1409		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_29)

	PreCreateString_1410		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_30)

	PreCreateString_1411		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_31)

	PreCreateString_1412		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_32)

	PreCreateString_1413		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_33)

	PreCreateString_1414		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_34)

	PreCreateString_1415		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_35)

	PreCreateString_1416		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_36)

	PreCreateString_1417		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_37)

	PreCreateString_1418		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_38)

	PreCreateString_1419		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_39)

	PreCreateString_1420		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_40)

	PreCreateString_1421		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_1)

	PreCreateString_1422		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_2)

	PreCreateString_1423		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_3)

	PreCreateString_1424		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_4)

	PreCreateString_1425		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_5)

	PreCreateString_1426		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_6)

	PreCreateString_1427		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_7)

	PreCreateString_1428		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_8)

	PreCreateString_1429		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_9)

	PreCreateString_1430		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_10)

	PreCreateString_1431		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_11)

	PreCreateString_1432		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_12)

	PreCreateString_1433		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_13)

	PreCreateString_1434		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_14)

	PreCreateString_1435		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_15)

	PreCreateString_1436		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_16)

	PreCreateString_1437		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_17)

	PreCreateString_1438		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_18)

	PreCreateString_1439		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_19)

	PreCreateString_1440		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_20)

	PreCreateString_1441		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_21)

	PreCreateString_1442		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_22)

	PreCreateString_1443		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_23)

	PreCreateString_1444		= GetSStringInfo(LAN_LUA_WND_VILLAGE_MAP_24)

	PreCreateString_1445		= GetSStringInfo(LAN_CPP_BTN_PAGEMOVE_1)

	PreCreateString_1446		= GetSStringInfo(LAN_CPP_BTN_PAGEMOVE_2)

	PreCreateString_1447		= GetSStringInfo(LAN_CPP_BTN_PAGEMOVE_3)

	PreCreateString_1448		= GetSStringInfo(LAN_CPP_BTN_PAGEMOVE_4)

	PreCreateString_1449		= GetSStringInfo(LAN_CPP_BTN_PAGEMOVE_5)

	PreCreateString_1450		= GetSStringInfo(LAN_CPP_BTN_PAGEMOVE_6)

	PreCreateString_1451		= GetSStringInfo(LAN_CPP_BASE_1)

	PreCreateString_1452		= GetSStringInfo(LAN_CPP_BASE_2)

	PreCreateString_1453		= GetSStringInfo(LAN_CPP_BASE_3)

	PreCreateString_1454		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_1)

	PreCreateString_1455		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_2)

	PreCreateString_1456		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_3)

	PreCreateString_1457		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_4)

	PreCreateString_1458		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_5)

	PreCreateString_1459		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_6)

	PreCreateString_1460		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_7)

	PreCreateString_1461		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_1)

	PreCreateString_1462		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_2)

	PreCreateString_1463		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_3)

	PreCreateString_1464		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_4)

	PreCreateString_1465		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_5)

	PreCreateString_1466		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_6)

	PreCreateString_1467		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_7)

	PreCreateString_1468		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_8)

	PreCreateString_1469		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_9)

	PreCreateString_1470		= GetSStringInfo(LAN_CPP_GAME_1)

	PreCreateString_1471		= GetSStringInfo(LAN_CPP_ITEM_BASE_1)

	PreCreateString_1472		= GetSStringInfo(LAN_CPP_ITEM_SHOP_1)

	PreCreateString_1473		= GetSStringInfo(LAN_CPP_LOADING_1)

	PreCreateString_1474		= GetSStringInfo(LAN_CPP_LOBBY_1)

	PreCreateString_1475		= GetSStringInfo(LAN_CPP_LOBBY_2)

	PreCreateString_1476		= GetSStringInfo(LAN_CPP_LOBBY_3)

	PreCreateString_1477		= GetSStringInfo(LAN_CPP_LOBBY_4)

	PreCreateString_1478		= GetSStringInfo(LAN_CPP_LOBBY_5)

	PreCreateString_1479		= GetSStringInfo(LAN_CPP_LOBBY_6)

	PreCreateString_1480		= GetSStringInfo(LAN_CPP_LOBBY_7)

	PreCreateString_1481		= GetSStringInfo(LAN_CPP_LOBBY_8)

	PreCreateString_1482		= GetSStringInfo(LAN_CPP_MYINFO_1)

	PreCreateString_1483		= GetSStringInfo(LAN_CPP_MYINFO_2)

	PreCreateString_1484		= GetSStringInfo(LAN_CPP_MYINFO_3)

	PreCreateString_1485		= GetSStringInfo(LAN_CPP_MYINFO_4)

	PreCreateString_1486		= GetSStringInfo(LAN_CPP_MYINFO_5)

	PreCreateString_1487		= GetSStringInfo(LAN_CPP_MYINFO_6)

	PreCreateString_1488		= GetSStringInfo(LAN_CPP_PRACTICE_1)

	PreCreateString_1489		= GetSStringInfo(LAN_CPP_PRACTICE_2)

	PreCreateString_1490		= GetSStringInfo(LAN_CPP_PRACTICE_3)

	PreCreateString_1491		= GetSStringInfo(LAN_CPP_PRACTICE_4)

	PreCreateString_1492		= GetSStringInfo(LAN_CPP_QUEST_1)

	PreCreateString_1493		= GetSStringInfo(LAN_CPP_QUEST_2)

	PreCreateString_1494		= GetSStringInfo(LAN_CPP_QUEST_3)

	PreCreateString_1495		= GetSStringInfo(LAN_CPP_QUEST_4)

	PreCreateString_1496		= GetSStringInfo(LAN_CPP_QUEST_5)

	PreCreateString_1497		= GetSStringInfo(LAN_CPP_QUEST_6)

	PreCreateString_1498		= GetSStringInfo(LAN_CPP_QUEST_7)

	PreCreateString_1499		= GetSStringInfo(LAN_CPP_QUEST_RESULT_1)

	PreCreateString_1500		= GetSStringInfo(LAN_CPP_QUEST_RESULT_2)

	PreCreateString_1501		= GetSStringInfo(LAN_CPP_QUEST_RESULT_3)

	PreCreateString_1502		= GetSStringInfo(LAN_CPP_QUEST_RESULT_4)

	PreCreateString_1503		= GetSStringInfo(LAN_CPP_QUEST_RESULT_5)

	PreCreateString_1504		= GetSStringInfo(LAN_CPP_QUEST_RESULT_6)

	PreCreateString_1505		= GetSStringInfo(LAN_CPP_QUEST_RESULT_7)

	PreCreateString_1506		= GetSStringInfo(LAN_CPP_QUEST_RESULT_8)

	PreCreateString_1507		= GetSStringInfo(LAN_CPP_QUEST_RESULT_9)

	PreCreateString_1508		= GetSStringInfo(LAN_CPP_QUEST_ROOM_1)

	PreCreateString_1509		= GetSStringInfo(LAN_CPP_QUEST_ROOM_2)

	PreCreateString_1510		= GetSStringInfo(LAN_CPP_QUEST_ROOM_3)

	PreCreateString_1511		= GetSStringInfo(LAN_CPP_SKILL_SHOP_1)

	PreCreateString_1512		= GetSStringInfo(LAN_CPP_SKILL_SHOP_2)

	PreCreateString_1513		= GetSStringInfo(LAN_CPP_VILLAGE_1)

	PreCreateString_1514		= GetSStringInfo(LAN_CPP_VILLAGE_2)

	PreCreateString_1515		= GetSStringInfo(LAN_CPP_VILLAGE_3)

	PreCreateString_1516		= GetSStringInfo(LAN_CPP_VILLAGE_4)

	PreCreateString_1517		= GetSStringInfo(LAN_CPP_VILLAGE_5)

	PreCreateString_1518		= GetSStringInfo(LAN_CPP_VILLAGE_6)

	PreCreateString_1519		= GetSStringInfo(LAN_CPP_VILLAGE_7)

	PreCreateString_1520		= GetSStringInfo(LAN_CPP_VILLAGE_8)

	PreCreateString_1521		= GetSStringInfo(LAN_CPP_VILLAGE_9)

	PreCreateString_1522		= GetSStringInfo(LAN_CPP_VILLAGE_10)

	PreCreateString_1523		= GetSStringInfo(LAN_CPP_VILLAGE_11)

	PreCreateString_1524		= GetSStringInfo(LAN_CPP_VILLAGE_12)

	PreCreateString_1525		= GetSStringInfo(LAN_CPP_VILLAGE_13)

	PreCreateString_1526		= GetSStringInfo(LAN_CPP_VILLAGE_14)

	PreCreateString_1527		= GetSStringInfo(LAN_CPP_VILLAGE_15)

	PreCreateString_1528		= GetSStringInfo(LAN_CPP_VILLAGE_16)

	PreCreateString_1529		= GetSStringInfo(LAN_CPP_VILLAGE_17)

	PreCreateString_1530		= GetSStringInfo(LAN_CPP_VILLAGE_18)

	PreCreateString_1531		= GetSStringInfo(LAN_CPP_VILLAGE_19)

	PreCreateString_1532		= GetSStringInfo(LAN_CPP_VILLAGE_20)

	PreCreateString_1533		= GetSStringInfo(LAN_CPP_VILLAGE_21)

	PreCreateString_1534		= GetSStringInfo(LAN_CPP_VILLAGE_22)

	PreCreateString_1535		= GetSStringInfo(LAN_CPP_VILLAGE_23)

	PreCreateString_1536		= GetSStringInfo(LAN_CPP_VILLAGE_24)

	PreCreateString_1537		= GetSStringInfo(LAN_CPP_VILLAGE_25)

	PreCreateString_1538		= GetSStringInfo(LAN_CPP_VILLAGE_26)

	PreCreateString_1539		= GetSStringInfo(LAN_CPP_VILLAGE_27)

	PreCreateString_1540		= GetSStringInfo(LAN_CPP_VILLAGE_28)

	PreCreateString_1541		= GetSStringInfo(LAN_CPP_VILLAGE_29)

	PreCreateString_1542		= GetSStringInfo(LAN_CPP_MYAPPLICATION_1)

	PreCreateString_1543		= GetSStringInfo(LAN_CPP_MYAPPLICATION_2)

	PreCreateString_1544		= GetSStringInfo(LAN_CPP_MYAPPLICATION_3)

	PreCreateString_1545		= GetSStringInfo(LAN_CPP_MYAPPLICATION_4)

	PreCreateString_1546		= GetSStringInfo(LAN_CPP_MYAPPLICATION_5)

	PreCreateString_1547		= GetSStringInfo(LAN_CPP_MYAPPLICATION_6)

	PreCreateString_1548		= GetSStringInfo(LAN_CPP_MYAPPLICATION_7)

	PreCreateString_1549		= GetSStringInfo(LAN_CPP_MYAPPLICATION_8)

	PreCreateString_1550		= GetSStringInfo(LAN_CPP_MYAPPLICATION_9)

	PreCreateString_1551		= GetSStringInfo(LAN_CPP_MYAPPLICATION_10)

	PreCreateString_1552		= GetSStringInfo(LAN_CPP_MYAPPLICATION_11)

	PreCreateString_1553		= GetSStringInfo(LAN_CPP_WNDAPPLICATION_1)

	PreCreateString_1554		= GetSStringInfo(LAN_CPP_WNDAPPLICATION_2)

	PreCreateString_1555		= GetSStringInfo(LAN_CPP_WNDAPPLICATION_3)

	PreCreateString_1556		= GetSStringInfo(LAN_CPP_OPTION_1)

	PreCreateString_1557		= GetSStringInfo(LAN_CPP_OPTION_2)

	PreCreateString_1558		= GetSStringInfo(LAN_CPP_OPTION_3)

	PreCreateString_1559		= GetSStringInfo(LAN_CPP_OPTION_4)

	PreCreateString_1560		= GetSStringInfo(LAN_CPP_OPTION_5)

	PreCreateString_1561		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_1)

	PreCreateString_1562		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_2)

	PreCreateString_1563		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_3)

	PreCreateString_1564		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_4)

	PreCreateString_1565		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_5)

	PreCreateString_1566		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_6)

	PreCreateString_1567		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_7)

	PreCreateString_1568		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_8)

	PreCreateString_1569		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_9)

	PreCreateString_1570		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_10)

	PreCreateString_1571		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_11)

	PreCreateString_1572		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_12)

	PreCreateString_1573		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_13)

	PreCreateString_1574		= GetSStringInfo(LAN_CPP_FIGHT_CLUB_1)

	PreCreateString_1575		= GetSStringInfo(LAN_CPP_FIGHT_CLUB_2)

	PreCreateString_1576		= GetSStringInfo(LAN_CPP_FIGHT_CLUB_3)

	PreCreateString_1577		= GetSStringInfo(LAN_CPP_FIGHT_CLUB_4)

	PreCreateString_1578		= GetSStringInfo(LAN_CPP_FIGHT_CLUB_5)

	PreCreateString_1579		= GetSStringInfo(LAN_CPP_FIGHT_CLUB_6)

	PreCreateString_1580		= GetSStringInfo(LAN_CPP_FIGHT_CLUB_7)

	PreCreateString_1581		= GetSStringInfo(LAN_CPP_FIGHT_CLUB_8)

	PreCreateString_1582		= GetSStringInfo(LAN_FONT_HY_GUYNGODIC)

	PreCreateString_1655		= GetSStringInfo(LAN_LUA_SELECT_CHANNEL_14)

	PreCreateString_1656		= GetSStringInfo(LAN_LUA_SELECT_CHANNEL_15)

	PreCreateString_1657		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_1)

	PreCreateString_1658		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_2)

	PreCreateString_1659		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_3)

	PreCreateString_1660		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_4)

	PreCreateString_1661		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_5)

	PreCreateString_1662		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_6)

	PreCreateString_1663		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_7)

	PreCreateString_1664		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_8)

	PreCreateString_1665		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_9)

	PreCreateString_1666		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_10)

	PreCreateString_1667		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_11)

	PreCreateString_1668		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_12)

	PreCreateString_1669		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_13)

	PreCreateString_1670		= GetSStringInfo(LAN_LUA_CREATE_CHARACTER_14)

	PreCreateString_1673		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP1)

	PreCreateString_1675		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP2)

	PreCreateString_1677		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP3)

	PreCreateString_1678		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP4)

	PreCreateString_1679		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP5)

	PreCreateString_1680		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP6)

	PreCreateString_1681		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP7)

	PreCreateString_1682		= GetSStringInfo(LAN_LUA_LOBBY_SELECTROOM)

	PreCreateString_1683		= GetSStringInfo(LAN_LUA_CHANGECLASS_1)

	PreCreateString_1684		= GetSStringInfo(LAN_LUA_CHANGECLASS_2)

	PreCreateString_1685		= GetSStringInfo(LAN_LUA_CHANGECLASS_3)

	PreCreateString_1687		= GetSStringInfo(LAN_LUA_CHANGECLASS_4)

	PreCreateString_1688		= GetSStringInfo(LAN_LUA_CHANGECLASS_5)

	PreCreateString_1689		= GetSStringInfo(LAN_LUA_CHANGECLASS_6)

	PreCreateString_1690		= GetSStringInfo(LAN_LUA_QEUESTROOM_1)

	PreCreateString_1691		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_41)

	PreCreateString_1692		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_42)

	PreCreateString_1693		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_43)

	PreCreateString_1694		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_44)

	PreCreateString_1695		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_41)

	PreCreateString_1696		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_42)

	PreCreateString_1697		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_43)

	PreCreateString_1698		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_44)

	PreCreateString_1699		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_45)

	PreCreateString_1700		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_46)

	PreCreateString_1701		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_47)

	PreCreateString_1702		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_48)

	PreCreateString_1703		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_49)

	PreCreateString_1704		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_50)

	PreCreateString_1705		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_51)

	PreCreateString_1706		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_52)

	PreCreateString_1707		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_53)

	PreCreateString_1708		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_54)

	PreCreateString_1709		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_55)

	PreCreateString_1710		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_56)

	PreCreateString_1711		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_57)

	PreCreateString_1712		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_58)

	PreCreateString_1713		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_59)

	PreCreateString_1714		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_60)

	PreCreateString_1715		= GetSStringInfo(LAN_CPP_SELECT_CHANNEL_16)

	PreCreateString_1716		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_61)

	PreCreateString_1723		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_62)

	PreCreateString_1724		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_63)

	PreCreateString_1725		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_64)

	PreCreateString_1726		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_65)

	PreCreateString_1727		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_66)

	PreCreateString_1728		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_67)

	PreCreateString_1729		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_68)

	PreCreateString_1730		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_69)

	PreCreateString_1731		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_70)

	PreCreateString_1733		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_71)

	PreCreateString_1734		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_72)

	PreCreateString_1735		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_73)

	PreCreateString_1736		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_74)

	PreCreateString_1737		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_75)

	PreCreateString_1738		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_76)

	PreCreateString_1739		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_77)

	PreCreateString_1740		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_78)

	PreCreateString_1741		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_1)

	PreCreateString_1742		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_2)

	PreCreateString_1743		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_3)

	PreCreateString_1744		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_4)

	PreCreateString_1745		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_5)

	PreCreateString_1746		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_6)

	PreCreateString_1747		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_7)

	PreCreateString_1748		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_8)

	PreCreateString_1749		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_9)

	PreCreateString_1750		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_10)

	PreCreateString_1751		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_11)

	PreCreateString_1752		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_12)

	PreCreateString_1753		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_13)

	PreCreateString_1754		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_14)

	PreCreateString_1755		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_15)

	PreCreateString_1756		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_16)

	PreCreateString_1757		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_17)

	PreCreateString_1758		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_18)

	PreCreateString_1759		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_19)

	PreCreateString_1760		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_20)

	PreCreateString_1761		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_21)

	PreCreateString_1762		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_22)

	PreCreateString_1763		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_23)

	PreCreateString_1765		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_24)

	PreCreateString_1768		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_25)

	PreCreateString_1769		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_26)

	PreCreateString_1770		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_27)

	PreCreateString_1771		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_28)

	PreCreateString_1772		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_29)

	PreCreateString_1773		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_30)

	PreCreateString_1774		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_31)

	PreCreateString_1775		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_32)

	PreCreateString_1776		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_33)

	PreCreateString_1777		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_34)

	PreCreateString_1778		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_35)

	PreCreateString_1779		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_36)

	PreCreateString_1780		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_37)

	PreCreateString_1781		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_38)

	PreCreateString_1782		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_39)

	PreCreateString_1783		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_40)

	PreCreateString_1784		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_41)

	PreCreateString_1786		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_42)

	PreCreateString_1787		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_43)

	PreCreateString_1788		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_44)

	PreCreateString_1789		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_45)

	PreCreateString_1790		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_46)

	PreCreateString_1791		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_47)

	PreCreateString_1792		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_48)

	PreCreateString_1793		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_49)

	PreCreateString_1794		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_50)

	PreCreateString_1795		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_51)

	PreCreateString_1796		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_52)

	PreCreateString_1797		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_53)

	PreCreateString_1798		= GetSStringInfo(LAN_EVENT_BATTLE_MISSION_54)

	PreCreateString_1801		= GetSStringInfo(LAN_LUA_WND_MYINFO_34)

	PreCreateString_1802		= GetSStringInfo(LAN_LUA_WND_MYINFO_35)

	PreCreateString_1807		= GetSStringInfo(LAN_LUA_WND_MYINFO_36)

	PreCreateString_1808		= GetSStringInfo(LAN_LUA_WND_MYINFO_37)

	PreCreateString_1809		= GetSStringInfo(LAN_LUA_WND_MYINFO_38)

	PreCreateString_1810		= GetSStringInfo(LAN_CPP_QUEST_ROOM_EX1)

	PreCreateString_1811		= GetSStringInfo(LAN_NOT_ENOUGH_CHARACTER_SLOT)

	PreCreateString_1815		= GetSStringInfo(LAN_LUA_ARCADESHOP_10)

	PreCreateString_1817		= GetSStringInfo(LAN_LUA_ARCADESHOP_11)

	PreCreateString_1818		= GetSStringInfo(LAN_LUA_ARCADESHOP_12)

	PreCreateString_1819		= GetSStringInfo(LAN_LUA_ARCADESHOP_13)

	PreCreateString_1821		= GetSStringInfo(LAN_LUA_WND_MYINFO_39)

	PreCreateString_1822		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_5)

	PreCreateString_1823		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_6)

	PreCreateString_1824		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_7)

	PreCreateString_1827		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_8)

	PreCreateString_1828		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_9)

	PreCreateString_1829		= GetSStringInfo(LAN_LUA_WND_MY_ITEM_10)

	PreCreateString_1830		= GetSStringInfo(LAN_LUA_PARTY_MATCH_20)

	PreCreateString_1831		= GetSStringInfo(LAN_LUA_PARTY_MATCH_21)

	PreCreateString_1832		= GetSStringInfo(LAN_LUA_PARTY_MATCH_22)

	PreCreateString_1833		= GetSStringInfo(LAN_LUA_PARTY_MATCH_23)

	PreCreateString_1835		= GetSStringInfo(LAN_LUA_WND_SKILL_SHOP_4)

	PreCreateString_1837		= GetSStringInfo(LAN_LUA_WND_SKILL_SHOP_5)

	PreCreateString_1838		= GetSStringInfo(LAN_LUA_WND_SKILL_SHOP_6)

	PreCreateString_1839		= GetSStringInfo(LAN_LUA_ARCADESHOP_14)

	PreCreateString_1840		= GetSStringInfo(LAN_NOTACADE_TICKET)

	PreCreateString_1841		= GetSStringInfo(LAN_LUA_MYROOM_1)

	PreCreateString_1842		= GetSStringInfo(LAN_LUA_MYROOM_2)

	PreCreateString_1843		= GetSStringInfo(LAN_LUA_MYROOM_3)

	PreCreateString_1844		= GetSStringInfo(LAN_LUA_MYROOM_4)

	PreCreateString_1845		= GetSStringInfo(LAN_LUA_MYROOM_5)

	PreCreateString_1846		= GetSStringInfo(LAN_LUA_MYROOM_6)

	PreCreateString_1847		= GetSStringInfo(LAN_LUA_MYROOM_7)

	PreCreateString_1848		= GetSStringInfo(LAN_LUA_MYROOM_8)

	PreCreateString_1849		= GetSStringInfo(LAN_LUA_MYROOM_9)

	PreCreateString_1850		= GetSStringInfo(LAN_LUA_MYROOM_10)

	PreCreateString_1852		= GetSStringInfo(LAN_LUA_MYROOM_11)

	PreCreateString_1853		= GetSStringInfo(LAN_LUA_MYROOM_12)

	PreCreateString_1863		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_8)

	PreCreateString_1864		= GetSStringInfo(LAN_CPP_BATTLE_ROOM_9)

	PreCreateString_1865		= GetSStringInfo(LAN_LUA_CHALLENGEMISSION_45)

	PreCreateString_1869		= GetSStringInfo(LAN_NOTEXIST_ID)

	PreCreateString_1870		= GetSStringInfo(LAN_CLIENTCALLBACK_1)

	PreCreateString_1871		= GetSStringInfo(LAN_HOST)

	PreCreateString_1872		= GetSStringInfo(LAN_NONETWORKSTATS)

	PreCreateString_1873		= GetSStringInfo(LAN_CLIENTCALLBACK_2)

	PreCreateString_1874		= GetSStringInfo(LAN_LOWSPEED)

	PreCreateString_1875		= GetSStringInfo(LAN_NOPLAYUDP)

	PreCreateString_1876		= GetSStringInfo(LAN_NOSTART)

	PreCreateString_1877		= GetSStringInfo(LAN_UNKNOWN_OUT)

	PreCreateString_1878		= GetSStringInfo(LAN_LUA_PARTY_1)

	PreCreateString_1879		= GetSStringInfo(LAN_LUA_PARTY_2)

	PreCreateString_1891		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_79)

	PreCreateString_1892		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_80)

	PreCreateString_1893		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_81)

	PreCreateString_1894		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_82)

	PreCreateString_1895		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_83)

	PreCreateString_1896		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_84)

	PreCreateString_1897		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_85)

	PreCreateString_1898		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_86)

	PreCreateString_1899		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_87)

	PreCreateString_1900		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_88)

	PreCreateString_1901		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP8)

	PreCreateString_1902		= GetSStringInfo(LAN_CPP_CREATE_CHARACTER_10)

	PreCreateString_1906		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_39)

	PreCreateString_1907		= GetSStringInfo(LAN_LUA_WND_MY_SKILL_40)

	PreCreateString_1908		= GetSStringInfo(LAN_FIND_CHEAT)

	PreCreateString_1909		= GetSStringInfo(ANQ_VIOLET)

	PreCreateString_1954		= GetSStringInfo(LAN_LUA_WND_MYINFO_40)

	PreCreateString_1955		= GetSStringInfo(LAN_CASH)

	PreCreateString_1956		= GetSStringInfo(LAN_LUA_CONGESTION_1)

	PreCreateString_1957		= GetSStringInfo(LAN_LUA_CONGESTION_2)

	PreCreateString_1958		= GetSStringInfo(LAN_LUA_CONGESTION_3)

	PreCreateString_1959		= GetSStringInfo(LAN_LUA_CONGESTION_4)

	PreCreateString_1960		= GetSStringInfo(LAN_LUA_WND_ITEM_SHOP_10)

	PreCreateString_1961		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_7)

	PreCreateString_1962		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_8)

	PreCreateString_1963		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_9)

	PreCreateString_1964		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_10)

	PreCreateString_1965		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_11)

	PreCreateString_1966		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_12)

	PreCreateString_1967		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_13)

	PreCreateString_1968		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_14)

	PreCreateString_1969		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_15)

	PreCreateString_1970		= GetSStringInfo(LAN_LUA_WND_LOBBY_MR_16)

	PreCreateString_1993		= GetSStringInfo(LAN_CPP_BTN_PAGEMOVE_7)

	PreCreateString_1994		= GetSStringInfo(LAN_NOTIFY_REWARD_TRANSFORM_ITEM)

	PreCreateString_1995		= GetSStringInfo(LAN_NOTIFY_REWARD_ZEN_ITEM)

	PreCreateString_1996		= GetSStringInfo(LAN_NOT_MATCH_CLIENT_VERSION)

	PreCreateString_1997		= GetSStringInfo(LAN_NOT_EXIST_HASH_DATA)

	PreCreateString_1998		= GetSStringInfo(LAN_LUA_SHOP_ATTACK_TYPE)

	PreCreateString_1999		= GetSStringInfo(LAN_LUA_SHOP_GRAB_TYPE)

	PreCreateString_2001		= GetSStringInfo(LAN_NOT_USAGECOUNT)

	PreCreateString_2002		= GetSStringInfo(LAN_NOTEXIST_MYSHOP)

	PreCreateString_2003		= GetSStringInfo(LAN_NOTREADY_MYSHOP)

	PreCreateString_2004		= GetSStringInfo(LAN_SHORTMONEY_OPENMYSHOP)

	PreCreateString_2005		= GetSStringInfo(LAN_NOTCHANNEL_INUSER)

	PreCreateString_2006		= GetSStringInfo(LAN_OtherMan_BuyMyShop)

	PreCreateString_2007		= GetSStringInfo(LAN_NOTVISITOR_MYSHOP)

	PreCreateString_2008		= GetSStringInfo(LAN_REGISTER_STRENGTHEN_SKILL)

	PreCreateString_2009		= GetSStringInfo(LAN_REGISTER_TICKET)

	PreCreateString_2010		= GetSStringInfo(LAN_UPGRADE_SKILL_DESC)

	PreCreateString_2011		= GetSStringInfo(LAN_SUCCESS_UPGRADE_SKILL)

	PreCreateString_2012		= GetSStringInfo(LAN_UPGRADE_SKILL_FEE)

	PreCreateString_2013		= GetSStringInfo(LAN_UPGRADE_SKILL_SUCCESS)

	PreCreateString_2014		= GetSStringInfo(LAN_UPGRADE_SKILL_FAIL)

	PreCreateString_2015		= GetSStringInfo(LAN_SKILL_GRADE_NOCHANGE)

	PreCreateString_2016		= GetSStringInfo(LAN_SKILL_GRADE_UP)

	PreCreateString_2017		= GetSStringInfo(LAN_SKILL_GRADE_DOWN)

	PreCreateString_2018		= GetSStringInfo(LAN_LUA_WND_MESSENGER_25)

	PreCreateString_2019		= GetSStringInfo(LAN_LUA_WND_MESSENGER_26)

	PreCreateString_2020		= GetSStringInfo(LAN_LUA_WND_MESSENGER_27)

	PreCreateString_2021		= GetSStringInfo(LAN_MESSENGER_ONLINE)

	PreCreateString_2022		= GetSStringInfo(LAN_MESSENGER_OFFLINE)

	PreCreateString_2023		= GetSStringInfo(LAN_CAN_NOT_INVITE)

	PreCreateString_2024		= GetSStringInfo(LAN_MESSENGER_MSG)

	PreCreateString_2025		= GetSStringInfo(LAN_ALREADY_LOGINED)

	PreCreateString_2027		= GetSStringInfo(LAN_LUA_MESSENGER_28)

	PreCreateString_2029		= GetSStringInfo(LAN_LUA_MESSENGER_29)

	PreCreateString_2036		= GetSStringInfo(LAN_LUA_MESSENGER_30)

	PreCreateString_2037		= GetSStringInfo(LAN_LUA_MESSENGER_31)

	PreCreateString_2038		= GetSStringInfo(LAN_CANNOT_SELL_SAMEITEM)

	PreCreateString_2039		= GetSStringInfo(LAN_GET_UPGRADE_ITEM)

	PreCreateString_2040		= GetSStringInfo(LAN_CAN_NOT_UPGRADE_HOTFIX)

	PreCreateString_2041		= GetSStringInfo(LAN_MYSHOP_OTHER1)

	PreCreateString_2042		= GetSStringInfo(LAN_MYSHOP_OTHER2)

	PreCreateString_2043		= GetSStringInfo(LAN_MYSHOP_OTHER3)

	PreCreateString_2044		= GetSStringInfo(LAN_MYSHOP_OTHER4)

	PreCreateString_2045		= GetSStringInfo(LAN_MYSHOP_OTHER5)

	PreCreateString_2046		= GetSStringInfo(LAN_MYSHOP_OTHER6)

	PreCreateString_2047		= GetSStringInfo(LAN_MYSHOP_OTHER7)

	PreCreateString_2048		= GetSStringInfo(LAN_UPGRADE_HOTFIX_DOUBLECLICK)

	PreCreateString_2049		= GetSStringInfo(LAN_PERIOD_ITEM)

	PreCreateString_2050		= GetSStringInfo(LAN_ALREADY_UPGRADEITEM)

	PreCreateString_2051		= GetSStringInfo(LAN_SHORT_ITEMNUM)

	PreCreateString_2052		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_89)

	PreCreateString_2053		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_90)

	PreCreateString_2054		= GetSStringInfo(LAN_SELECT_HOTFIX_FOR_UPGRADE)

	PreCreateString_2055		= GetSStringInfo(LAN_PURCHASE_SKILL_FAIL)

	PreCreateString_2056		= GetSStringInfo(LAN_LUA_MAIL_DELETE)

	PreCreateString_2057		= GetSStringInfo(LAN_LUA_MAIL_ALLDELETE)

	PreCreateString_2058		= GetSStringInfo(LAN_LUA_MAIL_RESULT)

	PreCreateString_2060		= GetSStringInfo(LAN_LUA_MAIL_MAILTITLE)

	PreCreateString_2061		= GetSStringInfo(LAN_LUA_MAIL_RECEIVER)

	PreCreateString_2062		= GetSStringInfo(LAN_LUA_MAIL_TITLEFILTER)

	PreCreateString_2063		= GetSStringInfo(LAN_LUA_MAIL_DELETECANCEL)

	PreCreateString_2064		= GetSStringInfo(LAN_CAN_NOT_PURCHASE_SKILL)

	PreCreateString_2065		= GetSStringInfo(LAN_LUA_RECEIVE_ITEM)

	PreCreateString_2066		= GetSStringInfo(LAN_FROM_ARCADE)

	PreCreateString_2067		= GetSStringInfo(LAN_FROM_COINNPC)

	PreCreateString_2068		= GetSStringInfo(LAN_FROM_PROMOTION)

	PreCreateString_2069		= GetSStringInfo(LAN_FROM_CHALLENGE)

	PreCreateString_2070		= GetSStringInfo(LAN_FROM_LEVELUP)

	PreCreateString_2071		= GetSStringInfo(LAN_FROM_COUPON)

	PreCreateString_2072		= GetSStringInfo(LAN_FROM_ARCADE_TICKET)

	PreCreateString_2073		= GetSStringInfo(LAN_FROM_CBT_EVENT)

	PreCreateString_2076		= GetSStringInfo(LAN_NOT_MATCH_CLIENT_EXE_VERSION)

	PreCreateString_2077		= GetSStringInfo(LAN_LUA_MAIL_SEND)

	PreCreateString_2078		= GetSStringInfo(LAN_LUA_MAIL_FAILD)

	PreCreateString_2079		= GetSStringInfo(LAN_DOUBLECLICK_REFORM_HOTFIX)

	PreCreateString_2080		= GetSStringInfo(LAN_ENABLE_REFORM_COUNT)

	PreCreateString_2081		= GetSStringInfo(LAN_LUA_BATTLEROOM_RANDOMMAP)

	PreCreateString_2082		= GetSStringInfo(LAN_LUA_MAIL_MESSAGEOVER)

	PreCreateString_2114		= GetSStringInfo(LAN_COMPLETE_COSTUM_REFORM)

	PreCreateString_2115		= GetSStringInfo(LAN_CAN_NOT_REFORM_BASICITEM)

	PreCreateString_2116		= GetSStringInfo(LAN_UPGRADE_IMPOSSIBLE)

	PreCreateString_2117		= GetSStringInfo(LAN_COSTUM_REFORM_WARNING)

	PreCreateString_2118		= GetSStringInfo(LAN_HOTFIX_REGIST_SELECT)

	PreCreateString_2119		= GetSStringInfo(LAN_HOTFIX_COUNT_REGIST_FAIL)

	PreCreateString_2120		= GetSStringInfo(LAN_NOT_CLUBMASTER)

	PreCreateString_2121		= GetSStringInfo(LAN_NOT_ADMINISTRATOR)

	PreCreateString_2122		= GetSStringInfo(LAN_NOT_REMOVECLUB)

	PreCreateString_2123		= GetSStringInfo(LAN_PERIOD_ITEM_REGIST_WARNING)

	PreCreateString_2124		= GetSStringInfo(LAN_LUA_MAIL_SIZEOVER)

	PreCreateString_2126		= GetSStringInfo(LAN_ALREADY_EXIST_USING_ITEM)

	PreCreateString_2127		= GetSStringInfo(LUA_MAIL_COINGRAN_OVER)

	PreCreateString_2130		= GetSStringInfo(LUA_CLUB_NEWMEMBER)

	PreCreateString_2131		= GetSStringInfo(LUA_CLUB_REFUSE)

	PreCreateString_2132		= GetSStringInfo(LUA_CLUB_DELETE)

	PreCreateString_2133		= GetSStringInfo(LUA_CLUB_MEMBEROUT)

	PreCreateString_2134		= GetSStringInfo(LUA_CLUB_CHANGEMASTER)

	PreCreateString_2136		= GetSStringInfo(LAN_USE_COUPON_SUCCESS)

	PreCreateString_2139		= GetSStringInfo(LAN_CAN_NOT_REFORM)

	PreCreateString_2140		= GetSStringInfo(LUA_ITEM_NEW_NAME)

	PreCreateString_2141		= GetSStringInfo(LAN_LUA_RECORDRESET)

	PreCreateString_2142		= GetSStringInfo(LAN_USE_TRANSFORM_WARNING)

	PreCreateString_2143		= GetSStringInfo(LUA_CLUB_NEWINTRO)

	PreCreateString_2144		= GetSStringInfo(LAN_LUA_INSERTBOARD)

	PreCreateString_2145		= GetSStringInfo(LAN_LUA_QUESTBOARD)

	PreCreateString_2146		= GetSStringInfo(LAN_LUA_DELETEBOARD)

	PreCreateString_2147		= GetSStringInfo(LAN_LUA_USE_ITEM)

	PreCreateString_2148		= GetSStringInfo(LAN_LUA_REFUSE_MASTER)

	PreCreateString_2149		= GetSStringInfo(LAN_LUA_GRADE_NAME)

	PreCreateString_2150		= GetSStringInfo(LAN_LUA_CLUBGRADE)

	PreCreateString_2151		= GetSStringInfo(LAN_LUA_INVITE_SUCCESS)

	PreCreateString_2152		= GetSStringInfo(LAN_LUA_INVITE_CLUB)

	PreCreateString_2153		= GetSStringInfo(LAN_USE_KORATE_REASET)

	PreCreateString_2154		= GetSStringInfo(LAN_LUA_MYBUFF_REMAINTIME)

	PreCreateString_2155		= GetSStringInfo(LAN_ADD_SKILL_DAMAGE)

	PreCreateString_2156		= GetSStringInfo(LAN_LUA_JOIN_CLUB)

	PreCreateString_2157		= GetSStringInfo(LAN_LUA_CLUB_BREAKAWAY)

	PreCreateString_2158		= GetSStringInfo(LAN_LUA_CLUBMASTER_REQUEST)

	PreCreateString_2159		= GetSStringInfo(LAN_LUA_DELETE_CLUB)

	PreCreateString_2160		= GetSStringInfo(LAN_LUA_SEND_INVITECLUB)

	PreCreateString_2161		= GetSStringInfo(LAN_LUA_CHANGEDGRADE)

	PreCreateString_2162		= GetSStringInfo(LAN_LUA_MYSHOP_1)

	PreCreateString_2163		= GetSStringInfo(LAN_LUA_MYSHOP_2)

	PreCreateString_2164		= GetSStringInfo(LAN_LUA_CREATENEWCLUB)

	PreCreateString_2165		= GetSStringInfo(LAN_LUA_INVITECLUBNAME)

	PreCreateString_2166		= GetSStringInfo(LAN_LUA_MASTER_CHANGE_NAME)

	PreCreateString_2167		= GetSStringInfo(LAN_LUA_REQUEST_JOINCLUB)

	PreCreateString_2168		= GetSStringInfo(LAN_LUA_CANNOT_PRSENT_HOTPICKS)

	PreCreateString_2169		= GetSStringInfo(LAN_LUA_AWAY_USER)

	PreCreateString_2170		= GetSStringInfo(LAN_INPUT_COUNT)

	PreCreateString_2171		= GetSStringInfo(LAN_BREAK_CLUB_WAITMEMBER)

	PreCreateString_2172		= GetSStringInfo(LAN_MYSHOP_OTHER8)

	PreCreateString_2173		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP9)

	PreCreateString_2174		= GetSStringInfo(LAN_REJECT_JOINCLUB)

	PreCreateString_2175		= GetSStringInfo(LAN_NOT_BREAK_CLUBMASTER)

	PreCreateString_2176		= GetSStringInfo(LAN_NOT_CLUBMEMBER)

	PreCreateString_2177		= GetSStringInfo(LAN_GIVE_CLUBMASTER)

	PreCreateString_2178		= GetSStringInfo(LAN_NOT_ENOUGH_MONEY_FOR_PRESENT)

	PreCreateString_2179		= GetSStringInfo(LAN_SEND_PRESENT)

	PreCreateString_2180		= GetSStringInfo(LAN_RECEIVED_PRESENT)

	PreCreateString_2181		= GetSStringInfo(LAN_DUPLICATE_CLUBNAME)

	PreCreateString_2182		= GetSStringInfo(LAN_DUPLICATE_CLUBTITLE)

	PreCreateString_2183		= GetSStringInfo(LAN_NOT_SHORT_CLUBNAME)

	PreCreateString_2186		= GetSStringInfo(LAN_NOT_USECLUBNAME)

	PreCreateString_2187		= GetSStringInfo(LAN_NOT_USECLUBTITLE)

	PreCreateString_2188		= GetSStringInfo(LAN_LUA_BOARD_SHORT)

	PreCreateString_2189		= GetSStringInfo(LAN_CANNOT_USE_MSG)

	PreCreateString_2190		= GetSStringInfo(LAN_GO_HIDDENMODE_TO_SRANK)

	PreCreateString_2191		= GetSStringInfo(LAN_LUA_POSITONNAME)

	PreCreateString_2192		= GetSStringInfo(LAN_SENT_GIFT)

	PreCreateString_2193		= GetSStringInfo(LAN_LUA_CLUB_PROPOSE_REFUSE)

	PreCreateString_2194		= GetSStringInfo(LAN_INPUT_FIGHTERNAME_GIFT)

	PreCreateString_2195		= GetSStringInfo(LAN_CAN_NOT_PRESENT_SELL_GRAN)

	PreCreateString_2196		= GetSStringInfo(LAN_SEND_GIFT_POSSIBLE_NAME)

	PreCreateString_2210		= GetSStringInfo(LAN_CLUB_NAME_TITLE_SAME)

	PreCreateString_2211		= GetSStringInfo(LAN_LUA_CLUB_SELECT)

	PreCreateString_2212		= GetSStringInfo(LUA_WAITMEMBERINFO_PROPOSE)

	PreCreateString_2213		= GetSStringInfo(LAN_WAITMEMBERINFO_CANCEL)

	PreCreateString_2214		= GetSStringInfo(LAN_LUA_MANAGE_BREAK_CLUB)

	PreCreateString_2215		= GetSStringInfo(LAN_CHARACTER_NAME_CHECK)

	PreCreateString_2216		= GetSStringInfo(LAN_LUA_NOTCHANGEMASTER)

	PreCreateString_2217		= GetSStringInfo(LAN_GAME_EXTENSION_TIME)

	PreCreateString_2218		= GetSStringInfo(LAN_QUICK_MATCH_FAIL)

	PreCreateString_2219		= GetSStringInfo(LAN_SELECT_COSTUM_DETACH_HOTFIX)

	PreCreateString_2220		= GetSStringInfo(LAN_SELECT_DETACH_HOTFIX)

	PreCreateString_2221		= GetSStringInfo(LAN_WANT_TO_DETACH_HOTFIX)

	PreCreateString_2222		= GetSStringInfo(LAN_COMPLETE_DETACH_HOTFIX )

	PreCreateString_2223		= GetSStringInfo(LAN_GOT_UPGRADE_ITEM)

	PreCreateString_2224		= GetSStringInfo(LUA_MASTER_CANT_DELETEID)

	PreCreateString_2225		= GetSStringInfo(LUA_LAN_UPLOAD_CLUBEMBLEM)

	PreCreateString_2226		= GetSStringInfo(LAN_CLUB_EMBLEM_CHANGE)

	PreCreateString_2227		= GetSStringInfo(LAN_EVENT_BONUS_TIME)

	PreCreateString_2228		= GetSStringInfo(LAN_NOW_PATCHING)

	PreCreateString_2229		= GetSStringInfo(LAN_GET_ATTEND_ITEM)

	PreCreateString_2230		= GetSStringInfo(LAN_CONGRATULATION_LEVEL_UP)

	PreCreateString_2236		= GetSStringInfo(LAN_GANG_DELETE_TITLE)

	PreCreateString_2237		= GetSStringInfo(LAN_GANG_DELETE_MSG)

	PreCreateString_2238		= GetSStringInfo(LAN_LOGIN_EVENT)

	PreCreateString_2239		= GetSStringInfo(LUA_TRADE_REQUEST)

	PreCreateString_2240		= GetSStringInfo(LUA_TRADE_REFUSE)

	PreCreateString_2241		= GetSStringInfo(LUA_TRADE_COMPLETE)

	PreCreateString_2242		= GetSStringInfo(LUA_TRADE_CANCEL)

	PreCreateString_2243		= GetSStringInfo(LUA_TRADE_CANCEL_REQUEST)

	PreCreateString_2244		= GetSStringInfo(LUA_TRADE_IMPOSSIBLE1)

	PreCreateString_2245		= GetSStringInfo(LUA_TRADE_IMPOSSIBLE2)

	PreCreateString_2246		= GetSStringInfo(LUA_TRADE_IMPOSSIBLE3)

	PreCreateString_2247		= GetSStringInfo(LUA_TRADE_REQUESTED)

	PreCreateString_2248		= GetSStringInfo(LUA_TRADE_IMPOSSIBLE4)

	PreCreateString_2250		= GetSStringInfo(LUA_TRADE_IMPOSSIBLE5)

	PreCreateString_2251		= GetSStringInfo(LAN_GET_DIG_REWARD_ZEN)

	PreCreateString_2252		= GetSStringInfo(LAN_GET_DIG_REWARD_ITEM)

	PreCreateString_2253		= GetSStringInfo(LUA_TRADE_IMPOSSIBLE6)

	PreCreateString_2254		= GetSStringInfo(LAN_ONE_BY_ONE_ALREADY_TRADE)

	PreCreateString_2262		= GetSStringInfo(LAN_LUA_TOTAL_ANNOUNCE)

	PreCreateString_2263		= GetSStringInfo(LAN_CAN_NOT_DIGITEM)

	PreCreateString_2265		= GetSStringInfo(LAN_REFUSE_ONEBYONE_BECAUSE_REFUSEOPTION)

	PreCreateString_2266		= GetSStringInfo(LAN_CLUBMATCH_CREATETEAM)

	PreCreateString_2267		= GetSStringInfo(LAN_CLUBMATCH_REGISTTEAM)

	PreCreateString_2268		= GetSStringInfo(LAN_CLUBMATCH_INVITE)

	PreCreateString_2269		= GetSStringInfo(LAN_CLUBMATCH_OUT)

	PreCreateString_2270		= GetSStringInfo(LAN_CLUBMATCH_JOIN)

	PreCreateString_2271		= GetSStringInfo(LAN_CLUBMATCH_PROPOSE)

	PreCreateString_2272		= GetSStringInfo(LAN_CLUBMATCH_JOIND)

	PreCreateString_2273		= GetSStringInfo(LAN_CLUBMATCH_LEAVED)

	PreCreateString_2276		= GetSStringInfo(LAN_USABLE)

	PreCreateString_2277		= GetSStringInfo(LAN_CAN_TRADE)

	PreCreateString_2278		= GetSStringInfo(LAN_CAN_PURCHASE)

	PreCreateString_2279		= GetSStringInfo(LAN_CAN_PRESENT)

	PreCreateString_2280		= GetSStringInfo(LAN_CAN_NOT_USE)

	PreCreateString_2281		= GetSStringInfo(LAN_CAN_NOT_TRADE)

	PreCreateString_2282		= GetSStringInfo(LAN_CAN_NOT_PURCHASE)

	PreCreateString_2283		= GetSStringInfo(LAN_CAN_NOT_PRESENT)

	PreCreateString_2284		= GetSStringInfo(LAN_CLUBMATCH_UNREGIST)

	PreCreateString_2285		= GetSStringInfo(LAN_ENABLE_TEAMLEADER)

	PreCreateString_2286		= GetSStringInfo(LAN_BEFORE_REGISTTEAM)

	PreCreateString_2287		= GetSStringInfo(LAN_CREATE_FIGHTGANGTEAM)

	PreCreateString_2288		= GetSStringInfo(LAN_REGIST_FIGHTCLUBTEAM)

	PreCreateString_2289		= GetSStringInfo(LAN_OUT_FIRHGTCLUBTEAM)

	PreCreateString_2290		= GetSStringInfo(LAN_CAN_REFORM_UNLIMITED)

	PreCreateString_2291		= GetSStringInfo(LAN_LUA_CANNOT_ROOMSETTING)

	PreCreateString_2292		= GetSStringInfo(LAN_FIGHTCLUB_EXITALL)

	PreCreateString_2293		= GetSStringInfo(LAN_CANNOT_CLUBMATCH)

	PreCreateString_2294		= GetSStringInfo(LAN_ALREADY_JOINED)

	PreCreateString_2295		= GetSStringInfo(LAN_FIGHTCLUB_UNREGISTED)

	PreCreateString_2296		= GetSStringInfo(LAN_FAILED_DUPLICATE_RUN)

	PreCreateString_2297		= GetSStringInfo(LAN_OUTPUT_EXPECT_TIME)

	PreCreateString_2298		= GetSStringInfo(LAN_WAIT_MEGAPHONE_COUNT)

	PreCreateString_2299		= GetSStringInfo(LAN_OUTPUT_WAIT_TIME)

	PreCreateString_2300		= GetSStringInfo(LAN_USE_MEGAPHONE)

	PreCreateString_2301		= GetSStringInfo(LAN_OUTPUT_NOW)

	PreCreateString_2302		= GetSStringInfo(LAN_RANKTYPE_PERFECT)

	PreCreateString_2303		= GetSStringInfo(LAN_RANKTYPE_MAX_CONSECUTIVE_WIN)

	PreCreateString_2304		= GetSStringInfo(LAN_OUTPUT_WAIT_TIME2)

	PreCreateString_2305		= GetSStringInfo(LAN_OUTPUT_WAIT_TIME3)

	PreCreateString_2306		= GetSStringInfo(LAN_RANKTYPE_CONSECUTIVE_WIN_BREAK)

	PreCreateString_2307		= GetSStringInfo(LAN_LUA_INVITE_FIGHTMATCH)

	PreCreateString_2308		= GetSStringInfo(LAN_CANNOTINVITE_REGISTCLUB)

	PreCreateString_2309		= GetSStringInfo(LAN_CANNOT_JOINFIGHTTEAM)

	PreCreateString_2310		= GetSStringInfo(LAN_PROPOSE_CLUBMACTH_SEND)

	PreCreateString_2311		= GetSStringInfo(LAN_REGISTER_MEGAPHONE_MSG)

	PreCreateString_2312		= GetSStringInfo(LAN_MOVE_CLUBLOBBY)

	PreCreateString_2313		= GetSStringInfo(LAN_LUA_CANCEL_CLUBMATCH)

	PreCreateString_2314		= GetSStringInfo(LAN_CLUBMATCH_STOP_REGIST)

	PreCreateString_2315		= GetSStringInfo(LAN_SHOP_TOOLTIP_TRADE_CHECK)

	PreCreateString_2317		= GetSStringInfo(LAN_REFUSE_INVITE_FRIEND)

	PreCreateString_2318		= GetSStringInfo(LAN_MAX_GUILD_MEMBER_FULLED)

	PreCreateString_2319		= GetSStringInfo(LAN_INCREASE_CLUB_MAX_MEMBER)

	PreCreateString_2323		= GetSStringInfo(LAN_CPP_BTN_PAGEMOVE_8)

	PreCreateString_2324		= GetSStringInfo(LAN_INPUT_LIFE_COUNT)

	PreCreateString_2325		= GetSStringInfo(LAN_NOTICE_MESSAGE)

	PreCreateString_2326		= GetSStringInfo(LAN_NOTICE_MESSAGE_ITEM)

	PreCreateString_2327		= GetSStringInfo(LAN_NOTICE_SKILL_ITEM)

	PreCreateString_2328		= GetSStringInfo(LAN_LUA_PARTY_3)

	PreCreateString_2329		= GetSStringInfo(LUA_ADAPTER_ENABLE)

	PreCreateString_2330		= GetSStringInfo(LAN_ADAPTER_SELECTCHARACTER)

	PreCreateString_2331		= GetSStringInfo(LAN_ADAPTER_REGISTITEM)

	PreCreateString_2332		= GetSStringInfo(LAN_ADAPTER_CHANGENAME)

	PreCreateString_2333		= GetSStringInfo(LAN_CANNOT_ADAPTER)

	PreCreateString_2334		= GetSStringInfo(LAN_GET_ITEM)

	PreCreateString_2335		= GetSStringInfo(LAN_ADAPTER_SAMEITEM)

	PreCreateString_2336		= GetSStringInfo(LAN_USABLE_ONLY_MYROOM)

	PreCreateString_2337		= GetSStringInfo(LAN_LUA_MAILBOX_FULL)

	PreCreateString_2338		= GetSStringInfo(LAN_LUA_MAILBOXFULL_NOTICE)

	PreCreateString_2339		= GetSStringInfo(LAN_LUCKY_FIGHTER_WINNER)

	PreCreateString_2340		= GetSStringInfo(LAN_LUCKY_FIGHTER_REWARD)

	PreCreateString_2341		= GetSStringInfo(LAN_LUCKY_FIGHTER_SUCCESS)

	PreCreateString_2342		= GetSStringInfo(LAN_LUCKY_FIGHTER_FAIL)

	PreCreateString_2343		= GetSStringInfo(LAN_LUCKY_FIGHTER_ATTAINMENT)

	PreCreateString_2344		= GetSStringInfo(LAN_LUCKY_FIGHTER_COUNT_NOTIFY)

	PreCreateString_2345		= GetSStringInfo(LAN_LUCKY_FIGHTER_CHALLENGE_AGAIN)

	PreCreateString_2346		= GetSStringInfo(LAN_LEFT_DAY_TIME)

	PreCreateString_2347		= GetSStringInfo(LAN_LEFT_HOUR_TIME)

	PreCreateString_2348		= GetSStringInfo(LAN_LEFT_MINIT_TIME )

	PreCreateString_2349		= GetSStringInfo(LAN_COSTUME_MIXING_NPC)

	PreCreateString_2350		= GetSStringInfo(LAN_SLOT_NEED_CHIP)

	PreCreateString_2351		= GetSStringInfo(LAN_SUCCESS_COSTUME_CRAFTING)

	PreCreateString_2352		= GetSStringInfo(LAN_FAIL_COSTUME_CRAFTING)

	PreCreateString_2353		= GetSStringInfo(LAN_ITEM_DESTROY)

	PreCreateString_2354		= GetSStringInfo(LAN_CHANGE_ORB_CHIP)

	PreCreateString_2355		= GetSStringInfo(LAN_ITEM_SET1_ABT1)

	PreCreateString_2356		= GetSStringInfo(LAN_ITEM_SET1_ABT2)

	PreCreateString_2357		= GetSStringInfo(LAN_ITEM_SET1_ABT3)

	PreCreateString_2358		= GetSStringInfo(LAN_ITEM_SKILL1)

	PreCreateString_2359		= GetSStringInfo(LAN_SET_EFFECT_STRING)

	PreCreateString_2360		= GetSStringInfo(LAN_SET_ITEM_COUNT)

	PreCreateString_2361		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_91)

	PreCreateString_2362		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_92)

	PreCreateString_2363		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_93)

	PreCreateString_2364		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_94)

	PreCreateString_2365		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_95)

	PreCreateString_2366		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_96)

	PreCreateString_2367		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_97)

	PreCreateString_2368		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_98)

	PreCreateString_2369		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_99)

	PreCreateString_2370		= GetSStringInfo(LAN_LUA_WND_VILLAGE_13)

	PreCreateString_2371		= GetSStringInfo(LAN_COSTUME_CRAFTING_FAIL)

	PreCreateString_2372		= GetSStringInfo(LAN_INPUT_CUBE_COUNT)

	PreCreateString_2373		= GetSStringInfo(LAN_GET_COSTUME_CUBE)

	PreCreateString_2374		= GetSStringInfo(LAN_LUA_BATTLEROOM_MR_MAP1)

	PreCreateString_2375		= GetSStringInfo(LAN_LUA_BATTLEROOM_MR_MAP2)

	PreCreateString_2376		= GetSStringInfo(LAN_LUA_BATTLEROOM_MR_MAP3)

	PreCreateString_2378		= GetSStringInfo(LAN_ITEM_SKILL2)

	PreCreateString_2379		= GetSStringInfo(LAN_NOT_FIGHTCLUBTIME)

	PreCreateString_2380		= GetSStringInfo(LAN_RETURN_MAIL)

	PreCreateString_2381		= GetSStringInfo(LAN_RETURN_MAIL_MSG)

	PreCreateString_2382		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_100)

	PreCreateString_2383		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_101)

	PreCreateString_2384		= GetSStringInfo(LAN_CAN_NOT_PURCHASE_ITEM_SOLD_OUT)

	PreCreateString_2385		= GetSStringInfo(LAN_COMMUNICATION)

	PreCreateString_2386		= GetSStringInfo(LAN_TOWNNPC_STORE)

	PreCreateString_2387		= GetSStringInfo(LAN_TOWNNPC_PARTY)

	PreCreateString_2388		= GetSStringInfo(LAN_TOWNNPC_CHALLENGEMISSION)

	PreCreateString_2389		= GetSStringInfo(LAN_TOWNNPC_SLOTMACHINE)

	PreCreateString_2390		= GetSStringInfo(LAN_TOWNNPC_COSTUME_CRAFTING)

	PreCreateString_2391		= GetSStringInfo(LAN_PROFILE_ADDBLACKLIST)

	PreCreateString_2393		= GetSStringInfo(LAN_PROFILE_DELETEBLACKLIST)

	PreCreateString_2394		= GetSStringInfo(LAN_PROFILE_SECRET)

	PreCreateString_2395		= GetSStringInfo(LAN_REPAIR_PROFILE)

	PreCreateString_2396		= GetSStringInfo(LAN_NOT_PROFILEINFO)

	PreCreateString_2397		= GetSStringInfo(LAN_SET_PROFILE_OPTION)

	PreCreateString_2398		= GetSStringInfo(LAN_PROFILE_WRITEGUESTBOOK)

	PreCreateString_2399		= GetSStringInfo(LAN_WRITE_PROFILEADDMSG)

	PreCreateString_2400		= GetSStringInfo(LAN_REGIST_PROFILE_IMAGE)

	PreCreateString_2401		= GetSStringInfo(LAN_INSERT_PROFILEIMAGE)

	PreCreateString_2402		= GetSStringInfo(LAN_END_OF_FULLSKILL_EVENT)

	PreCreateString_2403		= GetSStringInfo(LUA_GUESTBOOK_SIZEOVER)

	PreCreateString_2404		= GetSStringInfo(LUA_PROFILE_MAN)

	PreCreateString_2405		= GetSStringInfo(LAN_PROFILE_WOMAN)

	PreCreateString_2406		= GetSStringInfo(LAN_PROFILE_IMAGESIZE_OVER)

	PreCreateString_2407		= GetSStringInfo(LAN_PROFILEBUF_OVER)

	PreCreateString_2408		= GetSStringInfo(LAN_CAN_NOT_USE_TRANSFORM)

	PreCreateString_2409		= GetSStringInfo(LAN_CAN_NOT_USE_DOUBLE_DRILL)

	PreCreateString_2410		= GetSStringInfo(LAN_CAN_NOT_USE_METAL_DRILL)

	PreCreateString_2411		= GetSStringInfo(LAN_NOT_EVENT_TIME)

	PreCreateString_2412		= GetSStringInfo(LAN_SECEDE_FROM_PARTY_TO_ENTER)

	PreCreateString_2413		= GetSStringInfo(TOWN_NPC_RENTAL_NAME)

	PreCreateString_2414		= GetSStringInfo(TOWN_NPC_RENTAL_FUNCTION)

	PreCreateString_2415		= GetSStringInfo(TOWN_NPC_RENTAL_Visit)

	PreCreateString_2416		= GetSStringInfo(TOWN_NPC_RENTAL_Title1)

	PreCreateString_2417		= GetSStringInfo(TOWN_NPC_RENTAL_Explain1)

	PreCreateString_2418		= GetSStringInfo(LAN_INPUT_ITEM_COUNT)

	PreCreateString_2419		= GetSStringInfo(LAN_HAVE_NOT_ITEM_FOR_PURCHASE_ITEM)

	PreCreateString_2420		= GetSStringInfo(LAN_ITEMS_NOT_ENOUGH)

	PreCreateString_2421		= GetSStringInfo(LAN_CAN_NOT_SALE)

	PreCreateString_2422		= GetSStringInfo(LAN_PURCHASE_ITEM_COMPLETE)

	PreCreateString_2423		= GetSStringInfo(LAN_SELL_ITEM_COMPLETE)

	PreCreateString_2424		= GetSStringInfo(LAN_GET_ITEM_RANDOM_BOX)

	PreCreateString_2425		= GetSStringInfo(TOWN_NPC_SANTA_NAME)

	PreCreateString_2426		= GetSStringInfo(TOWN_NPC_SANTA_FUNCTION )

	PreCreateString_2427		= GetSStringInfo(TOWN_NPC_SANTA_VISIT)

	PreCreateString_2430		= GetSStringInfo(TOWN_NPC_SANTA_Title1 )

	PreCreateString_2431		= GetSStringInfo(TOWN_NPC_SANTA_Explain1 )

	PreCreateString_2432		= GetSStringInfo(LAN_GANGWAR_NOTIFY_1)

	PreCreateString_2433		= GetSStringInfo(TOWN_NPC_EXCHANGE_NAME )

	PreCreateString_2434		= GetSStringInfo(TOWN_NPC_EXCHANGE_FUNCTION)

	PreCreateString_2435		= GetSStringInfo(TOWN_NPC_EXCHANGE_Visit)

	PreCreateString_2436		= GetSStringInfo(TOWN_NPC_EXCHANGE_Title1)

	PreCreateString_2437		= GetSStringInfo(TOWN_NPC_EXCHANGE_Explain1)

	PreCreateString_2438		= GetSStringInfo(TOWN_NPC_EXCHANGE_Title2)

	PreCreateString_2439		= GetSStringInfo(TOWN_NPC_EXCHANGE_Explain2)

	PreCreateString_2440		= GetSStringInfo(LAN_GANGWAR_NOTIFY_2)

	PreCreateString_2441		= GetSStringInfo(LAN_GANGWAR_NOTIFY_3)

	PreCreateString_2442		= GetSStringInfo(LAN_GANGWAR_NOTIFY_4)

	PreCreateString_2443		= GetSStringInfo(LAN_GANGWAR_NOTIFY_5)

	PreCreateString_2444		= GetSStringInfo(TOWN_NPC_GANGWAR_NAME )

	PreCreateString_2445		= GetSStringInfo(TOWN_NPC_GANGWAR_FUNCTION)

	PreCreateString_2446		= GetSStringInfo(TOWN_NPC_GANGWAR_Visit)

	PreCreateString_2447		= GetSStringInfo(TOWN_NPC_GANGWAR_Title1 )

	PreCreateString_2448		= GetSStringInfo(TOWN_NPC_GANGWAR_Explain1 )

	PreCreateString_2449		= GetSStringInfo(TOWN_NPC_GANGWAR_Title2)

	PreCreateString_2450		= GetSStringInfo(TOWN_NPC_GANGWAR_Explain2)

	PreCreateString_2451		= GetSStringInfo(TOWN_NPC_GANGWAR_Title3)

	PreCreateString_2452		= GetSStringInfo(TOWN_NPC_GANGWAR_Explain3)

	PreCreateString_2453		= GetSStringInfo(TOWN_NPC_GANGWAR_Title4)

	PreCreateString_2454		= GetSStringInfo(TOWN_NPC_GANGWAR_Explain4)

	PreCreateString_2455		= GetSStringInfo(LAN_CLUBWAR_RESIST_MONEY)

	PreCreateString_2456		= GetSStringInfo(LAN_CLASS_DIRTYX)

	PreCreateString_2457		= GetSStringInfo(LAN_MAIL_CHALLREWARD)

	PreCreateString_2458		= GetSStringInfo(TOWN_NPC_GANGWAR_MENUNAME)

	PreCreateString_2459		= GetSStringInfo(LAN_CLUB_INSET_ENTRY)

	PreCreateString_2460		= GetSStringInfo(LAN_CLUB_REMOVE_ENTRY)

	PreCreateString_2461		= GetSStringInfo(LAN_CLUB_ENTRY_ALREADY)

	PreCreateString_2462		= GetSStringInfo(LAN_CLUB_ENTRY_FULL)

	PreCreateString_2464		= GetSStringInfo(LAN_OCCUPATION_WAIT_2_MINUTE)

	PreCreateString_2466		= GetSStringInfo(LAN_OCCUPATION_ALREADY_IN_GAME)

	PreCreateString_2467		= GetSStringInfo(LAN_OCCUPATION_NOT_EMPTY_SEAT)

	PreCreateString_2468		= GetSStringInfo(LAN_OCCUPATION_NOT_IN_ENTRY)

	PreCreateString_2469		= GetSStringInfo(LAN_OCCUPATION_UNKNOWN_ERROR)

	PreCreateString_2470		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX1_SHIELD)

	PreCreateString_2471		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX2_PWUP)

	PreCreateString_2472		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX3_BLOW)

	PreCreateString_2473		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX4_RECOVER)

	PreCreateString_2474		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX5_METEO )

	PreCreateString_2475		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX5_TOWER)

	PreCreateString_2476		= GetSStringInfo(LAN_RANDOMABILTY_GRADE1)

	PreCreateString_2477		= GetSStringInfo(LAN_RANDOMABILTY_GRADE2)

	PreCreateString_2478		= GetSStringInfo(LAN_RANDOMABILTY_GRADE3)

	PreCreateString_2479		= GetSStringInfo(LAN_RANDOMABILTY_GRADE4)

	PreCreateString_2480		= GetSStringInfo(LAN_RANDOMABILTY_GRADE5)

	PreCreateString_2481		= GetSStringInfo(LAN_RANDOMABILTY_GRADE6)

	PreCreateString_2482		= GetSStringInfo(LAN_RANDOMABILTY2_GRADE1)

	PreCreateString_2483		= GetSStringInfo(LAN_RANDOMABILTY2_GRADE2)

	PreCreateString_2484		= GetSStringInfo(LAN_RANDOMABILTY2_GRADE3)

	PreCreateString_2485		= GetSStringInfo(LAN_RANDOMABILTY2_GRADE4)

	PreCreateString_2486		= GetSStringInfo(LAN_RANDOMABILTY2_GRADE5 )

	PreCreateString_2487		= GetSStringInfo(LAN_RANDOMABILTY2_GRADE6)

	PreCreateString_2488		= GetSStringInfo(LAN_CLUBWAR_PLAY_OBSERVER)

	PreCreateString_2489		= GetSStringInfo(LAN_CLUBWAR_NOTICEMSG1)

	PreCreateString_2490		= GetSStringInfo(LAN_CLUBWAR_NOTICEMSG2)

	PreCreateString_2491		= GetSStringInfo(LAN_CLUBWAR_NOTICEMSG3)

	PreCreateString_2492		= GetSStringInfo(LAN_CLUBWAR_NOTICEMSG4)

	PreCreateString_2493		= GetSStringInfo(LAN_CLUBWAR_SERVERNOTICE1)

	PreCreateString_2494		= GetSStringInfo(LAN_CLUBWAR_SERVERNOTICE2)

	PreCreateString_2495		= GetSStringInfo(LAN_NORMAL_SLOT)

	PreCreateString_2496		= GetSStringInfo(LAN_SPECIAL_SLOT)

	PreCreateString_2497		= GetSStringInfo(LAN_PURCHASE_ITEM_TOWNSTORE)

	PreCreateString_2498		= GetSStringInfo(LAN_VALENTINE_EVENT_ERROR)

	PreCreateString_2499		= GetSStringInfo(LAN_CHOCOLATE_PURCHASE_STRING)

	PreCreateString_2500		= GetSStringInfo(LAN_HUNGING_NOTICE_EXP)

	PreCreateString_2501		= GetSStringInfo(LAN_ZONE4ANYFIRST_SETABILITY)

	PreCreateString_2502		= GetSStringInfo(LAN_CPP_LOBBY_9)

	PreCreateString_2521		= GetSStringInfo(LAN_WANT_TO_RESET_CLASS)

	PreCreateString_2522		= GetSStringInfo(LAN_COMPLET_RESET_CLASS)

	PreCreateString_2523		= GetSStringInfo(LAN_CAN_NOT_RESET_CLASS)

	PreCreateString_2524		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP10)

	PreCreateString_2525		= GetSStringInfo(LAN_PVP_Walkout_Start)

	PreCreateString_2526		= GetSStringInfo(LAN_PVP_Walkout_END_Succes)

	PreCreateString_2527		= GetSStringInfo(LAN_PVP_Walkout_END_Fail)

	PreCreateString_2528		= GetSStringInfo(LAN_PVP_Walkout_END_Agree)

	PreCreateString_2529		= GetSStringInfo(LAN_PVP_Walkout_END_NotAgree)

	PreCreateString_2530		= GetSStringInfo(LAN_PVP_Walkout_Wait)

	PreCreateString_2531		= GetSStringInfo(LAN_PVP_Walkout_END_Succes1)

	PreCreateString_2532		= GetSStringInfo(LAN_ITEM_SKILL3)

	PreCreateString_2534		= GetSStringInfo(LAN_ITEM_SKILL4)

	PreCreateString_2535		= GetSStringInfo(LAN_INVENTORY_FULL)

	PreCreateString_2536		= GetSStringInfo(LAN_WATER_GUN)

	PreCreateString_2537		= GetSStringInfo(LUA_DELETE_THIS_ITEM)

	PreCreateString_2538		= GetSStringInfo(LAN_LUA_PARTY_HUNTING)

	PreCreateString_2612		= GetSStringInfo(LAN_USE_HPPOTION)

	PreCreateString_2613		= GetSStringInfo(LAN_USE_SPPOTION)

	PreCreateString_2632		= GetSStringInfo(LAN_LUA_PARTY_PRACTICE)

	PreCreateString_2633		= GetSStringInfo(LAN_LUA_PARTY_BY_CENTER)

	PreCreateString_2634		= GetSStringInfo(LAN_LUA_PARTY_FIGHT)

	PreCreateString_2635		= GetSStringInfo(LAN_LUA_PARTY_AGIT)

	PreCreateString_2636		= GetSStringInfo(LAN_LUA_PARTY_HUNTINGSUBWAY)

	PreCreateString_2637		= GetSStringInfo(TOWN_NPC_STORAGE_NAME)

	PreCreateString_2638		= GetSStringInfo(TOWN_NPC_STORAGE_FUCTION)

	PreCreateString_2639		= GetSStringInfo(LAN_MY_INVEN_FULL)

	PreCreateString_2640		= GetSStringInfo(LAN_USER_INVEN_FULL)

	PreCreateString_2641		= GetSStringInfo(LAN_INVEN_FULL_SAVING_MAILBOX)

	PreCreateString_2642		= GetSStringInfo(LAN_MY_STORAGE_FULL)

	PreCreateString_2643		= GetSStringInfo(LAN_FULL_INVENTORY)

	PreCreateString_2644		= GetSStringInfo(LAN_CAN_NOT_INCREASE_SLOT)

	PreCreateString_2645		= GetSStringInfo(LAN_EXPAND_SLOT)

	PreCreateString_2646		= GetSStringInfo(LAN_ABILITY_ADD_01)

	PreCreateString_2647		= GetSStringInfo(LAN_ABILITY_ADD_02)

	PreCreateString_2648		= GetSStringInfo(LAN_ABILITY_ADD_03)

	PreCreateString_2649		= GetSStringInfo(LAN_ABILITY_ADD_04)

	PreCreateString_2650		= GetSStringInfo(LAN_ABILITY_ADD_05)

	PreCreateString_2651		= GetSStringInfo(LAN_ABILITY_ADD_06)

	PreCreateString_2652		= GetSStringInfo(LAN_ABILITY_ADD_07)

	PreCreateString_2653		= GetSStringInfo(LAN_CAN_NOT_BEFORE_PROMOTION)

	PreCreateString_2654		= GetSStringInfo(LAN_CAN_NOT_BAN_SUPER_OWNER)

	PreCreateString_2655		= GetSStringInfo(LAN_ONLY_SUPER_OWNER_CAN_BAN)

	PreCreateString_2656		= GetSStringInfo(LAN_KICK_VOTE_NOTICE1)

	PreCreateString_2657		= GetSStringInfo(LAN_KICK_VOTE_ERROR)

	PreCreateString_2658		= GetSStringInfo(LAN_KICK_VOTE_AFTER_ROOMJOIN)

	PreCreateString_2659		= GetSStringInfo(LAN_ITEM_SKILL15)

	PreCreateString_2660		= GetSStringInfo(LAN_GALAXY6_ABILITY1)

	PreCreateString_2661		= GetSStringInfo(LAN_GALAXY6_ABILITY2)

	PreCreateString_2662		= GetSStringInfo(LAN_RANDOMBOX_NOTICE)

	PreCreateString_2663		= GetSStringInfo(LAN_RESETCLASS_NOTICE )

	PreCreateString_2664		= GetSStringInfo(LAN_PARTY_LIFE_USE)

	PreCreateString_2665		= GetSStringInfo(LAN_CHINA_NPC1_NAME)

	PreCreateString_2666		= GetSStringInfo(LAN_CHINA_NPC2_NAME)

	PreCreateString_2667		= GetSStringInfo(LAN_CHINA_NPC3_NAME)

	PreCreateString_2668		= GetSStringInfo(LAN_CHINA_NPC4_NAME)

	PreCreateString_2669		= GetSStringInfo(LAN_CHINA_NPC5_NAME)

	PreCreateString_2671		= GetSStringInfo(LAN_CHINA_NPC6_NAME )

	PreCreateString_2672		= GetSStringInfo(LAN_CHINA_NPC1_FUN)

	PreCreateString_2673		= GetSStringInfo(LAN_CHINA_NPC2_FUN)

	PreCreateString_2674		= GetSStringInfo(LAN_CHINA_NPC3_FUN)

	PreCreateString_2675		= GetSStringInfo(LAN_CHINA_NPC1_TITLE1)

	PreCreateString_2676		= GetSStringInfo(LAN_CHINA_NPC1_EXPLAIN1)

	PreCreateString_2677		= GetSStringInfo(LAN_CHINA_NPC1_TITLE2)

	PreCreateString_2678		= GetSStringInfo(LAN_CHINA_NPC1_EXPLAIN2)

	PreCreateString_2679		= GetSStringInfo(LAN_CHINA_NPC1_VISIT)

	PreCreateString_2680		= GetSStringInfo(LAN_CHINA_NPC2_VISIT)

	PreCreateString_2681		= GetSStringInfo(LAN_CHINA_NPC2_TITLE1)

	PreCreateString_2682		= GetSStringInfo(LAN_CHINA_NPC2_EXPLAIN1)

	PreCreateString_2683		= GetSStringInfo(LAN_CHINA_NPC2_TITLE2)

	PreCreateString_2684		= GetSStringInfo(LAN_CHINA_NPC2_EXPLAIN2)

	PreCreateString_2685		= GetSStringInfo(LAN_CHINA_NPC4_VISIT)

	PreCreateString_2686		= GetSStringInfo(LAN_SHARK_ABILITY1)

	PreCreateString_2687		= GetSStringInfo(LAN_SHARK_ABILITY2)

	PreCreateString_2688		= GetSStringInfo(LAN_SHARK_ABILITY3)

	PreCreateString_2689		= GetSStringInfo(LAN_CHARACTER_SKIN_CHANGE)

	PreCreateString_2690		= GetSStringInfo(LAN_CHARACTER_SKIN_CHANGED)

	PreCreateString_2691		= GetSStringInfo(LAN_ITEM_SKILL5)

	PreCreateString_2692		= GetSStringInfo(LAN_SELECT_RANDOMI_TEM)

	PreCreateString_2693		= GetSStringInfo(LAN_REGISTER_STRENGTHEN_ITEM)

	PreCreateString_2694		= GetSStringInfo(LAN_REGISTER_SCROLL)

	PreCreateString_2695		= GetSStringInfo(SKILL_DESTROY_MSG)

	PreCreateString_2696		= GetSStringInfo(LAN_EVENT_FREEPHOTO)

	PreCreateString_2697		= GetSStringInfo(LAN_EVENT_DAILYSUPPLY)

	PreCreateString_2698		= GetSStringInfo(LAN_EVENT_MAILTITLE)

	PreCreateString_2699		= GetSStringInfo(LAN_NPC_TITLE_CHINA)

	PreCreateString_2700		= GetSStringInfo(LAN_LUA_PARTY_MATCH_55)

	PreCreateString_2701		= GetSStringInfo(LAN_LUA_PARTY_ARCADE_TEMPLE)

	PreCreateString_2702		= GetSStringInfo(LAN_LUA_PARTY_HUNTING_TEMPLE)

	PreCreateString_2703		= GetSStringInfo(LAN_SELECT_COUPON)

	PreCreateString_2705		= GetSStringInfo(LAN_HAVE_NOT_USABLE_COUPON)

	PreCreateString_2706		= GetSStringInfo(  LAN_LUA_WND_TOOLTIP_TEAMATK)

	PreCreateString_2707		= GetSStringInfo(LAN_RECOMMENDATION_EVENT)

	PreCreateString_2717		= GetSStringInfo(LAN_RECOMMEND_FRIEND_1)

	PreCreateString_2718		= GetSStringInfo(LAN_RECOMMEND_FRIEND_2)

	PreCreateString_2719		= GetSStringInfo(LAN_RECOMMEND_FRIEND_3)

	PreCreateString_2720		= GetSStringInfo(LAN_RECOMMEND_FRIEND_4)

	PreCreateString_2721		= GetSStringInfo(LAN_RECOMMEND_FRIEND_5)

	PreCreateString_2722		= GetSStringInfo(LAN_TOWN_NPC_EVENT_NAME)

	PreCreateString_2723		= GetSStringInfo(LAN_TOWN_NPC_EVENT_FUN)

	PreCreateString_2724		= GetSStringInfo(LAN_TOWN_NPC_EVENT_VISIT)

	PreCreateString_2725		= GetSStringInfo(LAN_TOWN_NPC_EVENT_MENU1)

	PreCreateString_2726		= GetSStringInfo(LAN_TOWN_NPC_EVENT_MENU2)

	PreCreateString_2727		= GetSStringInfo(LAN_TOWN_NPC_EVENT_EXPLAIN1)

	PreCreateString_2728		= GetSStringInfo(LAN_TOWN_NPC_EVENT_EXPLAIN2)

	PreCreateString_2729		= GetSStringInfo(LAN_RECOMMEND_FRIEND_6)

	PreCreateString_2730		= GetSStringInfo(LAN_CASH_DISCOUNT_1)

	PreCreateString_2731		= GetSStringInfo(LAN_REGIST_ATTRIBUTE_STUFF_ITEM)

	PreCreateString_2732		= GetSStringInfo(LAN_ENABLE_ATTRIBUTE_LEVEL)

	PreCreateString_2733		= GetSStringInfo(LAN_ALREADY_GIVE_ATTRIBUTE)

	PreCreateString_2734		= GetSStringInfo(LAN_SUCCESS_CHARACTER_ATTRIBUTE)

	PreCreateString_2735		= GetSStringInfo(LAN_REGIST_SKILL)

	PreCreateString_2736		= GetSStringInfo(LAN_ALREADY_GIVE_ATTRIBUTE_SKILL)

	PreCreateString_2737		= GetSStringInfo(LAN_SUCCESS_SKILL_ATTRIBUTE)

	PreCreateString_2738		= GetSStringInfo(LAN_FAIL_ATTRIBUTE)

	PreCreateString_2739		= GetSStringInfo(LAN_NOT_CHANGE_ATTRIBUTE_WARNING)

	PreCreateString_2740		= GetSStringInfo(LAN_SELECT_CHARACTER_ATTRIBUTE)

	PreCreateString_2741		= GetSStringInfo(LAN_SELECT_SKILL_ATTRIBUTE)

	PreCreateString_2742		= GetSStringInfo(LAN_ATTRIBUTE_DEFAULT)

	PreCreateString_2743		= GetSStringInfo(LAN_ATTRIBUTE_GROUND)

	PreCreateString_2744		= GetSStringInfo(LAN_ATTRIBUTE_WATER)

	PreCreateString_2745		= GetSStringInfo(LAN_ATTRIBUTE_FIRE)

	PreCreateString_2746		= GetSStringInfo(LAN_ATTRIBUTE_WIND)

	PreCreateString_2747		= GetSStringInfo(LAN_COMEBACK_EVENT )

	PreCreateString_2748		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP11)

	PreCreateString_2749		= GetSStringInfo(LAN_LUA_LIMIT_FRIENDLIST)

	PreCreateString_2752		= GetSStringInfo(LAN_ITEM_SKILL20)

	PreCreateString_2753		= GetSStringInfo(LAN_CANT_REFUND_AFTER_MOVE_INVEN )

	PreCreateString_2756		= GetSStringInfo(LAN_BESTFRIEND_REGISTER_001)

	PreCreateString_2757		= GetSStringInfo(LAN_BESTFRIEND_REGISTER_002)

	PreCreateString_2758		= GetSStringInfo(LAN_BESTFRIEND_REGISTER_003)

	PreCreateString_2759		= GetSStringInfo(LAN_BESTFRIEND_REGISTER_004)

	PreCreateString_2760		= GetSStringInfo(LAN_BESTFRIEND_REGISTER_005)

	PreCreateString_2761		= GetSStringInfo(LAN_BESTFRIEND_REGISTER_006)

	PreCreateString_2762		= GetSStringInfo(LAN_BESTFRIEND_DELETE_001)

	PreCreateString_2763		= GetSStringInfo(LAN_BESTFRIEND_DELETE_002)

	PreCreateString_2764		= GetSStringInfo(LAN_BESTFRIEND_DELETE_003)

	PreCreateString_2765		= GetSStringInfo(LAN_BESTFRIEND_DELETE_004)

	PreCreateString_2766		= GetSStringInfo(LAN_BESTFRIEND_DELETE_005)

	PreCreateString_2767		= GetSStringInfo(LAN_BESTFRIEND_DELETE_006)

	PreCreateString_2769		= GetSStringInfo(LAN_BESTFRIEND_REGISTER_007)

	PreCreateString_2770		= GetSStringInfo(LAN_NOTICE_TOWN_001)

	PreCreateString_2771		= GetSStringInfo(LAN_NOTICE_TOWN_002)

	PreCreateString_2772		= GetSStringInfo(LAN_NOTICE_TOWN_003)

	PreCreateString_2773		= GetSStringInfo(LAN_COSTUME_RESET_001)

	PreCreateString_2774		= GetSStringInfo(LAN_COSTUME_RESET_002)

	PreCreateString_2775		= GetSStringInfo(LAN_NOTICE_TOWN_004)

	PreCreateString_2776		= GetSStringInfo(LAN_NOTICE_TOWN_005)

	PreCreateString_2777		= GetSStringInfo(LAN_NOTICE_TOWN_006)

	PreCreateString_2778		= GetSStringInfo(LAN_NOTICE_TOWN_007)

	PreCreateString_2779		= GetSStringInfo(LAN_NOTICE_TOWN_008)

	PreCreateString_2780		= GetSStringInfo(LAN_BESTFRIEND_DELETE_007)

	PreCreateString_2781		= GetSStringInfo(NAN_PVP_EXIT_GIVEUP_UNDER)

	PreCreateString_2782		= GetSStringInfo(NAN_PVP_EXIT_GIVEUP_COURSE)

	PreCreateString_2783		= GetSStringInfo(NAN_PVP_EXIT_GIVEUP_EXIT)

	PreCreateString_2784		= GetSStringInfo(NAN_PVP_EXIT_GIVEUP_HPUP)

	PreCreateString_2785		= GetSStringInfo(NAN_PVP_EXIT_GIVEUP_HPUP_UP)

	PreCreateString_2786		= GetSStringInfo(NAN_PVP_EXIT_GIVEUP_VICTORY)

	PreCreateString_2837		= GetSStringInfo(LUA_CHANGE_RESOLUTION)

	PreCreateString_2840		= GetSStringInfo(EVENT_THANKSGIVING)

	PreCreateString_2842		= GetSStringInfo(EVENT_THANKSGIVING_1)

	PreCreateString_2843		= GetSStringInfo(EVENT_THANKSGIVING_2)

	PreCreateString_2844		= GetSStringInfo(EVENT_THANKSGIVING_3)

	PreCreateString_2845		= GetSStringInfo(EVENT_THANKSGIVING_4)

	PreCreateString_2853		= GetSStringInfo(LAN_QUEST_TITLE)

	PreCreateString_2889		= GetSStringInfo(NAN_PVP_EXIT_GIVEUP_SANGDEA)

	PreCreateString_2890		= GetSStringInfo(LAN_QUEST_ACCEPT_NOTIFY)

	PreCreateString_2891		= GetSStringInfo(LAN_QUEST_COMPLETE_NOTIFY)

	PreCreateString_2892		= GetSStringInfo(LAN_EVENT_TGD1_TITLE)

	PreCreateString_2893		= GetSStringInfo(LAN_EVENT_TGD_FUNTION)

	PreCreateString_2894		= GetSStringInfo(LAN_EVENT_TGD2_TITLE)

	PreCreateString_2895		= GetSStringInfo(LAN_EVENT_TGD3_TITLE)

	PreCreateString_2896		= GetSStringInfo(LAN_EVENT_TGD4_TITLE)

	PreCreateString_2897		= GetSStringInfo(LAN_TGD_TABLE_OPEN)

	PreCreateString_2898		= GetSStringInfo(LAN_NOT_ENOUGH_ITEM)

	PreCreateString_2899		= GetSStringInfo(LAN_CAN_NOT_TGD_EVENT)

	PreCreateString_2901		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_103)

	PreCreateString_2903		= GetSStringInfo(LAN_MOVE_VILLAGE)

	PreCreateString_2904		= GetSStringInfo(LAN_MOVE_CHARACTER_SELECT)

	PreCreateString_2905		= GetSStringInfo(LAN_MOVE_CHANNEL_SELECT)

	PreCreateString_2906		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_110)

	PreCreateString_2907		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_111)

	PreCreateString_2908		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_112)

	PreCreateString_2909		= GetSStringInfo(LAN_UNABLE_TO_ATTEND_PARTY)

	PreCreateString_2910		= GetSStringInfo(LAN_LUA_WND_PRACTICE_51)

	PreCreateString_2911		= GetSStringInfo(LAN_LUA_WND_PRACTICE_52)

	PreCreateString_2912		= GetSStringInfo( LAN_LUA_WND_PRACTICE_53)

	PreCreateString_2913		= GetSStringInfo( LAN_LUA_WND_PRACTICE_54)

	PreCreateString_2914		= GetSStringInfo(TOWN_NPC_EVENT_FUNCTION)

	PreCreateString_2915		= GetSStringInfo(TOWN_NPC_EVENT_VISIT)

	PreCreateString_2916		= GetSStringInfo(TOWN_NPC_EVENT_Title1 )

	PreCreateString_2917		= GetSStringInfo(TOWN_NPC_EVENT_Explain1 )

	PreCreateString_2918		= GetSStringInfo(LAN_SQUARE_6)

	PreCreateString_2919		= GetSStringInfo(LAN_SQUARE_3)

	PreCreateString_2920		= GetSStringInfo(LAN_LUA_WND_MESSENGER00_1)

	PreCreateString_2921		= GetSStringInfo(LAN_LUA_WND_MESSENGER00_3)

	PreCreateString_2922		= GetSStringInfo(LAN_LUA_WND_MESSENGER00_4)

	PreCreateString_2923		= GetSStringInfo(LAN_LUA_WND_MESSENGER00_6)

	PreCreateString_2924		= GetSStringInfo(LAN_POSSESSION)

	PreCreateString_2929		= GetSStringInfo(Halem_Boss)

	PreCreateString_3001		= GetSStringInfo(TEST_TESTING)

	PreCreateString_3002		= GetSStringInfo(NAN_PVP_CONTINUITY_VICTORY_CANCLE)

	PreCreateString_3009		= GetSStringInfo(NAN_PVP_CONTINUITY_VICTORY_CHANGE)

	PreCreateString_3010		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX6)

	PreCreateString_3015		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX7)

	PreCreateString_3016		= GetSStringInfo(LAN_CLUBWAR_PLAY_ITEMEX8)

	PreCreateString_3017		= GetSStringInfo(LAN_TOWN_NPC_MAIL_NAME)

	PreCreateString_3019		= GetSStringInfo(LAN_TOWN_NPC_MAIL_FUCTION)

	PreCreateString_3063		= GetSStringInfo(LAN_PARTY_NOT_DIVISION)

	PreCreateString_3064		= GetSStringInfo(LAN_PARTY_EQUALITY_DIVISION)

	PreCreateString_3065		= GetSStringInfo(LAN_PARTY_ORDER_DIVISION )

	PreCreateString_3066		= GetSStringInfo(LAN_PARTY_RANDOM_DIVISION )

	PreCreateString_3335		= GetSStringInfo(TOWN_NPC_SANTA_Explain2)

	PreCreateString_3336		= GetSStringInfo(TOWN_NPC_SANTA_Explain3)

	PreCreateString_3338		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_47)

	PreCreateString_3339		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_48)

	PreCreateString_3378		= GetSStringInfo(HUNTING_UI)

	PreCreateString_3379		= GetSStringInfo(ARCADE_UI)

	PreCreateString_3380		= GetSStringInfo(LAN_ITEM_CAPSULE_USE)

	PreCreateString_3381		= GetSStringInfo(LUA_CLUB_MEMBEROUT_GONGBAEK)

	PreCreateString_3382		= GetSStringInfo(LUA_CLUB_NEWMEMBER_CHAT)

	PreCreateString_3383		= GetSStringInfo(ABUSING_SECRETROOM_CREATE)

	PreCreateString_3384		= GetSStringInfo(ABUSING_SECRETROOM_DESCRIPTION)

	PreCreateString_3385		= GetSStringInfo(ABUSING_SECRETROOM_BRAKEFAIL)

	PreCreateString_3386		= GetSStringInfo(ABUSING_SECRETROOM_LOSERENTER)

	PreCreateString_3387		= GetSStringInfo(LAN_ITEM_PERIOD_DAY)

	PreCreateString_3388		= GetSStringInfo(LAN_ITEM_PERIOD_COUNT)

	PreCreateString_3389		= GetSStringInfo(LAN_ITEM_PERIOD_MINUTE)

	PreCreateString_3390		= GetSStringInfo(LAN_ITEM_PERIOD_HOUR)

	PreCreateString_3391		= GetSStringInfo(LAN_REFUND_RETURN_MSG)

	PreCreateString_3392		= GetSStringInfo(LAN_MOVE_BAG_RETURN_MSG)

	PreCreateString_3393		= GetSStringInfo(LAN_COMMERCIAL_STRING_1)

	PreCreateString_3394		= GetSStringInfo(LAN_COMMERCIAL_STRING_2)

	PreCreateString_3395		= GetSStringInfo(LAN_COMMERCIAL_STRING_3)

	PreCreateString_3396		= GetSStringInfo(LAN_COMMERCIAL_STRING_4)

	PreCreateString_3397		= GetSStringInfo(LAN_COMMERCIAL_STRING_5)

	PreCreateString_3398		= GetSStringInfo(LAN_COMMERCIAL_STRING_6)

	PreCreateString_3399		= GetSStringInfo(LAN_COMMERCIAL_STRING_7)

	PreCreateString_3400		= GetSStringInfo(LAN_COMMERCIAL_STRING_8)

	PreCreateString_3401		= GetSStringInfo(LAN_COMMERCIAL_STRING_9)

	PreCreateString_3402		= GetSStringInfo(LAN_COMMERCIAL_STRING_10)

	PreCreateString_3403		= GetSStringInfo(LAN_COMMERCIAL_STRING_11)

	PreCreateString_3405		= GetSStringInfo(LAN_COMMERCIAL_STRING_12)

	PreCreateString_3406		= GetSStringInfo(YOUNGJA_EVENT_TITLE)

	PreCreateString_3407		= GetSStringInfo(YOUNGJA_EVENT_DESCRIPTION)

	PreCreateString_3408		= GetSStringInfo(LAN_COMMERCIAL_STRING_13)

	PreCreateString_3414		= GetSStringInfo(LAN_SKILL_GRADE_RESET)

	PreCreateString_3415		= GetSStringInfo(LAN_SKILL_STATE_CANNOT_USE)

	PreCreateString_3416		= GetSStringInfo(LAN_SKILL_UPGRADE)

	PreCreateString_3417		= GetSStringInfo(LAN_SKILL_UNSEAL)

	PreCreateString_3418		= GetSStringInfo(LAN_SKILLNPC_WHATISSKILL)

	PreCreateString_3419		= GetSStringInfo(LAN_SKILLNPC_SKILLDESCRIPTION)

	PreCreateString_3420		= GetSStringInfo(LAN_EVENT_SALE)

	PreCreateString_3421		= GetSStringInfo(LAN_SKILL_REGIST)

	PreCreateString_3422		= GetSStringInfo(LAN_SKILL_STRENGTHEN_COUPON_REGIST)

	PreCreateString_3423		= GetSStringInfo(LAN_SKILL_UPGRADE_RESULT)

	PreCreateString_3424		= GetSStringInfo(LAN_VALENTINE_EVENT_TITLE)

	PreCreateString_3425		= GetSStringInfo(LAN_VALENTINE_EVENT_STORY)

	PreCreateString_3426		= GetSStringInfo(LAN_VALENTINE_EVENT_DESCRIPTION)

	PreCreateString_3427		= GetSStringInfo(LAN_VALENTINE_EVENT_COMPLETE)

	PreCreateString_3428		= GetSStringInfo(LAN_USE_CHOCOLATE)

	PreCreateString_3429		= GetSStringInfo(LAN_USE_CANDY)

	PreCreateString_3430		= GetSStringInfo(LAN_STORAGE_ERROR)

	PreCreateString_3431		= GetSStringInfo(LAN_ITEM_TRADEABLE)

	PreCreateString_3432		= GetSStringInfo(LAN_SEND_GIFT_LIMIT_EXCESS)

	PreCreateString_3433		= GetSStringInfo(LAN_SELL_ITEM_RETURN_MSG)

	PreCreateString_3434		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST_TITLE)

	PreCreateString_3435		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST_STORY)

	PreCreateString_3436		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST_DESCRIPTION)

	PreCreateString_3437		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST_COMPLETE)

	PreCreateString_3438		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST_CONDITION)

	PreCreateString_3439		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST1_TITLE)

	PreCreateString_3440		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST1_STORY )

	PreCreateString_3441		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST1_DESCRIPTION)

	PreCreateString_3442		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST1_COMPLETE)

	PreCreateString_3443		= GetSStringInfo(LAN_SKILLUPGRADE_QUEST1_CONDITION)

	PreCreateString_3444		= GetSStringInfo(LAN_DUAL_MODE_MIN_USER_NOTIFY)

	PreCreateString_3447		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP12)

	PreCreateString_3448		= GetSStringInfo(LAN_SELL_ITEM_RETURN_MSG001)

	PreCreateString_3449		= GetSStringInfo(LAN_SKILLUP_001)

	PreCreateString_3450		= GetSStringInfo(LAN_SKILLUP_002)

	PreCreateString_3451		= GetSStringInfo(LAN_REGISTER_001)

	PreCreateString_3452		= GetSStringInfo(LAN_REGISTER_002)

	PreCreateString_3453		= GetSStringInfo(LAN_REPORTUSER_001)

	PreCreateString_3460		= GetSStringInfo(YOUNGJA_EVENT_001_DESCRIPTION)

	PreCreateString_3461		= GetSStringInfo(YOUNGJA_EVENT_001_TITLE )

	PreCreateString_3462		= GetSStringInfo(LAN_SUMO)

	PreCreateString_3463		= GetSStringInfo(LAN_PWLIMITFAILURE)

	PreCreateString_3464		= GetSStringInfo(LAN_GodenIronWarrior_ABILITY1 )

	PreCreateString_3465		= GetSStringInfo(LAN_GodenIronWarrior_ABILITY2)

	PreCreateString_3466		= GetSStringInfo(LAN_GodenIronWarrior_ABILITY3)

	PreCreateString_3467		= GetSStringInfo(LAN_IronWarrior_ABILITY1)

	PreCreateString_3468		= GetSStringInfo(LAN_IronWarrior_ABILITY2 )

	PreCreateString_3469		= GetSStringInfo(LAN_IronWarrior_ABILITY3)

	PreCreateString_3470		= GetSStringInfo(LAN_ITEM_SKILL21)

	PreCreateString_3471		= GetSStringInfo(LAN_ONEVSONE_LEDDER)

	PreCreateString_3472		= GetSStringInfo(LAN_ONEVSONE_LEDDER1)

	PreCreateString_3473		= GetSStringInfo(LAN_ONEVSONE_REJECTION)

	PreCreateString_3474		= GetSStringInfo(LAN_ONEVSONE_PARTY)

	PreCreateString_3475		= GetSStringInfo(LAN_ONEVSONE_PARTY1)

	PreCreateString_3476		= GetSStringInfo(LAN_ONEVSONE_TRANSACTIONS)

	PreCreateString_3477		= GetSStringInfo(LAN_ONEVSONE_TRANSACTION1)

	PreCreateString_3478		= GetSStringInfo(LAN_ONEVSONE_REJECTION1)

	PreCreateString_3479		= GetSStringInfo(LAN_EVENT_MAIL001)

	PreCreateString_3480		= GetSStringInfo(LAN_EVENT_MAIL002)

	PreCreateString_3481		= GetSStringInfo(LAN_EVENT_MAIL003)

	PreCreateString_3485		= GetSStringInfo(LAN_GOLDWARRIOR_ABILITY1)

	PreCreateString_3494		= GetSStringInfo(LAN_ITEM_INSUFFICIENCY)

	PreCreateString_3495		= GetSStringInfo(LAN_CHARACTER_DEL_001)

	PreCreateString_3496		= GetSStringInfo(LAN_CHARACTER_DEL_002)

	PreCreateString_3497		= GetSStringInfo(LAN_SECOND_PASSWORD)

	PreCreateString_3498		= GetSStringInfo(LAN_SECOND_PASSWORD_FAIL)

	PreCreateString_3499		= GetSStringInfo(LAN_SECOND_PASSWORD_REENTER)

	PreCreateString_3501		= GetSStringInfo(LAN_SECOND_PASSWORD_LOGINFAIL)

	PreCreateString_3502		= GetSStringInfo(LAN_SECOND_PASSWORD_EASYINFER)

	PreCreateString_3504		= GetSStringInfo(LAN_SECOND_PASSWORD_DIFFERENT)

	PreCreateString_3505		= GetSStringInfo(LAN_SECOND_PASSWORD_CHANGE)

	PreCreateString_3506		= GetSStringInfo(LAN_SECOND_PASSWORD_CLIENTEXIT)

	PreCreateString_3507		= GetSStringInfo(LAN_SECOND_PASSWORD_CHANGE_COMPLET)

	PreCreateString_3508		= GetSStringInfo(LAN_DUAL_MODE_LIMIT)

	PreCreateString_3512		= GetSStringInfo(LAN_LUA_WND_VILLAGE_14)

	PreCreateString_3513		= GetSStringInfo(LAN_LUA_WND_VILLAGE_15)

	PreCreateString_3514		= GetSStringInfo(LAN_LUA_WND_VILLAGE_16)

	PreCreateString_3515		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_102)

	PreCreateString_3517		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_104)

	PreCreateString_3518		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_105)

	PreCreateString_3519		= GetSStringInfo(LAN_SECOND_PASSWORD_LOGIN_1)

	PreCreateString_3520		= GetSStringInfo(LAN_SECOND_PASSWORD_LOGIN_2)

	PreCreateString_3521		= GetSStringInfo(LAN_SECOND_PASSWORD_REFUSE_1)

	PreCreateString_3522		= GetSStringInfo(LAN_SECOND_PASSWORD_REFUSE_2)

	PreCreateString_3523		= GetSStringInfo(LAN_SECOND_PASSWORD_CONFIRM_COMPLETED)

	PreCreateString_3524		= GetSStringInfo(LAN_SECOND_PASSWORD_CONFIRM_FAILED)

	PreCreateString_3525		= GetSStringInfo(LAN_SECOND_PASSWORD_CHANGE_COMPLETE)

	PreCreateString_3526		= GetSStringInfo(LAN_SECOND_PASSWORD_CHANGE_FAILED)

	PreCreateString_3527		= GetSStringInfo(LAN_SECOND_PASSWORD_CREATE_COMPLETE)

	PreCreateString_3528		= GetSStringInfo(LAN_SECOND_PASSWORD_CREATE_FAILED)

	PreCreateString_3529		= GetSStringInfo(LAN_SECOND_PASSWORD_DELETE_QUESTION)

	PreCreateString_3530		= GetSStringInfo(LAN_SECOND_PASSWORD_DELETE_COMPLET)

	PreCreateString_3531		= GetSStringInfo(LAN_TEAM_MODE_MIN_USER_NOTIFY_001)

	PreCreateString_3532		= GetSStringInfo(LAN_CPP_LOBBY_10)

	PreCreateString_3533		= GetSStringInfo(LAN_IPADRESS_LIMIT)

	PreCreateString_3534		= GetSStringInfo(LAN_OTHERMYSHOP_MYSHOP )

	PreCreateString_3537		= GetSStringInfo(LAN_LAST_LOGIN_TIME)

	PreCreateString_3538		= GetSStringInfo(LAN_UPGRADE_HOTFIX)

	PreCreateString_3539		= GetSStringInfo(LAN_REFORM_HOTFIX)

	PreCreateString_3540		= GetSStringInfo(LAN_TOWERWAR_ENTERLIMIT)

	PreCreateString_3541		= GetSStringInfo(LAN_USABLE_ONLY_ZONE6)

	PreCreateString_3542		= GetSStringInfo(LAN_NOTICE_MESSAGE2)

	PreCreateString_3543		= GetSStringInfo(LAN_LUA_PARTY_ARCADE_COW)

	PreCreateString_3546		= GetSStringInfo(LAN_FAILED_ACCEPTCLUB)

	PreCreateString_3547		= GetSStringInfo(LAN_CLONE_MESSAGE_1)

	PreCreateString_3548		= GetSStringInfo(LAN_CLONE_POLLUTION_MESSAGE_1)

	PreCreateString_3549		= GetSStringInfo(LAN_CLONE_POLLUTION_MESSAGE_2)

	PreCreateString_3550		= GetSStringInfo(LAN_CLONE_POLLUTION_MESSAGE_3)

	PreCreateString_3551		= GetSStringInfo(LAN_CLONE_SEPARATE_MESSAGE_1)

	PreCreateString_3552		= GetSStringInfo(LAN_CLONE_SEPARATE_MESSAGE_2)

	PreCreateString_3553		= GetSStringInfo(LAN_CLONE_SEPARATE_MESSAGE_3)

	PreCreateString_3554		= GetSStringInfo(LAN_CLONE_ROLLBACK_1)

	PreCreateString_3555		= GetSStringInfo(LAN_CLONE_ROLLBACK_2)

	PreCreateString_3556		= GetSStringInfo(LAN_CLONE_ROLLBACK_3)

	PreCreateString_3557		= GetSStringInfo(LAN_LUA_WND_VILLAGE_17)

	PreCreateString_3558		= GetSStringInfo(LAN_CLONE_NO_CHANGED)

	PreCreateString_3560		= GetSStringInfo(LAN_CLONE_MESSAGE_2)

	PreCreateString_3561		= GetSStringInfo(LAN_CLONE_MESSAGE_3)

	PreCreateString_3562		= GetSStringInfo(LAN_ITEM_SKILL22)

	PreCreateString_3563		= GetSStringInfo(LAN_SWIMSUIT_ABILITY2 )

	PreCreateString_3564		= GetSStringInfo(LAN_SWIMSUIT_ABILITY3)

	PreCreateString_3566		= GetSStringInfo(LAN_CLONE_MESSAGE_5)

	PreCreateString_3567		= GetSStringInfo(LAN_CLONE_MESSAGE_6)

	PreCreateString_3568		= GetSStringInfo(LAN_CLONE_MESSAGE_7)

	PreCreateString_3569		= GetSStringInfo(LAN_TEAM_TOURNAMENT_01)

	PreCreateString_3570		= GetSStringInfo(LAN_TEAM_TOURNAMENT_02)

	PreCreateString_3571		= GetSStringInfo(LAN_TEAM_TOURNAMENT_03)

	PreCreateString_3572		= GetSStringInfo(LAN_TEAM_TOURNAMENT_04)

	PreCreateString_3573		= GetSStringInfo(LAN_TEAM_TOURNAMENT_05)

	PreCreateString_3574		= GetSStringInfo(LAN_TEAM_TOURNAMENT_06)

	PreCreateString_3575		= GetSStringInfo(LAN_TEAM_TOURNAMENT_07)

	PreCreateString_3576		= GetSStringInfo(LAN_TEAM_TOURNAMENT_08)

	PreCreateString_3577		= GetSStringInfo(LAN_TEAM_TOURNAMENT_20)

	PreCreateString_3578		= GetSStringInfo(LAN_TEAM_TOURNAMENT_10)

	PreCreateString_3579		= GetSStringInfo(LAN_TEAM_TOURNAMENT_11)

	PreCreateString_3580		= GetSStringInfo(LAN_TEAM_TOURNAMENT_12)

	PreCreateString_3581		= GetSStringInfo(LAN_TEAM_TOURNAMENT_13)

	PreCreateString_3582		= GetSStringInfo(LAN_TEAM_TOURNAMENT_14)

	PreCreateString_3583		= GetSStringInfo(LAN_TEAM_TOURNAMENT_15)

	PreCreateString_3584		= GetSStringInfo(LAN_TEAM_TOURNAMENT_16)

	PreCreateString_3585		= GetSStringInfo(LAN_TEAM_TOURNAMENT_17)

	PreCreateString_3586		= GetSStringInfo(LAN_TEAM_TOURNAMENT_18)

	PreCreateString_3587		= GetSStringInfo(LAN_TEAM_TOURNAMENT_19)

	PreCreateString_3588		= GetSStringInfo(LAN_TEAM_TOURNAMENT_21)

	PreCreateString_3589		= GetSStringInfo(LAN_TEAM_TOURNAMENT_22)

	PreCreateString_3590		= GetSStringInfo(LAN_ENTER_CHANNEL_ERROR1)

	PreCreateString_3591		= GetSStringInfo(LAN_BLOCK_USER_1)

	PreCreateString_3592		= GetSStringInfo(LAN_BLOCK_USER_2)

	PreCreateString_3593		= GetSStringInfo(LAN_BLOCK_USER_3)

	PreCreateString_3594		= GetSStringInfo(LAN_NOT_COW_EVENT_TIME )

	PreCreateString_3595		= GetSStringInfo(LAN_BLOCK_USER_4)

	PreCreateString_3596		= GetSStringInfo(LAN_LUA_WND_VILLAGE_PARTY)

	PreCreateString_3597		= GetSStringInfo(LAN_NOT_USE_COUPON_001)

	PreCreateString_3598		= GetSStringInfo(LAN_1ST_EVENT_STORE)

	PreCreateString_3599		= GetSStringInfo(LAN_1ST_EVENT_Visit_Scr)

	PreCreateString_3600		= GetSStringInfo(LAN_1ST_EVENT_FUNCTION_SCR)

	PreCreateString_3603		= GetSStringInfo(LAN_EFFECT_VILLAGE)

	PreCreateString_3605		= GetSStringInfo(LAN_COW_EVENT_MAIL_01)

	PreCreateString_3606		= GetSStringInfo(LAN_COW_EVENT_MAIL_02)

	PreCreateString_3607		= GetSStringInfo(LAN_COW_EVENT_MAIL_03)

	PreCreateString_3608		= GetSStringInfo(LAN_COW_EVENT_MAIL_04)

	PreCreateString_4135		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_60)

	PreCreateString_4136		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_61)

	PreCreateString_4137		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_62)

	PreCreateString_4138		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_63)

	PreCreateString_4139		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_64)

	PreCreateString_4140		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_65)

	PreCreateString_4141		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_66)

	PreCreateString_4142		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_67)

	PreCreateString_4143		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_68)

	PreCreateString_4144		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_69)

	PreCreateString_4145		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_70)

	PreCreateString_4146		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_71)

	PreCreateString_4147		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_72)

	PreCreateString_4148		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_73)

	PreCreateString_4149		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_74)

	PreCreateString_4150		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_75)

	PreCreateString_4151		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_76)

	PreCreateString_4152		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_77)

	PreCreateString_4153		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_78)

	PreCreateString_4154		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_79)

	PreCreateString_4155		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_80)

	PreCreateString_4156		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_81)

	PreCreateString_4157		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_82)

	PreCreateString_4158		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_83)

	PreCreateString_4159		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_84)

	PreCreateString_4160		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_85)

	PreCreateString_4161		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_86)

	PreCreateString_4162		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_87)

	PreCreateString_4163		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_88)

	PreCreateString_4164		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_89)

	PreCreateString_4165		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_90)

	PreCreateString_4166		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_91)

	PreCreateString_4167		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_92)

	PreCreateString_4168		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_93)

	PreCreateString_4169		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_94)

	PreCreateString_4170		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_95)

	PreCreateString_4171		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_96)

	PreCreateString_4172		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_97)

	PreCreateString_4173		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_98)

	PreCreateString_4174		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_99)

	PreCreateString_4175		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_100)

	PreCreateString_4176		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_101)

	PreCreateString_4177		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_102)

	PreCreateString_4178		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_103)

	PreCreateString_4179		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_104)

	PreCreateString_4180		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_105)

	PreCreateString_4181		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_106)

	PreCreateString_4182		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_107)

	PreCreateString_4183		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_108)

	PreCreateString_4184		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_109)

	PreCreateString_4185		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_110)

	PreCreateString_4186		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_111)

	PreCreateString_4187		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_112)

	PreCreateString_4188		= GetSStringInfo(LAN_LUA_WND_PRACTICE_DESIGNER_113)

	PreCreateString_4190		= GetSStringInfo(LAN_INJECTOR_001)

	PreCreateString_4191		= GetSStringInfo(LAN_INJECTOR_002)

	PreCreateString_4192		= GetSStringInfo(LAN_INJECTOR_003)

	PreCreateString_4193		= GetSStringInfo(LAN_INJECTOR_004)

	PreCreateString_4194		= GetSStringInfo(LAN_LEVEL_NOT_001 )

	PreCreateString_4195		= GetSStringInfo(LAN_PVP_MODE_CHOICE_001)

	PreCreateString_4197		= GetSStringInfo(LAN_TEAM_TOURNAMENT_MESSEGE_01)

	PreCreateString_4198		= GetSStringInfo(LAN_TEAM_TOURNAMENT_MESSEGE_02)

	PreCreateString_4199		= GetSStringInfo(LAN_TEAM_TOURNAMENT_AWARD)

	PreCreateString_4205		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP13)

	PreCreateString_4211		= GetSStringInfo(LAN_USE_MEGAPHONE_01)

	PreCreateString_4212		= GetSStringInfo(LAN_TRADE_NOT_01)

	PreCreateString_4213		= GetSStringInfo(LAN_TRADE_NOT_02)

	PreCreateString_4214		= GetSStringInfo(LAN_LEGEND_GATCHAMAN_SETABILITY_01)

	PreCreateString_4215		= GetSStringInfo(LAN_LEGEND_GATCHAMAN_SETABILITY_02)

	PreCreateString_4216		= GetSStringInfo(LAN_UNIQUE_GATCHAMAN_SETABILITY_01)

	PreCreateString_4217		= GetSStringInfo(LAN_UNIQUE_GATCHAMAN_SETABILITY_02)

	PreCreateString_4218		= GetSStringInfo(LAN_UNIQUE_GATCHAMAN_SETABILITY_03)

	PreCreateString_4219		= GetSStringInfo(LAN_LEGEND_GATCHAMAN_SETABILITY_03)

	PreCreateString_4220		= GetSStringInfo(LAN_ZOMBI_DEFFENSE_01)

	PreCreateString_4221		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_LOW_01)

	PreCreateString_4222		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_LOW_02)

	PreCreateString_4223		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_LOW_03)

	PreCreateString_4224		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_MID_01)

	PreCreateString_4225		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_MID_02)

	PreCreateString_4226		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_MID_03)

	PreCreateString_4227		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_HIGH_01)

	PreCreateString_4228		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_HIGH_02)

	PreCreateString_4229		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_HIGH_03)

	PreCreateString_4230		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_UNIQUE_01)

	PreCreateString_4231		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_UNIQUE_02)

	PreCreateString_4232		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_UNIQUE_03)

	PreCreateString_4233		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_RARE_01)

	PreCreateString_4234		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_RARE_02)

	PreCreateString_4235		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_RARE_03)

	PreCreateString_4236		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_LEGEND_01)

	PreCreateString_4237		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_LEGEND_02)

	PreCreateString_4238		= GetSStringInfo(LAN_SETABILITY_ZOMBIE_LEGEND_03)

	PreCreateString_4244		= GetSStringInfo(LAN_ZOMBI_DEFENSE_02)

	PreCreateString_4245		= GetSStringInfo(LAN_ZOMBI_DEFENSE_03)

	PreCreateString_4246		= GetSStringInfo(LAN_ZOMBI_DEFENSE_04)

	PreCreateString_4247		= GetSStringInfo(LAN_ZOMBI_DEFENSE_05)

	PreCreateString_4248		= GetSStringInfo(LAN_ZOMBI_DEFENSE_06)

	PreCreateString_4249		= GetSStringInfo(LAN_ZOMBI_DEFENSE_07)

	PreCreateString_4250		= GetSStringInfo(LAN_ZOMBI_DEFENSE_08)

	PreCreateString_4251		= GetSStringInfo(LAN_ZOMBI_NAME_01)

	PreCreateString_4252		= GetSStringInfo(LAN_ZOMBI_NAME_02)

	PreCreateString_4253		= GetSStringInfo(LAN_ZOMBI_NAME_03)

	PreCreateString_4254		= GetSStringInfo(LAN_ZOMBI_NAME_04)

	PreCreateString_4255		= GetSStringInfo(LAN_ZOMBI_NAME_05)

	PreCreateString_4256		= GetSStringInfo(LAN_ZOMBI_NAME_06)

	PreCreateString_4257		= GetSStringInfo(LAN_ZOMBI_NAME_07)

	PreCreateString_4258		= GetSStringInfo(LAN_LADDERLIMITAION_01)

	PreCreateString_4259		= GetSStringInfo(LAN_SHUTDOWN_NOTICE_01)

	PreCreateString_4266		= GetSStringInfo(LAN_ZOMBI_NOTICE_01)

	PreCreateString_4289		= GetSStringInfo(LAN_LEGEND_PHOENIX_SETABILITY_01 )

	PreCreateString_4290		= GetSStringInfo(LAN_LEGEND_PHOENIX_SETABILITY_02 )

	PreCreateString_4291		= GetSStringInfo(LAN_LEGEND_PHOENIX_SETABILITY_03)

	PreCreateString_4292		= GetSStringInfo(LAN_LEGEND_PHOENIX_SETABILITY_04)

	PreCreateString_4293		= GetSStringInfo(LAN_UNIQUE_PHOENIX_SETABILITY_01 )

	PreCreateString_4294		= GetSStringInfo(LAN_UNIQUE_PHOENIX_SETABILITY_02)

	PreCreateString_4295		= GetSStringInfo(LAN_UNIQUE_PHOENIX_SETABILITY_03 )

	PreCreateString_4296		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP14)

	PreCreateString_4297		= GetSStringInfo(LAN_EVENT_WINTERVACATION_MAIL_TITLE)

	PreCreateString_4298		= GetSStringInfo(LAN_EVENT_WINTERVACATION_MAIL_CONTENT)

	PreCreateString_4299		= GetSStringInfo(LAN_EVENT_WINTERVACATION_MAIL_FROM)

	PreCreateString_4300		= GetSStringInfo(LAN_GM_NOT_01)

	PreCreateString_4301		= GetSStringInfo(LAN_LEGEND_DARKAVENGER_SETABILITY_03)

	PreCreateString_4302		= GetSStringInfo(LAN_LEGEND_DarkAvenger_SETABILITY_01)

	PreCreateString_4303		= GetSStringInfo(LAN_LEGEND_DarkAvenger_SETABILITY_02)

	PreCreateString_4304		= GetSStringInfo(LAN_UNIQUE_DarkAvenger_SETABILITY_01)

	PreCreateString_4305		= GetSStringInfo(LAN_UNIQUE_DarkAvenger_SETABILITY_02)

	PreCreateString_4306		= GetSStringInfo(LAN_UNIQUE_DarkAvenger_SETABILITY_03)

	PreCreateString_4307		= GetSStringInfo(LAN_Sphinx_SETABILITY_01 )

	PreCreateString_4308		= GetSStringInfo(LAN_Sphinx_SETABILITY_02 )

	PreCreateString_4309		= GetSStringInfo(LAN_Sphinx_SETABILITY_03 )

	PreCreateString_4310		= GetSStringInfo(LAN_BLACKLIST_NOTICE_01)

	PreCreateString_4311		= GetSStringInfo(LAN_BLACKLIST_NOTICE_02)

	PreCreateString_4312		= GetSStringInfo(LAN_BLACKLIST_NOTICE_03)

	PreCreateString_4313		= GetSStringInfo(LAN_BLACKLIST_NOTICE_04)

	PreCreateString_4314		= GetSStringInfo(LAN_BLACKLIST_NOTICE_05)

	PreCreateString_4315		= GetSStringInfo(LAN_BLACKLIST_NOTICE_06)

	PreCreateString_4316		= GetSStringInfo(LAN_BLACKLIST_NOTICE_07)

	PreCreateString_4327		= GetSStringInfo(LAN_GANGWAR_REWORD_MAIL_01)

	PreCreateString_4328		= GetSStringInfo(LAN_GANGWAR_REWORD_MAIL_02)

	PreCreateString_4329		= GetSStringInfo(LAN_CHINA_NPC7_NAME )

	PreCreateString_4330		= GetSStringInfo(LAN_CHINA_NPC4_FUN )

	PreCreateString_4331		= GetSStringInfo(LAN_VALENTINE_ITEMSET_001)

	PreCreateString_4332		= GetSStringInfo(LAN_INPUT_CASHDECO_001)

	PreCreateString_4333		= GetSStringInfo(LAN_NO_INPUT_LEGEND_001)

	PreCreateString_4334		= GetSStringInfo(LAN_DECOMACHINE_001)

	PreCreateString_4335		= GetSStringInfo(LAN_DECOMACHINE_002)

	PreCreateString_4336		= GetSStringInfo(LAN_DECOMACHINE_003)

	PreCreateString_4337		= GetSStringInfo(LAN_DECOMACHINE_004)

	PreCreateString_4338		= GetSStringInfo(LAN_DECOMACHINE_005)

	PreCreateString_4339		= GetSStringInfo(LAN_DECOMACHINE_006)

	PreCreateString_4340		= GetSStringInfo(LAN_RENTALSKILL_MSG_01)

	PreCreateString_4341		= GetSStringInfo(LAN_RENTALSKILL_MSG_02)

	PreCreateString_4342		= GetSStringInfo(LAN_BLOCK_MESSAGE_01)

	PreCreateString_4343		= GetSStringInfo(LAN_DECOMACHINE_007)

	PreCreateString_4344		= GetSStringInfo(LAN_CLASSNAME_KUNGFU_001)

	PreCreateString_4351		= GetSStringInfo(LAN_Vacation_Event_Reward_New_03)

	PreCreateString_4352		= GetSStringInfo(LAN_LEGEND_FORESTKEEPER_SETABILITY_03)

	PreCreateString_4353		= GetSStringInfo(LAN_Vacation_Event_Reward_001)

	PreCreateString_4354		= GetSStringInfo(LAN_LEGEND_DARKAVENGER_SETABILITY_04)

	PreCreateString_4355		= GetSStringInfo(LAN_SUMMER_EVENT_MAIL_TITLE)

	PreCreateString_4356		= GetSStringInfo(LAN_LEGEND_FORESTKEEPER_SETABILITY_01)

	PreCreateString_4357		= GetSStringInfo(LAN_LEGEND_FORESTKEEPER_SETABILITY_02)

	PreCreateString_4358		= GetSStringInfo(LAN_UNIQUE_FORESTKEEPER_SETABILITY_01)

	PreCreateString_4359		= GetSStringInfo(LAN_UNIQUE_FORESTKEEPER_SETABILITY_02)

	PreCreateString_4360		= GetSStringInfo(LAN_UNIQUE_FORESTKEEPER_SETABILITY_03)

	PreCreateString_4361		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_001)

	PreCreateString_4362		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_002)

	PreCreateString_4363		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_003)

	PreCreateString_4364		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_004)

	PreCreateString_4365		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_005)

	PreCreateString_4366		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_006)

	PreCreateString_4367		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_007)

	PreCreateString_4368		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_008)

	PreCreateString_4369		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_009)

	PreCreateString_4370		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_010)

	PreCreateString_4371		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_011)

	PreCreateString_4372		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_012)

	PreCreateString_4373		= GetSStringInfo(LAN_EVENTQUEST_SONGKRAN_013)

	PreCreateString_4374		= GetSStringInfo(LAN_NPC_NAME_001)

	PreCreateString_4375		= GetSStringInfo(LAN_NPC_FUNCTION_001)

	PreCreateString_4376		= GetSStringInfo(LAN_Ability_Converter_Notice01)

	PreCreateString_4377		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_01)

	PreCreateString_4378		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_02)

	PreCreateString_4379		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_03)

	PreCreateString_4380		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_04)

	PreCreateString_4381		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_05)

	PreCreateString_4382		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_06)

	PreCreateString_4383		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_07)

	PreCreateString_4384		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_08)

	PreCreateString_4385		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_09)

	PreCreateString_4386		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_10)

	PreCreateString_4387		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_11)

	PreCreateString_4388		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_12)

	PreCreateString_4389		= GetSStringInfo(LAN_PET_NPC_DESCRIPTION_13)

	PreCreateString_4390		= GetSStringInfo(LAN_PET_EVOLUTION_DESCRIPTION_01)

	PreCreateString_4391		= GetSStringInfo(LAN_PET_EVOLUTION_DESCRIPTION_02)

	PreCreateString_4392		= GetSStringInfo(LAN_PET_EVOLUTION_DESCRIPTION_03)

	PreCreateString_4393		= GetSStringInfo(LAN_PET_EVOLUTION_DESCRIPTION_04)

	PreCreateString_4394		= GetSStringInfo(LAN_PET_EVOLUTION_DESCRIPTION_05)

	PreCreateString_4395		= GetSStringInfo(LAN_PET_NAMECHANGE_DESCRIPTION_01)

	PreCreateString_4396		= GetSStringInfo(LAN_PET_NAMECHANGE_DESCRIPTION_02)

	PreCreateString_4397		= GetSStringInfo(LAN_PET_NAMECHANGE_DESCRIPTION_03)

	PreCreateString_4398		= GetSStringInfo(LAN_PET_SATIETY_DESCRIPTION_01)

	PreCreateString_4399		= GetSStringInfo(LAN_PET_SATIETY_DESCRIPTION_02)

	PreCreateString_4400		= GetSStringInfo(LAN_PET_SATIETY_DESCRIPTION_03)

	PreCreateString_4401		= GetSStringInfo(LAN_PET_SATIETY_DESCRIPTION_04)

	PreCreateString_4402		= GetSStringInfo(LAN_PET_SATIETY_DESCRIPTION_05)

	PreCreateString_4403		= GetSStringInfo(LAN_PET_SATIETY_DESCRIPTION_06)

	PreCreateString_4404		= GetSStringInfo(LAN_PET_SATIETY_DESCRIPTION_07)

	PreCreateString_4405		= GetSStringInfo(LAN_PET_SATIETY_DESCRIPTION_08)

	PreCreateString_4406		= GetSStringInfo(LAN_PET_FEEDSTUFF_DESCRIPTION_01)

	PreCreateString_4407		= GetSStringInfo(LAN_PET_FEEDSTUFF_DESCRIPTION_02)

	PreCreateString_4408		= GetSStringInfo(LAN_PET_RECALL_DESCRIPTION_01)

	PreCreateString_4409		= GetSStringInfo(LAN_PET_DElETE_DESCRIPTION_01)

	PreCreateString_4410		= GetSStringInfo(LAN_PET_DElETE_DESCRIPTION_02)

	PreCreateString_4411		= GetSStringInfo(LAN_PET_AFFECTION_DESCRIPTION_01)

	PreCreateString_4412		= GetSStringInfo(LAN_PET_AFFECTION_DESCRIPTION_02)

	PreCreateString_4413		= GetSStringInfo(LAN_PET_AFFECTION_DESCRIPTION_03)

	PreCreateString_4414		= GetSStringInfo(LAN_PET_FEEDSTUFF_DESCRIPTION_03)

	PreCreateString_4415		= GetSStringInfo(LAN_PET_EVOLUTION_DESCRIPTION_06)

	PreCreateString_4416		= GetSStringInfo(LAN_PET_DElETE_DESCRIPTION_03)

	PreCreateString_4417		= GetSStringInfo(PET_EGG_001)

	PreCreateString_4418		= GetSStringInfo(PET_EGG_002)

	PreCreateString_4419		= GetSStringInfo(PET_EGG_003)

	PreCreateString_4420		= GetSStringInfo(LAN_PET_AFFECTION_DESCRIPTION_04)

	PreCreateString_4421		= GetSStringInfo(LAN_RENTALSKILL_MSG_03)

	PreCreateString_4422		= GetSStringInfo(LAN_PET_EGG_004)

	PreCreateString_4423		= GetSStringInfo(LAN_PET_CASHFEEDSTUFF_DESCRIPTION_01)

	PreCreateString_4424		= GetSStringInfo(LAN_PET_EGG_005)

	PreCreateString_4425		= GetSStringInfo(LAN_PET_EXTRA_001)

	PreCreateString_4426		= GetSStringInfo(LAN_PET_EXTRA_002)

	PreCreateString_4427		= GetSStringInfo(LAN_PET_EXTRA_003)

	PreCreateString_4428		= GetSStringInfo(LAN_PET_EXTRA_004)

	PreCreateString_4429		= GetSStringInfo(LAN_PET_EXTRA_005)

	PreCreateString_4430		= GetSStringInfo(LAN_PET_EXTRA_006)

	PreCreateString_4431		= GetSStringInfo(LAN_PET_EXTRA_007)

	PreCreateString_4432		= GetSStringInfo(LAN_PET_EXTRA_008)

	PreCreateString_4433		= GetSStringInfo(LAN_PET_EXTRA_009)

	PreCreateString_4434		= GetSStringInfo(LAN_PET_EXTRA_010)

	PreCreateString_4435		= GetSStringInfo(LAN_PET_EXTRA_011)

	PreCreateString_4436		= GetSStringInfo(LAN_PET_EXTRA_012)

	PreCreateString_4437		= GetSStringInfo(LAN_PET_EXTRA_013)

	PreCreateString_4438		= GetSStringInfo(LAN_PET_EXTRA_014)

	PreCreateString_4439		= GetSStringInfo(LAN_DECO_CHIPUSE_001)

	PreCreateString_4440		= GetSStringInfo(LAN_DECO_CHIPUSE_002)

	PreCreateString_4441		= GetSStringInfo(LAN_DECO_CHIPUSE_003)

	PreCreateString_4442		= GetSStringInfo(LAN_DECO_CHIPUSE_004)

	PreCreateString_4443		= GetSStringInfo(LAN_DECO_CHIPUSE_005)

	PreCreateString_4444		= GetSStringInfo(LAN_HUNTINGFIELD_ERRMSG_001)

	PreCreateString_4445		= GetSStringInfo(LAN_HUNTINGFIELD_ERRMSG_002)

	PreCreateString_4446		= GetSStringInfo(LAN_ESCROW_ERRMSG_001)

	PreCreateString_4447		= GetSStringInfo(LAN_ESCROW_ERRMSG_002)

	PreCreateString_4448		= GetSStringInfo(LAN_ESCROW_ERRMSG_003)

	PreCreateString_4449		= GetSStringInfo(LAN_ESCROW_ERRMSG_004)

	PreCreateString_4450		= GetSStringInfo(LAN_ESCROW_ERRMSG_005)

	PreCreateString_4451		= GetSStringInfo(LAN_ESCROW_ERRMSG_006)

	PreCreateString_4452		= GetSStringInfo(LAN_ESCROW_ERRMSG_007)

	PreCreateString_4453		= GetSStringInfo(LAN_ESCROW_ASKMSG_001)

	PreCreateString_4454		= GetSStringInfo(LAN_ESCROW_OKMSG_001)

	PreCreateString_4455		= GetSStringInfo(LAN_ESCROW_OKMSG_002)

	PreCreateString_4456		= GetSStringInfo(LAN_ESCROW_ERRMSG_REQUESTBUY_001)

	PreCreateString_4457		= GetSStringInfo(LAN_ESCROW_ASKMSG_DEL_SALE_001)

	PreCreateString_4458		= GetSStringInfo(LAN_ESCROW_OKMSG_DEL_SALE_001)

	PreCreateString_4459		= GetSStringInfo(LAN_ESCROW_ERRMSG_DEL_SALE_001)

	PreCreateString_4460		= GetSStringInfo(LAN_ESCROW_OKMSG_EDIT_SALE_001)

	PreCreateString_4461		= GetSStringInfo(LAN_ESCROW_ASKMSG_CANCELBUY_001)

	PreCreateString_4462		= GetSStringInfo(LAN_ESCROW_ASKMSG_CANCELSALE_001)

	PreCreateString_4463		= GetSStringInfo(LAN_ESCROW_OKMSG_CANCELSALE_001)

	PreCreateString_4464		= GetSStringInfo(LAN_ESCROW_ASKMSG_COMPLETIONSALE_001)

	PreCreateString_4465		= GetSStringInfo(LAN_ESCROW_OKMSG_COMPLETIONSALE_001)

	PreCreateString_4466		= GetSStringInfo(LAN_ESCROW_OKMAIL_REQUESTBUY_001)

	PreCreateString_4467		= GetSStringInfo(LAN_ESCROW_OKMAIL_CANCELREQUESTBUY_001)

	PreCreateString_4468		= GetSStringInfo(LAN_ESCROW_OKMAIL_COMPLETIONSALE_001)

	PreCreateString_4469		= GetSStringInfo(LAN_ESCROW_ERRMSG_008)

	PreCreateString_4470		= GetSStringInfo(LAN_ESCROW_ERRMSG_009)

	PreCreateString_4471		= GetSStringInfo(LAN_ESCROW_ERRMSG_EDIT_SALE_001)

	PreCreateString_4472		= GetSStringInfo(LAN_ESCROW_MAILTITLE_001)

	PreCreateString_4473		= GetSStringInfo(LAN_ESCROW_MAILTITLE_002)

	PreCreateString_4474		= GetSStringInfo(LAN_ESCROW_MAILTITLE_003)

	PreCreateString_4475		= GetSStringInfo(LAN_LEGEND_SHINOBI_SETABILITY_03 )

	PreCreateString_4476		= GetSStringInfo(LAN_ITEM_SKILL6)

	PreCreateString_4477		= GetSStringInfo(LAN_SHUTDOWN_NOTICE_02)

	PreCreateString_4478		= GetSStringInfo(LAN_SHUTDOWN_NOTICE_03)

	PreCreateString_4479		= GetSStringInfo(LAN_SHUTDOWN_NOTICE_04)

	PreCreateString_4480		= GetSStringInfo(LAN_SHUTDOWN_NOTICE_05)

	PreCreateString_4481		= GetSStringInfo(LAN_PETITEM_ASKMSG_REFINE_001)

	PreCreateString_4482		= GetSStringInfo(LAN_PETITEM_ASKMSG_OPENABILITY_001)

	PreCreateString_4483		= GetSStringInfo(LAN_PETITEM_OKMSG_OPENABILITY_001)

	PreCreateString_4484		= GetSStringInfo(LAN_PETITEM_ERRMSG_001)

	PreCreateString_4485		= GetSStringInfo(LAN_PETITEM_KIND_001)

	PreCreateString_4486		= GetSStringInfo(LAN_PETITEM_KIND_002)

	PreCreateString_4487		= GetSStringInfo(LAN_PETITEM_KIND_003)

	PreCreateString_4488		= GetSStringInfo(LAN_PETITEM_KIND_004)

	PreCreateString_4489		= GetSStringInfo(LAN_PETITEM_KIND_005)

	PreCreateString_4490		= GetSStringInfo(LAN_PETITEM_KIND_006)

	PreCreateString_4491		= GetSStringInfo(LAN_GABABO_MAIN_001)

	PreCreateString_4492		= GetSStringInfo(LAN_GABABO_MAIN_002)

	PreCreateString_4493		= GetSStringInfo(LAN_GABABO_MAIN_003)

	PreCreateString_4494		= GetSStringInfo(LAN_GABABO_OUTCOME_001)

	PreCreateString_4495		= GetSStringInfo(LAN_GABABO_OUTCOME_002)

	PreCreateString_4496		= GetSStringInfo(LAN_GABABO_OUTCOME_003)

	PreCreateString_4497		= GetSStringInfo(LAN_GABABO_OUTCOME_004)

	PreCreateString_4498		= GetSStringInfo(LAN_GABABO_OUTCOME_005)

	PreCreateString_4499		= GetSStringInfo(LAN_GABABO_OUTCOME_006)

	PreCreateString_4500		= GetSStringInfo(LAN_GABABO_PRESENT_001)

	PreCreateString_4501		= GetSStringInfo(LAN_GABABO_PRESENT_002)

	PreCreateString_4502		= GetSStringInfo(LAN_GABABO_PRESENT_003)

	PreCreateString_4503		= GetSStringInfo(LAN_GABABO_PRESENT_004)

	PreCreateString_4504		= GetSStringInfo(LAN_GABABO_PRESENT_005)

	PreCreateString_4505		= GetSStringInfo(LAN_GABABO_PRESENT_006)

	PreCreateString_4506		= GetSStringInfo(LAN_GABABO_PRESENT_007)

	PreCreateString_4507		= GetSStringInfo(LAN_GABABO_PRESENT_008)

	PreCreateString_4508		= GetSStringInfo(LAN_GABABO_PRESENT_009)

	PreCreateString_4509		= GetSStringInfo(LAN_GABABO_PRESENT_010)

	PreCreateString_4510		= GetSStringInfo(LAN_GABABO_PRESENT_011)

	PreCreateString_4511		= GetSStringInfo(LAN_GABABO_CONSUME_001)

	PreCreateString_4512		= GetSStringInfo(LAN_GABABO_CONSUME_002)

	PreCreateString_4513		= GetSStringInfo(LAN_GABABO_NPC_TALK_001)

	PreCreateString_4514		= GetSStringInfo(LAN_GABABO_NPC_TALK_002)

	PreCreateString_4515		= GetSStringInfo(LAN_GABABO_NPC_TALK_003)

	PreCreateString_4516		= GetSStringInfo(LAN_GABABO_NPC_TALK_004)

	PreCreateString_4517		= GetSStringInfo(LAN_GABABO_NPC_TALK_005)

	PreCreateString_4518		= GetSStringInfo(LAN_OMULTIPLICATION_MAIN_001)

	PreCreateString_4519		= GetSStringInfo(LAN_OMULTIPLICATION_KIND_001)

	PreCreateString_4520		= GetSStringInfo(LAN_OMULTIPLICATION_KIND_002)

	PreCreateString_4521		= GetSStringInfo(LAN_OMULTIPLICATION_KIND_003)

	PreCreateString_4522		= GetSStringInfo(LAN_OMULTIPLICATION_KIND_004)

	PreCreateString_4523		= GetSStringInfo(LAN_OMULTIPLICATION_KIND_005)

	PreCreateString_4524		= GetSStringInfo(LAN_OMULTIPLICATION_KIND_006)

	PreCreateString_4525		= GetSStringInfo(LAN_OMULTIPLICATION_KIND_007)

	PreCreateString_4526		= GetSStringInfo(LAN_OMULTIPLICATION_PRESENT_001)

	PreCreateString_4527		= GetSStringInfo(LAN_OMULTIPLICATION_PRESENT_002)

	PreCreateString_4528		= GetSStringInfo(LAN_OMULTIPLICATION_CONSUME_001)

	PreCreateString_4529		= GetSStringInfo(LAN_OMULTIPLICATION_NPC_TALK_001)

	PreCreateString_4530		= GetSStringInfo(LAN_OMULTIPLICATION_NPC_TALK_002)

	PreCreateString_4531		= GetSStringInfo(LAN_OMULTIPLICATION_NPC_TALK_003)

	PreCreateString_4532		= GetSStringInfo(LAN_OMULTIPLICATION_NPC_TALK_004)

	PreCreateString_4533		= GetSStringInfo(LAN_LEGEND_FORESTKEEPER_SETABILITY_04)

	PreCreateString_4534		= GetSStringInfo(LAN_AMAZINGEGG_SET_001)

	PreCreateString_4535		= GetSStringInfo(LAN_AMAZINGEGG_SET_002)

	PreCreateString_4536		= GetSStringInfo(LAN_AMAZINGEGG_SET_003)

	PreCreateString_4537		= GetSStringInfo(LAN_AMAZINGEGG_SET_004)

	PreCreateString_4538		= GetSStringInfo(LAN_AMAZINGEGG_SET_005)

	PreCreateString_4539		= GetSStringInfo(LAN_AMAZINGEGG_SET_006)

	PreCreateString_4540		= GetSStringInfo(LAN_AMAZINGEGG_SET_007)

	PreCreateString_4541		= GetSStringInfo(LAN_AMAZINGEGG_SET_008)

	PreCreateString_4542		= GetSStringInfo(LAN_AMAZINGEGG_SET_009)

	PreCreateString_4543		= GetSStringInfo(LAN_AMAZINGEGG_SET_010)

	PreCreateString_4544		= GetSStringInfo(LAN_GABABO_NOTICE_01)

	PreCreateString_4545		= GetSStringInfo(LAN_GABABO_MAIN_004)

	PreCreateString_4546		= GetSStringInfo(LAN_VIKING_ESKILL_001)

	PreCreateString_4547		= GetSStringInfo(LAN_HALLOWEEN_BOX_NOTICE_01)

	PreCreateString_4548		= GetSStringInfo(LAN_HALLOWEEN_BOX_NOTICE_02)

	PreCreateString_4549		= GetSStringInfo(LAN_ESCROW_ERRMSG_010)

	PreCreateString_4550		= GetSStringInfo(LAN_MSG_FB_ERR_001)

	PreCreateString_4551		= GetSStringInfo(LAN_MSG_FB_ERR_002)

	PreCreateString_4552		= GetSStringInfo(LAN_MSG_FB_ERR_003)

	PreCreateString_4553		= GetSStringInfo(LAN_MSG_FB_OK_001)

	PreCreateString_4554		= GetSStringInfo(LAN_MSG_FB_ASK_001)

	PreCreateString_4555		= GetSStringInfo(LAN_MSG_FB_LOADING_001)

	PreCreateString_4556		= GetSStringInfo(LAN_MSG_FB_INFO_001)

	PreCreateString_4557		= GetSStringInfo(LAN_MSG_FB_INFO_002)

	PreCreateString_4558		= GetSStringInfo(LAN_ESKILL_BLAZE_001)

	PreCreateString_4559		= GetSStringInfo(LAN_MSG_FB_ASK_002)

	PreCreateString_4560		= GetSStringInfo(LEN_BLAZE_SET_001)

	PreCreateString_4561		= GetSStringInfo(LEN_BLAZE_SET_002)

	PreCreateString_4562		= GetSStringInfo(LEN_BLAZE_SET_003)

	PreCreateString_4563		= GetSStringInfo(LEN_BLAZE_SET_004)

	PreCreateString_4564		= GetSStringInfo(LEN_BLAZE_SET_005)

	PreCreateString_4565		= GetSStringInfo(LEN_BLAZE_SET_006)

	PreCreateString_4566		= GetSStringInfo(LAN_LEGEND_SHINOBI_SETABILITY_01)

	PreCreateString_4567		= GetSStringInfo(LAN_LEGEND_SHINOBI_SETABILITY_02)

	PreCreateString_4568		= GetSStringInfo(LAN_LEGEND_SHINOBI_SETABILITY_04)

	PreCreateString_4569		= GetSStringInfo(LAN_UNIQUE_SHINOBI_SETABILITY_01)

	PreCreateString_4570		= GetSStringInfo(LAN_UNIQUE_SHINOBI_SETABILITY_02)

	PreCreateString_4571		= GetSStringInfo(LAN_UNIQUE_SHINOBI_SETABILITY_03)

	PreCreateString_4572		= GetSStringInfo(LAN_AUTO_BLACKSYSTEM_001)

	PreCreateString_4573		= GetSStringInfo(LAN_MAX_ADMISSION_USER_001)

	PreCreateString_4574		= GetSStringInfo(LAN_MAX_ADMISSION_USER_002)

	PreCreateString_4575		= GetSStringInfo(LEN_BLACKKNIGHT_001)

	PreCreateString_4576		= GetSStringInfo(LEN_BLACKKNIGHT_002)

	PreCreateString_4577		= GetSStringInfo(LEN_BLACKKNIGHT_003)

	PreCreateString_4578		= GetSStringInfo(LEN_USER_ARTIST_001)

	PreCreateString_4579		= GetSStringInfo(LEN_USER_ARTIST_002)

	PreCreateString_4580		= GetSStringInfo(LEN_USER_ARTIST_003)

	PreCreateString_4581		= GetSStringInfo(LEN_LEGEND_MAGETION_001)

	PreCreateString_4582		= GetSStringInfo(LEN_LEGEND_MAGETION_002)

	PreCreateString_4583		= GetSStringInfo(LEN_LEGEND_MAGETION_003)

	PreCreateString_4584		= GetSStringInfo(LEN_UNIQUE_MAGETION_001)

	PreCreateString_4585		= GetSStringInfo(LEN_UNIQUE_MAGETION_002)

	PreCreateString_4586		= GetSStringInfo(LEN_UNIQUE_MAGETION_003)

	PreCreateString_4590		= GetSStringInfo(LEN_USER_THIEF_001)

	PreCreateString_4591		= GetSStringInfo(LEN_USER_THIEF_002)

	PreCreateString_4592		= GetSStringInfo(LEN_USER_THIEF_003)

	PreCreateString_4593		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_001 )

	PreCreateString_4594		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_002)

	PreCreateString_4595		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_003)

	PreCreateString_4596		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_004)

	PreCreateString_4597		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_005)

	PreCreateString_4598		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_006)

	PreCreateString_4599		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_007)

	PreCreateString_4600		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_008)

	PreCreateString_4601		= GetSStringInfo(LAN_GOLDENEGG_UPGRADESYSTEM_009)

	PreCreateString_4602		= GetSStringInfo(LAN_ULTIMATE_GodenIronWarrior_ABILITY1)

	PreCreateString_4603		= GetSStringInfo(LAN_ULTIMATE_GodenIronWarrior_ABILITY2)

	PreCreateString_4604		= GetSStringInfo(LAN_ULTIMATE_Samurai_ABILITY1)

	PreCreateString_4605		= GetSStringInfo(LAN_ULTIMATE_Samurai_ABILITY2)

	PreCreateString_4606		= GetSStringInfo(LAN_ULTIMATE_GATCHAMAN_SETABILITY_01)

	PreCreateString_4607		= GetSStringInfo(LAN_ULTIMATE_GATCHAMAN_SETABILITY_02)

	PreCreateString_4608		= GetSStringInfo(LAN_ULTIMATE_DarkAvenger_SETABILITY_01)

	PreCreateString_4609		= GetSStringInfo(LAN_ULTIMATE_DarkAvenger_SETABILITY_02)

	PreCreateString_4610		= GetSStringInfo(LAN_ULTIMATE_FORESTKEEPER_SETABILITY_01)

	PreCreateString_4611		= GetSStringInfo(LAN_ULTIMATE_FORESTKEEPER_SETABILITY_02)

	PreCreateString_4612		= GetSStringInfo(LAN_ULTIMATE_Shinobi_SETABILITY_01)

	PreCreateString_4613		= GetSStringInfo(LAN_ULTIMATE_Shinobi_SETABILITY_02)

	PreCreateString_4614		= GetSStringInfo(LEN_ULTIMATE_BLAZE_SET_001)

	PreCreateString_4615		= GetSStringInfo(LEN_ULTIMATE_BLAZE_SET_002)

	PreCreateString_4616		= GetSStringInfo(LEN_ULTIMATE_BLAZE_SET_003)

	PreCreateString_4617		= GetSStringInfo(LEN_ULTIMATE_MAGETION_001)

	PreCreateString_4618		= GetSStringInfo(LEN_ULTIMATE_MAGETION_002)

	PreCreateString_4619		= GetSStringInfo(LEN_ULTIMATE_MAGETION_003)

	PreCreateString_4620		= GetSStringInfo(LAN_PLAY_TIME_EVENT_001)

	PreCreateString_4621		= GetSStringInfo(LAN_MEGASHOP_MESSAGE_001)

	PreCreateString_4622		= GetSStringInfo(LEN_SILVERKNIGHT_001)

	PreCreateString_4623		= GetSStringInfo(LEN_SILVERKNIGHT_002)

	PreCreateString_4624		= GetSStringInfo(LEN_SILVERKNIGHT_003)

	PreCreateString_4625		= GetSStringInfo(LAN_LEGEND_WUKONG_001)

	PreCreateString_4626		= GetSStringInfo(LAN_LEGEND_WUKONG_002)

	PreCreateString_4627		= GetSStringInfo(LAN_LEGEND_WUKONG_003)

	PreCreateString_4628		= GetSStringInfo(LAN_UNIQUE_WUKONG_001)

	PreCreateString_4629		= GetSStringInfo(LAN_UNIQUE_WUKONG_002)

	PreCreateString_4630		= GetSStringInfo(LAN_UNIQUE_WUKONG_003)

	PreCreateString_4631		= GetSStringInfo(LAN_ULTIMATE_WUKONG_001)

	PreCreateString_4632		= GetSStringInfo(LAN_ULTIMATE_WUKONG_002)

	PreCreateString_4633		= GetSStringInfo(LEN_HUNTING_FIELD_IMPROVEMENT_001)

	PreCreateString_4634		= GetSStringInfo(LAN_CLOWN_EVENT_MESSAGE_001)

	PreCreateString_4635		= GetSStringInfo(LAN_LUA_BATTLEROOM_MAP15)

	PreCreateString_4636		= GetSStringInfo(LAN_COSTOM_CAT_001)

	PreCreateString_4637		= GetSStringInfo(LAN_COSTOM_CAT_002)

	PreCreateString_4638		= GetSStringInfo(LAN_COSTOM_CAT_003)

	PreCreateString_4639		= GetSStringInfo(LAN_TRADE_CHAT_001)

	PreCreateString_4640		= GetSStringInfo(LAN_2013_MOMDAY_TITLE_001)

	PreCreateString_4641		= GetSStringInfo(LAN_2013_MOMDAY_STORY_001)

	PreCreateString_4642		= GetSStringInfo(LAN_2013_MOMDAY_DISCRIPTION_001)

	PreCreateString_4643		= GetSStringInfo(LAN_2013_MOMDAY_PROGRESS_001)

	PreCreateString_4644		= GetSStringInfo(LAN_2013_MOMDAY_PROGRESS_002)

	PreCreateString_4645		= GetSStringInfo(LAN_2013_MOMDAY_COMPLETION_001)

	PreCreateString_4646		= GetSStringInfo(LAN_CLUB_WITHDRAWAL_001)

	PreCreateString_4647		= GetSStringInfo(LAN_ENUM_TEST_TOOL)

	PreCreateString_4648		= GetSStringInfo(LAN_ENUM_CHANGE_JOB)

	PreCreateString_4649		= GetSStringInfo(LAN_ENUM_ATTEND_EVENT)

	PreCreateString_4651		= GetSStringInfo(LAN_GRAVE_NPC_NAME_001)

	PreCreateString_4652		= GetSStringInfo(LAN_GRAVE_NPC_NAME_002)

	PreCreateString_4653		= GetSStringInfo(LAN_GRAVE_NPC_NAME_003)

	PreCreateString_4654		= GetSStringInfo(LAN_GRAVE_NPC_NAME_004)

	PreCreateString_4655		= GetSStringInfo(LAN_GRAVE_NPC_NAME_005)

	PreCreateString_4656		= GetSStringInfo(LAN_GRAVE_NPC_NAME_006)

	PreCreateString_4657		= GetSStringInfo(LAN_GRAVE_NPC_STORY_001)

	PreCreateString_4658		= GetSStringInfo(LAN_GRAVE_NPC_STORY_002)

	PreCreateString_4659		= GetSStringInfo(LAN_GRAVE_NPC_STORY_003)

	PreCreateString_4660		= GetSStringInfo(LAN_GRAVE_NPC_STORY_004)

	PreCreateString_4661		= GetSStringInfo(LAN_GRAVE_NPC_STORY_005)

	PreCreateString_4662		= GetSStringInfo(LAN_DSCYTHE_ESKILL_001)

	PreCreateString_4663		= GetSStringInfo(LAN_DSCYTHE_SET_LEGEND_001)

	PreCreateString_4664		= GetSStringInfo(LAN_DSCYTHE_SET_LEGEND_002)

	PreCreateString_4665		= GetSStringInfo(LAN_DSCYTHE_SET_UNIQUE_001)

	PreCreateString_4666		= GetSStringInfo(LAN_DSCYTHE_SET_UNIQUE_002)

	PreCreateString_4667		= GetSStringInfo(LAN_DSCYTHE_SET_UNIQUE_003)

	PreCreateString_4668		= GetSStringInfo(LAN_DSCYTHE_SET_ULTIMATE_001)

	PreCreateString_4669		= GetSStringInfo(LAN_DSCYTHE_SET_ULTIMATE_002)

	PreCreateString_4670		= GetSStringInfo(LAN_ONEPEACE_ITEM_SET_001)

	PreCreateString_4671		= GetSStringInfo(LAN_ONEPEACE_ITEM_SET_002)

	PreCreateString_4672		= GetSStringInfo(LAN_ONEPEACE_ITEM_SET_003)

	PreCreateString_4673		= GetSStringInfo(LEN_ULTIMATE_GOLEM_SET_001)

	PreCreateString_4674		= GetSStringInfo(LEN_ULTIMATE_GOLEM_SET_002)

	PreCreateString_4675		= GetSStringInfo(LEN_ULTIMATE_GOLEM_SET_003)

	PreCreateString_4676		= GetSStringInfo(LEN_LEGEND_GOLEM_SET_001)

	PreCreateString_4677		= GetSStringInfo(LEN_LEGEND_GOLEM_SET_002)

	PreCreateString_4678		= GetSStringInfo(LEN_LEGEND_GOLEM_SET_003)

	PreCreateString_4679		= GetSStringInfo(LEN_RARE_GOLEM_SET_001)

	PreCreateString_4680		= GetSStringInfo(LEN_RARE_GOLEM_SET_002)

	PreCreateString_4681		= GetSStringInfo(LEN_RARE_GOLEM_SET_003)

	PreCreateString_4682		= GetSStringInfo(LEN_UNIQUE_GOLEM_SET_001)

	PreCreateString_4683		= GetSStringInfo(LEN_UNIQUE_GOLEM_SET_002)

	PreCreateString_4684		= GetSStringInfo(LEN_UNIQUE_GOLEM_SET_003)

	PreCreateString_4685		= GetSStringInfo(LEN_HIGH_GOLEM_SET_001)

	PreCreateString_4686		= GetSStringInfo(LEN_HIGH_GOLEM_SET_002)

	PreCreateString_4687		= GetSStringInfo(LEN_HIGH_GOLEM_SET_003)

	PreCreateString_4688		= GetSStringInfo(LEN_MEDIUM_GOLEM_SET_001)

	PreCreateString_4689		= GetSStringInfo(LEN_MEDIUM_GOLEM_SET_002)

	PreCreateString_4690		= GetSStringInfo(LEN_MEDIUM_GOLEM_SET_003)

	PreCreateString_4691		= GetSStringInfo(LEN_LOW_GOLEM_SET_001)

	PreCreateString_4692		= GetSStringInfo(LEN_LOW_GOLEM_SET_002)

	PreCreateString_4693		= GetSStringInfo(LEN_LOW_GOLEM_SET_003)

	PreCreateString_4694		= GetSStringInfo(LAN_ENUM_UI_ESPECIAL)

	PreCreateString_4695		= GetSStringInfo(LAN_ENUM_UI_NEWJOB)

	PreCreateString_4696		= GetSStringInfo(LAN_ENUM_EMAIL_SYSTEM)

	PreCreateString_4711		= GetSStringInfo(LAN_ENUM_CHARACTER_INFO)

	PreCreateString_4712		= GetSStringInfo(LAN_MOM_DAD_SET)

	PreCreateString_4713		= GetSStringInfo(LAN_GRAVE_SKELETON_GENERAL)

	PreCreateString_4714		= GetSStringInfo(LAN_GRAVE_SKELETON_GUARDIAN)

	PreCreateString_4715		= GetSStringInfo(LAN_GRAVE_SKELETON_MINER)

	PreCreateString_4716		= GetSStringInfo(LAN_GRAVE_SKELETON)

	PreCreateString_4717		= GetSStringInfo(LAN_GRAVE_SKELETON_WARRIOR)

	PreCreateString_4718		= GetSStringInfo(LAN_GRAVE_SKELETON_DEMON)

	PreCreateString_4719		= GetSStringInfo(LAN_GRAVE_DEATH_METAL_SKELETON)

	PreCreateString_4721		= GetSStringInfo(LAN_2ND_GRAVE_NPC_STORY_001)

	PreCreateString_4722		= GetSStringInfo(LAN_2ND_GRAVE_NPC_STORY_002)

	PreCreateString_4723		= GetSStringInfo(LAN_2ND_GRAVE_NPC_STORY_003)

	PreCreateString_4724		= GetSStringInfo(LAN_2ND_GRAVE_NPC_STORY_004)

	PreCreateString_4725		= GetSStringInfo(LAN_2ND_GRAVE_NPC_STORY_005)

	PreCreateString_4726		= GetSStringInfo(LAN_PVP_MODE_DUALMATCH_NAME)

	PreCreateString_4727		= GetSStringInfo(LAN_QUANTITY_COUNT)

	PreCreateString_4728		= GetSStringInfo(LAN_ANGEL_SET)

	PreCreateString_4729		= GetSStringInfo(LAN_DEVIL_SET)

	PreCreateString_4730		= GetSStringInfo(LAN_GOLD_JAGUA_SET)

	PreCreateString_4731		= GetSStringInfo(LAN_RED_JAGUA_SET)

	PreCreateString_4732		= GetSStringInfo(LAN_PURPLE_RICH_SET)

	PreCreateString_4733		= GetSStringInfo(LAN_BURGUNDY_RICH_SET)

	PreCreateString_4734		= GetSStringInfo(LAN_ORANGE_LADYBUG_SET)

	PreCreateString_4735		= GetSStringInfo(LAN_RED_LADYBUG_SET)

	PreCreateString_4736		= GetSStringInfo(LAN_RED_SCARA_SET)

	PreCreateString_4737		= GetSStringInfo(LAN_BLUE_SCARA_SET)

	PreCreateString_4738		= GetSStringInfo(LAN_ENUM_TRANSFORM_MICHEL)

	PreCreateString_4739		= GetSStringInfo(LAN_ENUM_TRANSFORM_MUCA)

	PreCreateString_4740		= GetSStringInfo(LAN_COSTUME_SET1_001)

	PreCreateString_4741		= GetSStringInfo(LAN_COSTUME_SET1_002)

	PreCreateString_4742		= GetSStringInfo(LAN_COSTUME_SET1_003)

	PreCreateString_4743		= GetSStringInfo(LAN_ITEM_UNSEALED)

	PreCreateString_4744		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_113)

	PreCreateString_4745		= GetSStringInfo(LAN_OVERLOAD_SET_01)

	PreCreateString_4746		= GetSStringInfo(LAN_OVERLOAD_SET_02)

	PreCreateString_4747		= GetSStringInfo(LAN_OVERLOAD_SKILL)

	PreCreateString_4748		= GetSStringInfo(LAN_ENUM_PVPMODE_BOOM)

	PreCreateString_4749		= GetSStringInfo(LAN_COSTUME_NATIVE_SET1_001)

	PreCreateString_4750		= GetSStringInfo(LAN_COSTUME_NATIVE_SET1_002)

	PreCreateString_4751		= GetSStringInfo(LAN_COSTUME_NATIVE_SET1_003)

	PreCreateString_4752		= GetSStringInfo(LAN_ARCADE_LEVEL_POPUP_001)

	PreCreateString_4753		= GetSStringInfo(LAN_ARCADE_LEVEL_POPUP_002)

	PreCreateString_4782		= GetSStringInfo(LEN_BLACKKNIGHT_004)

	PreCreateString_4783		= GetSStringInfo(LEN_BLACKKNIGHT_005)

	PreCreateString_4784		= GetSStringInfo(LEN_BLACKKNIGHT_006)

	PreCreateString_4785		= GetSStringInfo(LEN_BLACKKNIGHT_007)

	PreCreateString_4786		= GetSStringInfo(LEN_BLACKKNIGHT_008)

	PreCreateString_4787		= GetSStringInfo(LEN_BLACKKNIGHT_009)

	PreCreateString_4788		= GetSStringInfo(LEN_UI_ENUM_BASIC_001)

	PreCreateString_4789		= GetSStringInfo(LEN_CHANGE_NPC_SUPERVISOR)

	PreCreateString_4790		= GetSStringInfo(LAN_ENUM_EMAIL_ATTACHMENT_MESSAGE)

	PreCreateString_4791		= GetSStringInfo(LAN_SWIMMINGSUIT_SET_01)

	PreCreateString_4792		= GetSStringInfo(LAN_SWIMMINGSUIT_SET_02)

	PreCreateString_4793		= GetSStringInfo(LAN_SWIMMINGSUIT_SET_03)

	PreCreateString_4794		= GetSStringInfo(LAN_GRAVE_GIANT_STATUE)

	PreCreateString_4795		= GetSStringInfo(LAN_GRAVE_MUD_SOLDIER)

	PreCreateString_4796		= GetSStringInfo(LAN_GRAVE_MUD_KNIGHT)

	PreCreateString_4797		= GetSStringInfo(LAN_GRAVE_MUD_ARCHER)

	PreCreateString_4798		= GetSStringInfo(LAN_GRAVE_MUD_SWORDSMAN)

	PreCreateString_4799		= GetSStringInfo(LAN_GRAVE_TWO_SWORDS_WARRIOR)

	PreCreateString_4800		= GetSStringInfo(LAN_GRAVE_MUD_CAPTAIN)

	PreCreateString_4801		= GetSStringInfo(LAN_3ND_GRAVE_NPC_STORY_001)

	PreCreateString_4802		= GetSStringInfo(LAN_3ND_GRAVE_NPC_STORY_002)

	PreCreateString_4803		= GetSStringInfo(LAN_3ND_GRAVE_NPC_STORY_003)

	PreCreateString_4804		= GetSStringInfo(LAN_3ND_GRAVE_NPC_STORY_004)

	PreCreateString_4805		= GetSStringInfo(LAN_3ND_GRAVE_NPC_STORY_005)

	PreCreateString_4806		= GetSStringInfo(LAN_CHUTCHA_SET_01)

	PreCreateString_4807		= GetSStringInfo(LAN_COSTUME_RACER_SET1_001)

	PreCreateString_4808		= GetSStringInfo(LAN_COSTUME_RACER_SET1_002)

	PreCreateString_4809		= GetSStringInfo(LAN_COSTUME_RACER_SET1_003)

	PreCreateString_4810		= GetSStringInfo(LAN_2014_GUN_01)

	PreCreateString_4811		= GetSStringInfo(LAN_PIRATE_SET_01)

	PreCreateString_4812		= GetSStringInfo(LAN_PIRATE_SET_02)

	PreCreateString_4813		= GetSStringInfo(LAN_PIRATE_SET_03)

	PreCreateString_4814		= GetSStringInfo(LAN_CAT_SET_01)

	PreCreateString_4815		= GetSStringInfo(LAN_CAT_SET_02)

	PreCreateString_4816		= GetSStringInfo(LAN_CAT_SET_03)

	PreCreateString_4817		= GetSStringInfo(LAN_ARTIST_SET_01)

	PreCreateString_4818		= GetSStringInfo(LAN_ARTIST_SET_02)

	PreCreateString_4819		= GetSStringInfo(LAN_ARTIST_SET_03)

	PreCreateString_4820		= GetSStringInfo(LAN_JUMPING_POPUP_01)

	PreCreateString_4821		= GetSStringInfo(LAN_JUMPING_POPUP_02)

	PreCreateString_4822		= GetSStringInfo(LAN_JUMPING_POPUP_03)

	PreCreateString_4823		= GetSStringInfo(LAN_GRAVE_IMMORTAL_EMPEROR)

	PreCreateString_4824		= GetSStringInfo(LAN_4ND_GRAVE_NPC_STORY_001)

	PreCreateString_4825		= GetSStringInfo(LAN_4ND_GRAVE_NPC_STORY_002)

	PreCreateString_4826		= GetSStringInfo(LAN_DANCER_SET_01)

	PreCreateString_4827		= GetSStringInfo(LAN_DANCER_SET_02)

	PreCreateString_4828		= GetSStringInfo(LAN_DANCER_SET_03)

	PreCreateString_4829		= GetSStringInfo(LAN_COSTUME_SOCCER_SET1_001)

	PreCreateString_4830		= GetSStringInfo(LAN_COSTUME_SOCCER_SET1_002)

	PreCreateString_4831		= GetSStringInfo(LAN_COSTUME_SOCCER_SET1_003)

	PreCreateString_4832		= GetSStringInfo(LAN_COSTUME_Shark_SET1_001)

	PreCreateString_4833		= GetSStringInfo(LAN_COSTUME_Shark_SET1_002)

	PreCreateString_4834		= GetSStringInfo(LAN_COSTUME_Shark_SET1_003)

	PreCreateString_4835		= GetSStringInfo(LEN_CHANGE_NPC_DEATH_METAL)

	PreCreateString_4864		= GetSStringInfo(LAN_LEGEND_RIDER_SET_01)

	PreCreateString_4865		= GetSStringInfo(LAN_LEGEND_RIDER_SET_02)

	PreCreateString_4866		= GetSStringInfo(LAN_LEGEND_RIDER_SET_03)

	PreCreateString_4867		= GetSStringInfo(LAN_UNIQUE_RIDER_SET_01)

	PreCreateString_4868		= GetSStringInfo(LAN_UNIQUE_RIDER_SET_02)

	PreCreateString_4869		= GetSStringInfo(LAN_UNIQUE_RIDER_SET_03)

	PreCreateString_4870		= GetSStringInfo(LAN_ULTIMATE_RIDER_SET_01)

	PreCreateString_4871		= GetSStringInfo(LAN_ULTIMATE_RIDER_SET_02)

	PreCreateString_4872		= GetSStringInfo(LAN_ULTIMATE_RIDER_SET_03)

	PreCreateString_4873		= GetSStringInfo(LAN_COSTUME_SAMBA_SET1_001)

	PreCreateString_4874		= GetSStringInfo(LAN_COSTUME_SAMBA_SET1_002)

	PreCreateString_4875		= GetSStringInfo(LAN_COSTUME_SAMBA_SET1_003)

	PreCreateString_4876		= GetSStringInfo(LAN_EVENT_ESKILL_2014WORLDCUP_001)

	PreCreateString_4877		= GetSStringInfo(LAN_RARE_SAMURAI_SET_01)

	PreCreateString_4878		= GetSStringInfo(LAN_RARE_SAMURAI_SET_02)

	PreCreateString_4879		= GetSStringInfo(LAN_RARE_SAMURAI_SET_03)

	PreCreateString_4880		= GetSStringInfo(LAN_UNIQUE_SAMURAI_SET_01)

	PreCreateString_4881		= GetSStringInfo(LAN_UNIQUE_SAMURAI_SET_02)

	PreCreateString_4882		= GetSStringInfo(LAN_UNIQUE_SAMURAI_SET_03)

	PreCreateString_4883		= GetSStringInfo(LAN_GOLDENEGG_ESKILL_SAMURAI_001)

	PreCreateString_4884		= GetSStringInfo(LEN_CHANGE_NPC_GIANT_STATUE)

	PreCreateString_4885		= GetSStringInfo(LAN_COSTUME_BEACH_SET1_001)

	PreCreateString_4886		= GetSStringInfo(LAN_COSTUME_BEACH_SET1_002)

	PreCreateString_4887		= GetSStringInfo(LAN_COSTUME_BEACH_SET1_003)

	PreCreateString_4888		= GetSStringInfo(LAN_2014_WORLDCUP_SKILL_001)

	PreCreateString_4889		= GetSStringInfo(LAN_U_OTP_POPUP_001)

	PreCreateString_4890		= GetSStringInfo(LAN_U_OTP_POPUP_002)

	PreCreateString_4891		= GetSStringInfo(LAN_U_OTP_POPUP_003)

	PreCreateString_4892		= GetSStringInfo(LAN_COSTUME_CAT_SET1_001)

	PreCreateString_4893		= GetSStringInfo(LAN_COSTUME_CAT_SET1_002)

	PreCreateString_4894		= GetSStringInfo(LAN_COSTUME_CAT_SET1_003)

	PreCreateString_4895		= GetSStringInfo(LAN_COSTUME_ROYAL_SET1_001)

	PreCreateString_4896		= GetSStringInfo(LAN_COSTUME_ROYAL_SET1_002)

	PreCreateString_4897		= GetSStringInfo(LAN_COSTUME_ROYAL_SET1_003)

	PreCreateString_4898		= GetSStringInfo(LAN_RARE_PHOENIX_SET_01)

	PreCreateString_4899		= GetSStringInfo(LAN_RARE_PHOENIX_SET_02)

	PreCreateString_4900		= GetSStringInfo(LAN_RARE_PHOENIX_SET_03)

	PreCreateString_4901		= GetSStringInfo(LAN_UNIQUE_PHOENIX_SET_01)

	PreCreateString_4902		= GetSStringInfo(LAN_UNIQUE_PHOENIX_SET_02)

	PreCreateString_4903		= GetSStringInfo(LAN_UNIQUE_PHOENIX_SET_03)

	PreCreateString_4904		= GetSStringInfo(LAN_GOLDENEGG_ESKILL_PHOENIX_001)

	PreCreateString_4905		= GetSStringInfo(LAN_LEGEND_PALADIN_SET_01)

	PreCreateString_4906		= GetSStringInfo(LAN_LEGEND_PALADIN_SET_02)

	PreCreateString_4907		= GetSStringInfo(LAN_LEGEND_PALADIN_SET_03)

	PreCreateString_4908		= GetSStringInfo(LAN_UNIQUE_PALADIN_SET_01)

	PreCreateString_4909		= GetSStringInfo(LAN_UNIQUE_PALADIN_SET_02)

	PreCreateString_4910		= GetSStringInfo(LAN_UNIQUE_PALADIN_SET_03)

	PreCreateString_4911		= GetSStringInfo(LAN_ULTIMATE_PALADIN_SET_01)

	PreCreateString_4912		= GetSStringInfo(LAN_ULTIMATE_PALADIN_SET_02)

	PreCreateString_4913		= GetSStringInfo(LAN_ULTIMATE_PALADIN_SET_03)

	PreCreateString_4914		= GetSStringInfo(LAN_DIAMOND_RANKING_SET_02)

	PreCreateString_4915		= GetSStringInfo(LAN_DIAMOND_RANKING_SET_03)

	PreCreateString_4916		= GetSStringInfo(LAN_RUBY_RANKING_SET_02)

	PreCreateString_4917		= GetSStringInfo(LAN_RUBY_RANKING_SET_03)

	PreCreateString_4918		= GetSStringInfo(LAN_EMERALD_RANKING_SET_02)

	PreCreateString_4919		= GetSStringInfo(LAN_EMERALD_RANKING_SET_03)

	PreCreateString_4920		= GetSStringInfo(LAN_CLASSNAME_NINJA_001)

	PreCreateString_4921		= GetSStringInfo(LAN_COSTUME_GANGSI_SET1_001)

	PreCreateString_4922		= GetSStringInfo(LAN_COSTUME_ZBI_SET1_001)

	PreCreateString_4923		= GetSStringInfo(LAN_COSTUME_ZBI_SET1_002)

	PreCreateString_4924		= GetSStringInfo(LAN_COSTUME_ZBI_SET1_003)

	PreCreateString_4925		= GetSStringInfo(LAN_XENOCIDE_E_SKILL)

	PreCreateString_4926		= GetSStringInfo(LAN_XENOCIDE_ABILITY1)

	PreCreateString_4927		= GetSStringInfo(LAN_XENOCIDE_ABILITY2)

	PreCreateString_4928		= GetSStringInfo(LAN_COSTUME_SANTA_SET1_001)

	PreCreateString_4929		= GetSStringInfo(LAN_COSTUME_SANTA_SET1_002)

	PreCreateString_4930		= GetSStringInfo(LAN_COSTUME_SANTA_SET1_003)

	PreCreateString_4931		= GetSStringInfo(LAN_2014_CHRISTMAS_SET_01)

	PreCreateString_4932		= GetSStringInfo(LAN_2014_CHRISTMAS_SET_02)

	PreCreateString_4933		= GetSStringInfo(LAN_2014_CHRISTMAS_SET_03)

	PreCreateString_4934		= GetSStringInfo(LAN_RARE_DARKAVENGER_SET_01)

	PreCreateString_4935		= GetSStringInfo(LAN_RARE_DARKAVENGER_SET_02)

	PreCreateString_4936		= GetSStringInfo(LAN_RARE_DARKAVENGER_SET_03)

	PreCreateString_4937		= GetSStringInfo(LAN_UNIQUE_DARKAVENGER_SET_01)

	PreCreateString_4938		= GetSStringInfo(LAN_UNIQUE_DARKAVENGER_SET_02)

	PreCreateString_4939		= GetSStringInfo(LAN_UNIQUE_DARKAVENGER_SET_03)

	PreCreateString_4940		= GetSStringInfo(LAN_GOLDENEGG_ESKILL_DARKAVENGER_001)

	PreCreateString_4941		= GetSStringInfo(LAN_COSTUME_PHARAOH_SET1_001)

	PreCreateString_4942		= GetSStringInfo(LAN_COSTUME_PHARAOH_SET1_002)

	PreCreateString_4943		= GetSStringInfo(LAN_COSTUME_PHARAOH_SET1_003)

	PreCreateString_4944		= GetSStringInfo(LAN_COSTUME_FARMER_SET1_001)

	PreCreateString_4945		= GetSStringInfo(LAN_COSTUME_FARMER_SET1_002)

	PreCreateString_4946		= GetSStringInfo(LAN_COSTUME_FARMER_SET1_003)

	PreCreateString_5116		= GetSStringInfo(LAN_SEASON1_UNIQUE_COSTUME_SET_01)

	PreCreateString_5117		= GetSStringInfo(LAN_SEASON1_UNIQUE_COSTUME_SET_02)

	PreCreateString_5118		= GetSStringInfo(LAN_SEASON1_UNIQUE_COSTUME_SET_03)

	PreCreateString_5119		= GetSStringInfo(LAN_COMBINATION_ABILITY1)

	PreCreateString_5120		= GetSStringInfo(LAN_COMBINATION_ABILITY2)

	PreCreateString_5121		= GetSStringInfo(LAN_NOTACADE_TICKET_PARTY)

	PreCreateString_5122		= GetSStringInfo(LAN_ENG_CHARACNAME)

	PreCreateString_5123		= GetSStringInfo(LAN_LUA_WND_MESSENGER_28)

	PreCreateString_5124		= GetSStringInfo(LAN_UPGRADE_SKILL_LOCK)

	PreCreateString_5125		= GetSStringInfo(LAN_EVENT_EXP_BONUS_TIME)

	PreCreateString_5126		= GetSStringInfo(LAN_EVENT_ZEN_BONUS_TIME)

	PreCreateString_5127		= GetSStringInfo(LAN_EVENT_ALL_BONUS_TIME)

	PreCreateString_5128		= GetSStringInfo(LAN_KICK_USER)

	PreCreateString_5255		= GetSStringInfo(LAN_ANTI_AUTO_FAIL)

	PreCreateString_5256		= GetSStringInfo(LAN_LUA_TOTAL_ANNOUNCE_SKILL)

	PreCreateString_5257		= GetSStringInfo(LAN_MYSHOP_EVENT_NOTICE)

	PreCreateString_5258		= GetSStringInfo(LAN_MYSHOP_EVENT_DATE)

	PreCreateString_5259		= GetSStringInfo(LAN_Tire_ABILITY1)

	PreCreateString_5260		= GetSStringInfo(LAN_Mackerel_ABILITY1)

	PreCreateString_5261		= GetSStringInfo(LAN_Red_Dragon_Set_ABILITY1)

	PreCreateString_5262		= GetSStringInfo(LAN_Red_Dragon_Set_ABILITY2)

	PreCreateString_5263		= GetSStringInfo(LAN_Red_Dragon_Set_ABILITY3)

	PreCreateString_5264		= GetSStringInfo(LAN_Gold_Firer_ABILITY1)

	PreCreateString_5265		= GetSStringInfo(LAN_Gold_Firer_ABILITY2)

	PreCreateString_5266		= GetSStringInfo(LAN_Gold_Firer_ABILITY3)

	PreCreateString_5267		= GetSStringInfo(LAN_Silver_Firer_ABILITY1)

	PreCreateString_5268		= GetSStringInfo(LAN_Silver_Firer_ABILITY2)

	PreCreateString_5269		= GetSStringInfo(LAN_Silver_Firer_ABILITY3)

	PreCreateString_5277		= GetSStringInfo(LAN_Legend_Gold_Firer_Set_ABILITY1)

	PreCreateString_5278		= GetSStringInfo(LAN_Legend_Gold_Firer_Set_ABILITY2)

	PreCreateString_5279		= GetSStringInfo(LAN_Legend_Gold_Firer_Set_ABILITY3)

	PreCreateString_5286		= GetSStringInfo(LAN_CashDeco_01_Medium_Set_ABILITY1)

	PreCreateString_5287		= GetSStringInfo(LAN_CashDeco_01_High_Set_ABILITY1)

	PreCreateString_5288		= GetSStringInfo(LAN_CashDeco_01_Unique_Set_ABILITY1)

	PreCreateString_5289		= GetSStringInfo(LAN_CashCostume_01_Unique_Set_ABILITY1)

	PreCreateString_5290		= GetSStringInfo(LAN_CashCostume_01_Unique_Set_ABILITY2)

	PreCreateString_5291		= GetSStringInfo(LAN_CashCostume_01_Unique_Set_ABILITY3)

	PreCreateString_5292		= GetSStringInfo(LAN_Language_Option_Notice_01)

	PreCreateString_5301		= GetSStringInfo(LAN_Premium_Login_Notice_01)

	PreCreateString_5302		= GetSStringInfo(LAN_Premium_Login_Notice_02)

	PreCreateString_5303		= GetSStringInfo(LAN_Premium_Login_Notice_03)

	PreCreateString_5304		= GetSStringInfo(LAN_Black_Dragon_Set_ABILITY1)

	PreCreateString_5305		= GetSStringInfo(LAN_Black_Dragon_Set_ABILITY2)

	PreCreateString_5306		= GetSStringInfo(LAN_Black_Dragon_Set_ABILITY3)

	PreCreateString_5321		= GetSStringInfo(LAN_Phoenix_SET_01)

	PreCreateString_5322		= GetSStringInfo(LAN_Phoenix_SET_02)

	PreCreateString_5323		= GetSStringInfo(LAN_Phoenix_SET_03)

	PreCreateString_5324		= GetSStringInfo(LAN_Dark_Avenger_Rare_ABILITY1)

	PreCreateString_5325		= GetSStringInfo(LAN_Dark_Avenger_Rare_ABILITY2)

	PreCreateString_5326		= GetSStringInfo(LAN_Dark_Avenger_Rare_ABILITY3)

	PreCreateString_5327		= GetSStringInfo(LAN_Dark_Avenger_Unique_ABILITY1)

	PreCreateString_5328		= GetSStringInfo(LAN_Dark_Avenger_Unique_ABILITY2)

	PreCreateString_5329		= GetSStringInfo(LAN_Dark_Avenger_Unique_ABILITY3)

	PreCreateString_5336		= GetSStringInfo(LAN_LUA_PARTY_HARD)

	PreCreateString_5337		= GetSStringInfo(LAN_WhiteValkyria_Set_ABILITY1)

	PreCreateString_5338		= GetSStringInfo(LAN_WhiteValkyria_Set_ABILITY2)

	PreCreateString_5339		= GetSStringInfo(LAN_WhiteValkyria_Set_ABILITY3)

	PreCreateString_5340		= GetSStringInfo(LAN_BlackValkyria_Set_ABILITY1)

	PreCreateString_5341		= GetSStringInfo(LAN_BlackValkyria_Set_ABILITY2)

	PreCreateString_5342		= GetSStringInfo(LAN_BlackValkyria_Set_ABILITY3)

	PreCreateString_5343		= GetSStringInfo(LAN_Premium_Login_Notice_04)

	PreCreateString_5344		= GetSStringInfo(LAN_Dark_Avenger_Legend_ABILITY1)

	PreCreateString_5345		= GetSStringInfo(LAN_Dark_Avenger_Legend_ABILITY2)

	PreCreateString_5346		= GetSStringInfo(LAN_Dark_Avenger_Legend_ABILITY3)

	PreCreateString_5347		= GetSStringInfo(LAN_2vs2_team_tournament_Notice_01)

	PreCreateString_5348		= GetSStringInfo(LAN_New_Gold_egg_ABILITY1)

	PreCreateString_5349		= GetSStringInfo(LAN_New_Gold_egg_Rare_ABILITY2)

	PreCreateString_5350		= GetSStringInfo(LAN_New_Gold_egg_Rare_ABILITY3)

	PreCreateString_5351		= GetSStringInfo(LAN_New_Gold_egg_unique_ABILITY1)

	PreCreateString_5352		= GetSStringInfo(LAN_New_Gold_egg_unique_ABILITY2)

	PreCreateString_5353		= GetSStringInfo(LAN_New_Gold_egg_unique_ABILITY3)

	PreCreateString_5354		= GetSStringInfo(LAN_Deco_Rare_3Set_ABILITY1)

	PreCreateString_5355		= GetSStringInfo(LAN_Deco_Rare_3Set_ABILITY2)

	PreCreateString_5356		= GetSStringInfo(LAN_Deco_Rare_3Set_ABILITY3)

	PreCreateString_5357		= GetSStringInfo(LAN_Deco_Rare_3Set_ABILITY4)

	PreCreateString_5358		= GetSStringInfo(LAN_Deco_Rare_3Set_ABILITY5)

	PreCreateString_5359		= GetSStringInfo(LAN_Deco_Rare_3Set_ABILITY6)

	PreCreateString_5360		= GetSStringInfo(LAN_Deco_Unique_3Set_ABILITY1)

	PreCreateString_5361		= GetSStringInfo(LAN_Deco_Unique_3Set_ABILITY2)

	PreCreateString_5362		= GetSStringInfo(LAN_Deco_Unique_3Set_ABILITY3)

	PreCreateString_5363		= GetSStringInfo(LAN_Deco_Unique_3Set_ABILITY4)

	PreCreateString_5364		= GetSStringInfo(LAN_Deco_Unique_3Set_ABILITY5)

	PreCreateString_5365		= GetSStringInfo(LAN_Deco_Unique_3Set_ABILITY6)

	PreCreateString_5366		= GetSStringInfo(LAN_Deco_High_3Set_ABILITY1)

	PreCreateString_5367		= GetSStringInfo(LAN_Deco_High_3Set_ABILITY2)

	PreCreateString_5368		= GetSStringInfo(LAN_Deco_High_3Set_ABILITY3)

	PreCreateString_5369		= GetSStringInfo(LAN_Deco_High_3Set_ABILITY4)

	PreCreateString_5370		= GetSStringInfo(LAN_Deco_High_3Set_ABILITY5)

	PreCreateString_5371		= GetSStringInfo(LAN_Deco_High_3Set_ABILITY6)

	PreCreateString_5387		= GetSStringInfo(LAN_MageFighter_Set_ABILITY1)

	PreCreateString_5388		= GetSStringInfo(LAN_MageFighter_Set_ABILITY2)

	PreCreateString_5389		= GetSStringInfo(LAN_MageFighter_Set_ABILITY3)

	PreCreateString_5390		= GetSStringInfo(LEN_BLAZE_SET_007)

	PreCreateString_5391		= GetSStringInfo(LEN_BLAZE_SET_008)

	PreCreateString_5392		= GetSStringInfo(LEN_BLAZE_SET_009)

	PreCreateString_5407		= GetSStringInfo(LAN_SCRAMBLE_NOTIFY_1)

	PreCreateString_5408		= GetSStringInfo(LAN_SCRAMBLE_NOTIFY_2)

	PreCreateString_5409		= GetSStringInfo(LAN_SCRAMBLE_NOTIFY_3)

	PreCreateString_5410		= GetSStringInfo(LAN_NEWCollection_Adventure_Low_set3)

	PreCreateString_5411		= GetSStringInfo(LAN_NEWCollection_Adventure_Low_set6)

	PreCreateString_5412		= GetSStringInfo(LAN_NEWCollection_Adventure_Low_set9)

	PreCreateString_5413		= GetSStringInfo(LAN_NEWCollection_Adventure_Medium_set3)

	PreCreateString_5414		= GetSStringInfo(LAN_NEWCollection_Adventure_Medium_set6)

	PreCreateString_5415		= GetSStringInfo(LAN_NEWCollection_Adventure_Medium_set9)

	PreCreateString_5416		= GetSStringInfo(LAN_NEWCollection_Adventure_High_set3)

	PreCreateString_5417		= GetSStringInfo(LAN_NEWCollection_Adventure_High_set6)

	PreCreateString_5418		= GetSStringInfo(LAN_NEWCollection_Adventure_High_set9)

	PreCreateString_5419		= GetSStringInfo(LAN_NEWCollection_Adventure_Unique_set3)

	PreCreateString_5420		= GetSStringInfo(LAN_NEWCollection_Adventure_Unique_set6)

	PreCreateString_5421		= GetSStringInfo(LAN_NEWCollection_Adventure_Unique_set9)

	PreCreateString_5422		= GetSStringInfo(LAN_NEWCollection_Adventure_Rare_set3)

	PreCreateString_5423		= GetSStringInfo(LAN_NEWCollection_Adventure_Rare_set6)

	PreCreateString_5424		= GetSStringInfo(LAN_NEWCollection_Adventure_Rare_set9)

	PreCreateString_5425		= GetSStringInfo(LAN_NEWCollection_Adventure_Legend_set3)

	PreCreateString_5426		= GetSStringInfo(LAN_NEWCollection_Adventure_Legend_set6)

	PreCreateString_5427		= GetSStringInfo(LAN_NEWCollection_Adventure_Legend_set9)

	PreCreateString_5428		= GetSStringInfo(LAN_NEWCollection_Pierrot_Low_set3)

	PreCreateString_5429		= GetSStringInfo(LAN_NEWCollection_Pierrot_Low_set6)

	PreCreateString_5430		= GetSStringInfo(LAN_NEWCollection_Pierrot_Low_set9)

	PreCreateString_5431		= GetSStringInfo(LAN_NEWCollection_Pierrot_Medium_set3)

	PreCreateString_5432		= GetSStringInfo(LAN_NEWCollection_Pierrot_Medium_set6)

	PreCreateString_5433		= GetSStringInfo(LAN_NEWCollection_Pierrot_Medium_set9)

	PreCreateString_5434		= GetSStringInfo(LAN_NEWCollection_Pierrot_High_set3)

	PreCreateString_5435		= GetSStringInfo(LAN_NEWCollection_Pierrot_High_set6)

	PreCreateString_5436		= GetSStringInfo(LAN_NEWCollection_Pierrot_High_set9)

	PreCreateString_5437		= GetSStringInfo(LAN_NEWCollection_Pierrot_Unique_set3)

	PreCreateString_5438		= GetSStringInfo(LAN_NEWCollection_Pierrot_Unique_set6)

	PreCreateString_5439		= GetSStringInfo(LAN_NEWCollection_Pierrot_Unique_set9)

	PreCreateString_5440		= GetSStringInfo(LAN_NEWCollection_Pierrot_Rare_set3)

	PreCreateString_5441		= GetSStringInfo(LAN_NEWCollection_Pierrot_Rare_set6)

	PreCreateString_5442		= GetSStringInfo(LAN_NEWCollection_Pierrot_Rare_set9)

	PreCreateString_5443		= GetSStringInfo(LAN_NEWCollection_Pierrot_Legend_set3)

	PreCreateString_5444		= GetSStringInfo(LAN_NEWCollection_Pierrot_Legend_set6)

	PreCreateString_5445		= GetSStringInfo(LAN_NEWCollection_Pierrot_Legend_set9)

	PreCreateString_5446		= GetSStringInfo(LAN_NEWCollection_Rocker_Low_set3)

	PreCreateString_5447		= GetSStringInfo(LAN_NEWCollection_Rocker_Low_set6)

	PreCreateString_5448		= GetSStringInfo(LAN_NEWCollection_Rocker_Low_set9)

	PreCreateString_5449		= GetSStringInfo(LAN_NEWCollection_Rocker_Medium_set3)

	PreCreateString_5450		= GetSStringInfo(LAN_NEWCollection_Rocker_Medium_set6)

	PreCreateString_5451		= GetSStringInfo(LAN_NEWCollection_Rocker_Medium_set9)

	PreCreateString_5452		= GetSStringInfo(LAN_NEWCollection_Rocker_High_set3)

	PreCreateString_5453		= GetSStringInfo(LAN_NEWCollection_Rocker_High_set6)

	PreCreateString_5454		= GetSStringInfo(LAN_NEWCollection_Rocker_High_set9)

	PreCreateString_5455		= GetSStringInfo(LAN_NEWCollection_Rocker_Unique_set3)

	PreCreateString_5456		= GetSStringInfo(LAN_NEWCollection_Rocker_Unique_set6)

	PreCreateString_5457		= GetSStringInfo(LAN_NEWCollection_Rocker_Unique_set9)

	PreCreateString_5458		= GetSStringInfo(LAN_NEWCollection_Rocker_Rare_set3)

	PreCreateString_5459		= GetSStringInfo(LAN_NEWCollection_Rocker_Rare_set6)

	PreCreateString_5460		= GetSStringInfo(LAN_NEWCollection_Rocker_Rare_set9)

	PreCreateString_5461		= GetSStringInfo(LAN_NEWCollection_Rocker_Legend_set3)

	PreCreateString_5462		= GetSStringInfo(LAN_NEWCollection_Rocker_Legend_set6)

	PreCreateString_5463		= GetSStringInfo(LAN_NEWCollection_Rocker_Legend_set9)

	PreCreateString_5464		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Low_set3)

	PreCreateString_5465		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Low_set6)

	PreCreateString_5466		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Low_set9)

	PreCreateString_5467		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Medium_set3)

	PreCreateString_5468		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Medium_set6)

	PreCreateString_5469		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Medium_set9)

	PreCreateString_5470		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_High_set3)

	PreCreateString_5471		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_High_set6)

	PreCreateString_5472		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_High_set9)

	PreCreateString_5473		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Unique_set3)

	PreCreateString_5474		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Unique_set6)

	PreCreateString_5475		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Unique_set9)

	PreCreateString_5476		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Rare_set3)

	PreCreateString_5477		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Rare_set6)

	PreCreateString_5478		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Rare_set9)

	PreCreateString_5479		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Legend_set3)

	PreCreateString_5480		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Legend_set6)

	PreCreateString_5481		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Legend_set9)

	PreCreateString_5482		= GetSStringInfo(LAN_NEWCollection_Invertor_Low_set3)

	PreCreateString_5483		= GetSStringInfo(LAN_NEWCollection_Invertor_Low_set6)

	PreCreateString_5484		= GetSStringInfo(LAN_NEWCollection_Invertor_Low_set9)

	PreCreateString_5485		= GetSStringInfo(LAN_NEWCollection_Invertor_Medium_set3)

	PreCreateString_5486		= GetSStringInfo(LAN_NEWCollection_Invertor_Medium_set6)

	PreCreateString_5487		= GetSStringInfo(LAN_NEWCollection_Invertor_Medium_set9)

	PreCreateString_5488		= GetSStringInfo(LAN_NEWCollection_Invertor_High_set3)

	PreCreateString_5489		= GetSStringInfo(LAN_NEWCollection_Invertor_High_set6)

	PreCreateString_5490		= GetSStringInfo(LAN_NEWCollection_Invertor_High_set9)

	PreCreateString_5491		= GetSStringInfo(LAN_NEWCollection_Invertor_Unique_set3)

	PreCreateString_5492		= GetSStringInfo(LAN_NEWCollection_Invertor_Unique_set6)

	PreCreateString_5493		= GetSStringInfo(LAN_NEWCollection_Invertor_Unique_set9)

	PreCreateString_5494		= GetSStringInfo(LAN_NEWCollection_Invertor_Rare_set3)

	PreCreateString_5495		= GetSStringInfo(LAN_NEWCollection_Invertor_Rare_set6)

	PreCreateString_5496		= GetSStringInfo(LAN_NEWCollection_Invertor_Rare_set9)

	PreCreateString_5497		= GetSStringInfo(LAN_NEWCollection_Invertor_Legend_set3)

	PreCreateString_5498		= GetSStringInfo(LAN_NEWCollection_Invertor_Legend_set6)

	PreCreateString_5499		= GetSStringInfo(LAN_NEWCollection_Invertor_Legend_set9)

	PreCreateString_5500		= GetSStringInfo(LAN_NEWCollection_General_Low_set3)

	PreCreateString_5501		= GetSStringInfo(LAN_NEWCollection_General_Low_set6)

	PreCreateString_5502		= GetSStringInfo(LAN_NEWCollection_General_Low_set9)

	PreCreateString_5503		= GetSStringInfo(LAN_NEWCollection_General_Medium_set3)

	PreCreateString_5504		= GetSStringInfo(LAN_NEWCollection_General_Medium_set6)

	PreCreateString_5505		= GetSStringInfo(LAN_NEWCollection_General_Medium_set9)

	PreCreateString_5506		= GetSStringInfo(LAN_NEWCollection_General_High_set3)

	PreCreateString_5507		= GetSStringInfo(LAN_NEWCollection_General_High_set6)

	PreCreateString_5508		= GetSStringInfo(LAN_NEWCollection_General_High_set9)

	PreCreateString_5509		= GetSStringInfo(LAN_NEWCollection_General_Unique_set3)

	PreCreateString_5510		= GetSStringInfo(LAN_NEWCollection_General_Unique_set6)

	PreCreateString_5511		= GetSStringInfo(LAN_NEWCollection_General_Unique_set9)

	PreCreateString_5512		= GetSStringInfo(LAN_NEWCollection_General_Rare_set3)

	PreCreateString_5513		= GetSStringInfo(LAN_NEWCollection_General_Rare_set6)

	PreCreateString_5514		= GetSStringInfo(LAN_NEWCollection_General_Rare_set9)

	PreCreateString_5515		= GetSStringInfo(LAN_NEWCollection_General_Legend_set3)

	PreCreateString_5516		= GetSStringInfo(LAN_NEWCollection_General_Legend_set6)

	PreCreateString_5517		= GetSStringInfo(LAN_NEWCollection_General_Legend_set9)

	PreCreateString_5518		= GetSStringInfo(LAN_NEWCollection_Hunter_Low_set3)

	PreCreateString_5519		= GetSStringInfo(LAN_NEWCollection_Hunter_Low_set6)

	PreCreateString_5520		= GetSStringInfo(LAN_NEWCollection_Hunter_Low_set9)

	PreCreateString_5521		= GetSStringInfo(LAN_NEWCollection_Hunter_Medium_set3)

	PreCreateString_5522		= GetSStringInfo(LAN_NEWCollection_Hunter_Medium_set6)

	PreCreateString_5523		= GetSStringInfo(LAN_NEWCollection_Hunter_Medium_set9)

	PreCreateString_5524		= GetSStringInfo(LAN_NEWCollection_Hunter_High_set3)

	PreCreateString_5525		= GetSStringInfo(LAN_NEWCollection_Hunter_High_set6)

	PreCreateString_5526		= GetSStringInfo(LAN_NEWCollection_Hunter_High_set9)

	PreCreateString_5527		= GetSStringInfo(LAN_NEWCollection_Hunter_Unique_set3)

	PreCreateString_5528		= GetSStringInfo(LAN_NEWCollection_Hunter_Unique_set6)

	PreCreateString_5529		= GetSStringInfo(LAN_NEWCollection_Hunter_Unique_set9)

	PreCreateString_5530		= GetSStringInfo(LAN_NEWCollection_Hunter_Rare_set3)

	PreCreateString_5531		= GetSStringInfo(LAN_NEWCollection_Hunter_Rare_set6)

	PreCreateString_5532		= GetSStringInfo(LAN_NEWCollection_Hunter_Rare_set9)

	PreCreateString_5533		= GetSStringInfo(LAN_NEWCollection_Hunter_Legend_set3)

	PreCreateString_5534		= GetSStringInfo(LAN_NEWCollection_Hunter_Legend_set6)

	PreCreateString_5535		= GetSStringInfo(LAN_NEWCollection_Hunter_Legend_set9)

	PreCreateString_5536		= GetSStringInfo(LAN_NEWCollection_Special_Costume_Set3)

	PreCreateString_5537		= GetSStringInfo(LAN_NEWCollection_Special_Costume_Set6)

	PreCreateString_5538		= GetSStringInfo(LAN_newShinobi_Legend_Set3)

	PreCreateString_5539		= GetSStringInfo(LAN_newShinobi_Legend_Set6)

	PreCreateString_5540		= GetSStringInfo(LAN_newShinobi_Rare_Set3)

	PreCreateString_5541		= GetSStringInfo(LAN_newShinobi_Rare_Set6)

	PreCreateString_5542		= GetSStringInfo(LAN_newShinobi_Unique_Set3)

	PreCreateString_5543		= GetSStringInfo(LAN_newShinobi_Unique_Set6)

	PreCreateString_5544		= GetSStringInfo(LAN_newShinobi_Unique_Set9)

	PreCreateString_5545		= GetSStringInfo(LAN_newWukong_Legend_Set3)

	PreCreateString_5546		= GetSStringInfo(LAN_newWukong_Legend_Set6)

	PreCreateString_5547		= GetSStringInfo(LAN_newWukong_Rare_Set3)

	PreCreateString_5548		= GetSStringInfo(LAN_newWukong_Rare_Set6)

	PreCreateString_5549		= GetSStringInfo(LAN_newWukong_Unique_Set3)

	PreCreateString_5550		= GetSStringInfo(LAN_newWukong_Unique_Set6)

	PreCreateString_5551		= GetSStringInfo(LAN_newWukong_Unique_Set9)

	PreCreateString_5552		= GetSStringInfo(LAN_newMagetion_Gold_Legend_Set3)

	PreCreateString_5553		= GetSStringInfo(LAN_newMagetion_Gold_Legend_Set6)

	PreCreateString_5554		= GetSStringInfo(LAN_newMagetion_Gold_Rare_Set3)

	PreCreateString_5555		= GetSStringInfo(LAN_newMagetion_Gold_Rare_Set6)

	PreCreateString_5556		= GetSStringInfo(LAN_newMagetion_Gold_Unique_Set3)

	PreCreateString_5557		= GetSStringInfo(LAN_newMagetion_Gold_Unique_Set6)

	PreCreateString_5558		= GetSStringInfo(LAN_newMagetion_Gold_Unique_Set9)

	PreCreateString_5559		= GetSStringInfo(LAN_newForest_Legend_Set3)

	PreCreateString_5560		= GetSStringInfo(LAN_newForest_Legend_Set6)

	PreCreateString_5561		= GetSStringInfo(LAN_newForest_Rare_Set3)

	PreCreateString_5562		= GetSStringInfo(LAN_newForest_Rare_Set6)

	PreCreateString_5563		= GetSStringInfo(LAN_newForest_Unique_Set3)

	PreCreateString_5564		= GetSStringInfo(LAN_newForest_Unique_Set6)

	PreCreateString_5565		= GetSStringInfo(LAN_newForest_Unique_Set9)

	PreCreateString_5566		= GetSStringInfo(LAN_newDark_Avenger_Legend_Set3)

	PreCreateString_5567		= GetSStringInfo(LAN_newDark_Avenger_Legend_Set6)

	PreCreateString_5568		= GetSStringInfo(LAN_newDark_Avenger_Rare_Set3)

	PreCreateString_5569		= GetSStringInfo(LAN_newDark_Avenger_Rare_Set6)

	PreCreateString_5570		= GetSStringInfo(LAN_newDark_Avenger_Unique_Set3)

	PreCreateString_5571		= GetSStringInfo(LAN_newDark_Avenger_Unique_Set6)

	PreCreateString_5572		= GetSStringInfo(LAN_newDark_Avenger_Unique_Set9)

	PreCreateString_5573		= GetSStringInfo(LAN_newRider_Legend_Set3)

	PreCreateString_5574		= GetSStringInfo(LAN_newRider_Legend_Set6)

	PreCreateString_5575		= GetSStringInfo(LAN_newRider_Rare_Set3)

	PreCreateString_5576		= GetSStringInfo(LAN_newRider_Rare_Set6)

	PreCreateString_5577		= GetSStringInfo(LAN_newRider_Unique_Set3)

	PreCreateString_5578		= GetSStringInfo(LAN_newRider_Unique_Set6)

	PreCreateString_5579		= GetSStringInfo(LAN_newRider_Unique_Set9)

	PreCreateString_5580		= GetSStringInfo(LAN_CashCostume_02_Unique_Set_ABILITY1)

	PreCreateString_5581		= GetSStringInfo(LAN_CashCostume_02_Unique_Set_ABILITY2)

	PreCreateString_5582		= GetSStringInfo(LAN_CashCostume_02_Unique_Set_ABILITY3)

	PreCreateString_5583		= GetSStringInfo(LAN_MixCostume_ABILITY1)

	PreCreateString_5584		= GetSStringInfo(LAN_MixCostume_ABILITY2)

	PreCreateString_5600		= GetSStringInfo(LAN_CashCostume_03_Unique_Set_ABILITY1)

	PreCreateString_5601		= GetSStringInfo(LAN_CashCostume_03_Unique_Set_ABILITY2)

	PreCreateString_5602		= GetSStringInfo(LAN_CashCostume_03_Unique_Set_ABILITY3)

	PreCreateString_5603		= GetSStringInfo(LAN_CashDeco_02_High_Set_ABILITY1)

	PreCreateString_5614		= GetSStringInfo(LAN_GoldenEgg_01_Legend_Set_1)

	PreCreateString_5615		= GetSStringInfo(LAN_GoldenEgg_01_Legend_Set_2)

	PreCreateString_5616		= GetSStringInfo(LAN_GoldenEgg_01_Rare_Set_1)

	PreCreateString_5617		= GetSStringInfo(LAN_GoldenEgg_01_Rare_Set_2)

	PreCreateString_5618		= GetSStringInfo(LAN_GoldenEgg_01_Unique_Set_1)

	PreCreateString_5619		= GetSStringInfo(LAN_GoldenEgg_01_Unique_Set_2)

	PreCreateString_5620		= GetSStringInfo(LAN_GoldenEgg_01_Unique_Set_3)

	PreCreateString_5621		= GetSStringInfo(LAN_GoldenEgg_02_Legend_Set_1)

	PreCreateString_5622		= GetSStringInfo(LAN_GoldenEgg_02_Legend_Set_2)

	PreCreateString_5623		= GetSStringInfo(LAN_GoldenEgg_02_Rare_Set_1)

	PreCreateString_5624		= GetSStringInfo(LAN_GoldenEgg_02_Rare_Set_2)

	PreCreateString_5625		= GetSStringInfo(LAN_GoldenEgg_02_Unique_Set_1)

	PreCreateString_5626		= GetSStringInfo(LAN_GoldenEgg_02_Unique_Set_2)

	PreCreateString_5627		= GetSStringInfo(LAN_GoldenEgg_02_Unique_Set_3)

	PreCreateString_5628		= GetSStringInfo(LAN_GoldenEgg_03_Legend_Set_1)

	PreCreateString_5629		= GetSStringInfo(LAN_GoldenEgg_03_Legend_Set_2)

	PreCreateString_5630		= GetSStringInfo(LAN_GoldenEgg_03_Rare_Set_1)

	PreCreateString_5631		= GetSStringInfo(LAN_GoldenEgg_03_Rare_Set_2)

	PreCreateString_5632		= GetSStringInfo(LAN_GoldenEgg_03_Unique_Set_1)

	PreCreateString_5633		= GetSStringInfo(LAN_GoldenEgg_03_Unique_Set_2)

	PreCreateString_5634		= GetSStringInfo(LAN_GoldenEgg_03_Unique_Set_3)

	PreCreateString_5635		= GetSStringInfo(LAN_GoldenEgg_04_Legend_Set_1)

	PreCreateString_5636		= GetSStringInfo(LAN_GoldenEgg_04_Legend_Set_2)

	PreCreateString_5637		= GetSStringInfo(LAN_GoldenEgg_04_Rare_Set_1)

	PreCreateString_5638		= GetSStringInfo(LAN_GoldenEgg_04_Rare_Set_2)

	PreCreateString_5639		= GetSStringInfo(LAN_GoldenEgg_04_Unique_Set_1)

	PreCreateString_5640		= GetSStringInfo(LAN_GoldenEgg_04_Unique_Set_2)

	PreCreateString_5641		= GetSStringInfo(LAN_GoldenEgg_04_Unique_Set_3)

	PreCreateString_5642		= GetSStringInfo(LAN_GoldenEgg_05_Legend_Set_1)

	PreCreateString_5643		= GetSStringInfo(LAN_GoldenEgg_05_Legend_Set_2)

	PreCreateString_5644		= GetSStringInfo(LAN_GoldenEgg_05_Rare_Set_1)

	PreCreateString_5645		= GetSStringInfo(LAN_GoldenEgg_05_Rare_Set_2)

	PreCreateString_5646		= GetSStringInfo(LAN_GoldenEgg_05_Unique_Set_1)

	PreCreateString_5647		= GetSStringInfo(LAN_GoldenEgg_05_Unique_Set_2)

	PreCreateString_5648		= GetSStringInfo(LAN_GoldenEgg_05_Unique_Set_3)

	PreCreateString_5649		= GetSStringInfo(LAN_GoldenEgg_06_Legend_Set_1)

	PreCreateString_5650		= GetSStringInfo(LAN_GoldenEgg_06_Legend_Set_2)

	PreCreateString_5651		= GetSStringInfo(LAN_GoldenEgg_06_Rare_Set_1)

	PreCreateString_5652		= GetSStringInfo(LAN_GoldenEgg_06_Rare_Set_2)

	PreCreateString_5653		= GetSStringInfo(LAN_GoldenEgg_06_Unique_Set_1)

	PreCreateString_5654		= GetSStringInfo(LAN_GoldenEgg_06_Unique_Set_2)

	PreCreateString_5655		= GetSStringInfo(LAN_GoldenEgg_06_Unique_Set_3)

	PreCreateString_5656		= GetSStringInfo(LAN_GoldenEgg_07_Legend_Set_1)

	PreCreateString_5657		= GetSStringInfo(LAN_GoldenEgg_07_Legend_Set_2)

	PreCreateString_5658		= GetSStringInfo(LAN_GoldenEgg_07_Rare_Set_1)

	PreCreateString_5659		= GetSStringInfo(LAN_GoldenEgg_07_Rare_Set_2)

	PreCreateString_5660		= GetSStringInfo(LAN_GoldenEgg_07_Unique_Set_1)

	PreCreateString_5661		= GetSStringInfo(LAN_GoldenEgg_07_Unique_Set_2)

	PreCreateString_5662		= GetSStringInfo(LAN_GoldenEgg_07_Unique_Set_3)

	PreCreateString_5663		= GetSStringInfo(LAN_GoldenEgg_08_Legend_Set_1)

	PreCreateString_5664		= GetSStringInfo(LAN_GoldenEgg_08_Legend_Set_2)

	PreCreateString_5665		= GetSStringInfo(LAN_GoldenEgg_08_Rare_Set_1)

	PreCreateString_5666		= GetSStringInfo(LAN_GoldenEgg_08_Rare_Set_2)

	PreCreateString_5667		= GetSStringInfo(LAN_GoldenEgg_08_Unique_Set_1)

	PreCreateString_5668		= GetSStringInfo(LAN_GoldenEgg_08_Unique_Set_2)

	PreCreateString_5669		= GetSStringInfo(LAN_GoldenEgg_08_Unique_Set_3)

	PreCreateString_5670		= GetSStringInfo(LAN_GoldenEgg_09_Legend_Set_1)

	PreCreateString_5671		= GetSStringInfo(LAN_GoldenEgg_09_Legend_Set_2)

	PreCreateString_5672		= GetSStringInfo(LAN_GoldenEgg_09_Rare_Set_1)

	PreCreateString_5673		= GetSStringInfo(LAN_GoldenEgg_09_Rare_Set_2)

	PreCreateString_5674		= GetSStringInfo(LAN_GoldenEgg_09_Unique_Set_1)

	PreCreateString_5675		= GetSStringInfo(LAN_GoldenEgg_09_Unique_Set_2)

	PreCreateString_5676		= GetSStringInfo(LAN_GoldenEgg_09_Unique_Set_3)

	PreCreateString_5677		= GetSStringInfo(LAN_GoldenEgg_10_Legend_Set_1)

	PreCreateString_5678		= GetSStringInfo(LAN_GoldenEgg_10_Legend_Set_2)

	PreCreateString_5679		= GetSStringInfo(LAN_GoldenEgg_10_Rare_Set_1)

	PreCreateString_5680		= GetSStringInfo(LAN_GoldenEgg_10_Rare_Set_2)

	PreCreateString_5681		= GetSStringInfo(LAN_GoldenEgg_10_Unique_Set_1)

	PreCreateString_5682		= GetSStringInfo(LAN_GoldenEgg_10_Unique_Set_2)

	PreCreateString_5683		= GetSStringInfo(LAN_GoldenEgg_10_Unique_Set_3)

	PreCreateString_5684		= GetSStringInfo(LAN_GoldenEgg_11_Legend_Set_1)

	PreCreateString_5685		= GetSStringInfo(LAN_GoldenEgg_11_Legend_Set_2)

	PreCreateString_5686		= GetSStringInfo(LAN_GoldenEgg_11_Rare_Set_1)

	PreCreateString_5687		= GetSStringInfo(LAN_GoldenEgg_11_Rare_Set_2)

	PreCreateString_5688		= GetSStringInfo(LAN_GoldenEgg_11_Unique_Set_1)

	PreCreateString_5689		= GetSStringInfo(LAN_GoldenEgg_11_Unique_Set_2)

	PreCreateString_5690		= GetSStringInfo(LAN_GoldenEgg_11_Unique_Set_3)

	PreCreateString_5691		= GetSStringInfo(LAN_GoldenEgg_12_Legend_Set_1)

	PreCreateString_5692		= GetSStringInfo(LAN_GoldenEgg_12_Legend_Set_2)

	PreCreateString_5693		= GetSStringInfo(LAN_GoldenEgg_12_Rare_Set_1)

	PreCreateString_5694		= GetSStringInfo(LAN_GoldenEgg_12_Rare_Set_2)

	PreCreateString_5695		= GetSStringInfo(LAN_GoldenEgg_12_Unique_Set_1)

	PreCreateString_5696		= GetSStringInfo(LAN_GoldenEgg_12_Unique_Set_2)

	PreCreateString_5697		= GetSStringInfo(LAN_GoldenEgg_12_Unique_Set_3)

	PreCreateString_5698		= GetSStringInfo(LAN_newDeath_Scythe_Legend_Set3)

	PreCreateString_5699		= GetSStringInfo(LAN_newDeath_Scythe_Legend_Set6)

	PreCreateString_5700		= GetSStringInfo(LAN_newDeath_Scythe_Rare_Set3)

	PreCreateString_5701		= GetSStringInfo(LAN_newDeath_Scythe_Rare_Set6)

	PreCreateString_5702		= GetSStringInfo(LAN_newDeath_Scythe_Unique_Set3)

	PreCreateString_5703		= GetSStringInfo(LAN_newDeath_Scythe_Unique_Set6)

	PreCreateString_5704		= GetSStringInfo(LAN_newDeath_Scythe_Unique_Set9)

	PreCreateString_5705		= GetSStringInfo(LAN_Thief_Set_ABILITY1)

	PreCreateString_5706		= GetSStringInfo(LAN_Thief_Set_ABILITY2)

	PreCreateString_5707		= GetSStringInfo(LAN_Thief_Set_ABILITY3)

	PreCreateString_5717		= GetSStringInfo(LAN_STEAM_CASH_REFILL)

	PreCreateString_5718		= GetSStringInfo(LAN_GoldenEgg_samurai_Legend_Set_1)

	PreCreateString_5719		= GetSStringInfo(LAN_GoldenEgg_samurai_Legend_Set_2)

	PreCreateString_5720		= GetSStringInfo(LAN_GoldenEgg_samurai_rare_Set_1)

	PreCreateString_5721		= GetSStringInfo(LAN_GoldenEgg_samurai_rare_Set_2)

	PreCreateString_5722		= GetSStringInfo(LAN_GoldenEgg_samurai_Unique_Set_1)

	PreCreateString_5723		= GetSStringInfo(LAN_GoldenEgg_samurai_Unique_Set_2)

	PreCreateString_5724		= GetSStringInfo(LAN_GoldenEgg_samurai_Unique_Set_3)

	PreCreateString_5747		= GetSStringInfo(LAN_snowman_ESKILL_001)

	PreCreateString_5748		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_114)

	PreCreateString_5749		= GetSStringInfo(LAN_LUA_WND_VILLAGE_DESIGNER_115)

	PreCreateString_5750		= GetSStringInfo(LAN_CONTROLLER_NOTICE_01)

	PreCreateString_5751		= GetSStringInfo(LAN_CONTROLLER_NOTICE_02)

	PreCreateString_5752		= GetSStringInfo(LAN_Legend_Saw_blade_Set_ABILITY1)

	PreCreateString_5753		= GetSStringInfo(LAN_Legend_Saw_blade_Set_ABILITY2)

	PreCreateString_5754		= GetSStringInfo(LAN_Legend_Saw_blade_Set_ABILITY3)

	PreCreateString_5755		= GetSStringInfo(LAN_Rare_Saw_blade_Set_ABILITY1)

	PreCreateString_5756		= GetSStringInfo(LAN_Rare_Saw_blade_Set_ABILITY2)

	PreCreateString_5757		= GetSStringInfo(LAN_Unique_Saw_blade_Set_ABILITY1)

	PreCreateString_5758		= GetSStringInfo(LAN_Unique_Saw_blade_Set_ABILITY2)

	PreCreateString_5759		= GetSStringInfo(LAN_Unique_Saw_blade_Set_ABILITY3)

	PreCreateString_5762		= GetSStringInfo(LAN_bouquet_ESKILL_001)

	PreCreateString_5763		= GetSStringInfo(LAN_ITEM_SET1_ABT4)

	PreCreateString_5764		= GetSStringInfo(LAN_ITEM_SET1_ABT5)

	PreCreateString_5765		= GetSStringInfo(LAN_NEWCollection_Adventure_Ultimate_set3)

	PreCreateString_5766		= GetSStringInfo(LAN_NEWCollection_Adventure_Ultimate_set6)

	PreCreateString_5767		= GetSStringInfo(LAN_NEWCollection_Adventure_Ultimate_set9)

	PreCreateString_5768		= GetSStringInfo(LAN_NEWCollection_Pierrot_Ultimate_set3)

	PreCreateString_5769		= GetSStringInfo(LAN_NEWCollection_Pierrot_Ultimate_set6)

	PreCreateString_5770		= GetSStringInfo(LAN_NEWCollection_Pierrot_Ultimate_set9)

	PreCreateString_5771		= GetSStringInfo(LAN_NEWCollection_Rocker_Ultimate_set3)

	PreCreateString_5772		= GetSStringInfo(LAN_NEWCollection_Rocker_Ultimate_set6)

	PreCreateString_5773		= GetSStringInfo(LAN_NEWCollection_Rocker_Ultimate_set9)

	PreCreateString_5774		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Ultimate_set3)

	PreCreateString_5775		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Ultimate_set6)

	PreCreateString_5776		= GetSStringInfo(LAN_NEWCollection_Cowboy_Girl_Ultimate_set9)

	PreCreateString_5777		= GetSStringInfo(LAN_NEWCollection_Invertor_Ultimate_set3)

	PreCreateString_5778		= GetSStringInfo(LAN_NEWCollection_Invertor_Ultimate_set6)

	PreCreateString_5779		= GetSStringInfo(LAN_NEWCollection_Invertor_Ultimate_set9)

	PreCreateString_5780		= GetSStringInfo(LAN_NEWCollection_General_Ultimate_set3)

	PreCreateString_5781		= GetSStringInfo(LAN_NEWCollection_General_Ultimate_set6)

	PreCreateString_5782		= GetSStringInfo(LAN_NEWCollection_General_Ultimate_set9)

	PreCreateString_5783		= GetSStringInfo(LAN_NEWCollection_Hunter_Ultimate_set3)

	PreCreateString_5784		= GetSStringInfo(LAN_NEWCollection_Hunter_Ultimate_set6)

	PreCreateString_5785		= GetSStringInfo(LAN_NEWCollection_Hunter_Ultimate_set9)

	PreCreateString_5786		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_1)

	PreCreateString_5787		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_2)

	PreCreateString_5788		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_3)

	PreCreateString_5789		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_4)

	PreCreateString_5790		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_5)

	PreCreateString_5791		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_6)

	PreCreateString_5792		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_7)

	PreCreateString_5793		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_8)

	PreCreateString_5794		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_9)

	PreCreateString_5795		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_10)

	PreCreateString_5796		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_11)

	PreCreateString_5797		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_12)

	PreCreateString_5798		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_13)

	PreCreateString_5799		= GetSStringInfo(LAN_GoldenEgg_01_Ultimate_Set_14)

	PreCreateString_5812		= GetSStringInfo(LAN_Viking_Set_1)

	PreCreateString_5813		= GetSStringInfo(LAN_Viking_Set_2)

	PreCreateString_5814		= GetSStringInfo(LAN_Viking_Set_3)

	PreCreateString_5815		= GetSStringInfo(LAN_Unicorn_Set_1)

	PreCreateString_5816		= GetSStringInfo(LAN_Unicorn_Set_2)

	PreCreateString_5817		= GetSStringInfo(LAN_Falcon_Silve_Set_1)

	PreCreateString_5818		= GetSStringInfo(LAN_Falcon_Silve_Set_2)

	PreCreateString_5857		= GetSStringInfo(LAN_HolyDragon_ESKILL_001)

	PreCreateString_5858		= GetSStringInfo(LAN_Gang_Champion_Set)

	PreCreateString_5859		= GetSStringInfo(LAN_swordattack_ESKILL_001)

	PreCreateString_5866		= GetSStringInfo(LAN_Halloween_ESKILL_001)

	PreCreateString_5872		= GetSStringInfo(LAN_Knigh_costume_gold_Set_1)

	PreCreateString_5873		= GetSStringInfo(LAN_Knigh_costume_gold_Set_2)

	PreCreateString_5874		= GetSStringInfo(LAN_Knigh_costume_gold_Set_3)

	PreCreateString_5875		= GetSStringInfo(LAN_Knigh_costume_Silver_Set_1)

	PreCreateString_5876		= GetSStringInfo(LAN_Knigh_costume_Silver_Set_2)

	PreCreateString_5877		= GetSStringInfo(LAN_Knigh_costume_Silver_Set_3)

	PreCreateString_5878		= GetSStringInfo(LAN_Knigh_costume_Black_Set_1)

	PreCreateString_5879		= GetSStringInfo(LAN_Knigh_costume_Black_Set_2)

	PreCreateString_5880		= GetSStringInfo(LAN_Knigh_costume_Black_Set_3)

	PreCreateString_5881		= GetSStringInfo(LAN_christmas_ESKILL_001)

	PreCreateString_5890		= GetSStringInfo(LAN_Firelord_ESKILL_001)

	PreCreateString_5891		= GetSStringInfo(LAN_Weapon_ESKILL_001)

	PreCreateString_5904		= GetSStringInfo(LAN_artist_costume_Set_1)

	PreCreateString_5905		= GetSStringInfo(LAN_artist_costume_Set_2)

	PreCreateString_5906		= GetSStringInfo(LAN_artist_costume_Set_3)

	PreCreateString_5930		= GetSStringInfo(LAN_Cyber_costume_Set_1)

	PreCreateString_5931		= GetSStringInfo(LAN_Cyber_costume_Set_2)

	PreCreateString_5938		= GetSStringInfo(LAN_World_Set_1)

	PreCreateString_5939		= GetSStringInfo(LAN_World_Set_2)

	PreCreateString_5940		= GetSStringInfo(LAN_World_Set_3)

	PreCreateString_5941		= GetSStringInfo(LAN_World_HIDDEN_SIN01)

	PreCreateString_5953		= GetSStringInfo(LAN_Dancer_costume_Set_1)

	PreCreateString_5954		= GetSStringInfo(LAN_Dancer_costume_Set_2)

	PreCreateString_5955		= GetSStringInfo(LAN_Dancer_costume_Set_3)

	PreCreateString_5984		= GetSStringInfo(LAN_Warm_ESKILL_001)

	PreCreateString_5985		= GetSStringInfo(LAN_war_Egg_set_01)

	PreCreateString_5986		= GetSStringInfo(LAN_war_Egg_set_02)

	PreCreateString_5987		= GetSStringInfo(LAN_LoiKrathong_Set)

	PreCreateString_6023		= GetSStringInfo(LAN_Bigstar_set_01)

	PreCreateString_6024		= GetSStringInfo(LAN_Bigmeat_set_01)

	PreCreateString_6025		= GetSStringInfo(LAN_CuteBear_set_01)

	PreCreateString_6050		= GetSStringInfo(LAN_Wars_ESKILL_001)

	PreCreateString_6054		= GetSStringInfo(LAN_Songkran_ESKILL_001)

	PreCreateString_6066		= GetSStringInfo(LAN_Wars_ESKILL_002)

	PreCreateString_6067		= GetSStringInfo(LAN_Pirate_set_001)

	PreCreateString_6068		= GetSStringInfo(LAN_Pirate_set_002)

	PreCreateString_6069		= GetSStringInfo(LAN_Farmer_set_001)

	PreCreateString_6070		= GetSStringInfo(LAN_Farmer_set_002)

	PreCreateString_6071		= GetSStringInfo(LAN_Royal_set_001)

	PreCreateString_6072		= GetSStringInfo(LAN_Royal_set_002)

	PreCreateString_6073		= GetSStringInfo(LAN_Royal_set_003)

	PreCreateString_6074		= GetSStringInfo(LAN_Warg_ESKILL_001)

	PreCreateString_6075		= GetSStringInfo(LAN_Monk_Set_001)

	PreCreateString_6076		= GetSStringInfo(LAN_Monk_Set_002)

	PreCreateString_6077		= GetSStringInfo(LAN_Krathong_Set_001)

	PreCreateString_6078		= GetSStringInfo(LAN_CircleEnergy_Set_001)

	PreCreateString_6079		= GetSStringInfo(LAN_CircleEnergy_Set_002)

	PreCreateString_6080		= GetSStringInfo(LAN_CircleEnergy_Set_003)

	PreCreateString_6081		= GetSStringInfo(LAN_BrutalWarrior_ESKILL_001)

	PreCreateString_6082		= GetSStringInfo(LAN_2020golednegg_Set_001)

	PreCreateString_6083		= GetSStringInfo(LAN_2020golednegg_Set_002)

	PreCreateString_6084		= GetSStringInfo(LAN_2020golednegg_Set_003)

	PreCreateString_6085		= GetSStringInfo(LAN_BrutalAvenger_ESKILL_001)

	PreCreateString_6086		= GetSStringInfo(LAN_2020gangwar_Set_001)

	PreCreateString_6087		= GetSStringInfo(LAN_2020gangwar_Set_002)

	PreCreateString_6088		= GetSStringInfo(LAN_BrutalCelestial_ESKILL_001)

	PreCreateString_6089		= GetSStringInfo(LAN_2020mam_event_001)

	PreCreateString_7002		= GetSStringInfo(LAN_EXECollection_Adventure_Normal_Set3)

	PreCreateString_7003		= GetSStringInfo(LAN_EXECollection_Adventure_Normal_Set6)

	PreCreateString_7004		= GetSStringInfo(LAN_EXECollection_Adventure_Normal_Set9)

	PreCreateString_7005		= GetSStringInfo(LAN_EXECollection_Adventure_High_Set3)

	PreCreateString_7006		= GetSStringInfo(LAN_EXECollection_Adventure_High_Set6)

	PreCreateString_7007		= GetSStringInfo(LAN_EXECollection_Adventure_High_Set9)

	PreCreateString_7008		= GetSStringInfo(LAN_EXECollection_Adventure_Unique_Set3)

	PreCreateString_7009		= GetSStringInfo(LAN_EXECollection_Adventure_Unique_Set6)

	PreCreateString_7010		= GetSStringInfo(LAN_EXECollection_Adventure_Unique_Set9)

	PreCreateString_7011		= GetSStringInfo(LAN_EXECollection_Adventure_Rare_Set3)

	PreCreateString_7012		= GetSStringInfo(LAN_EXECollection_Adventure_Rare_Set6)

	PreCreateString_7013		= GetSStringInfo(LAN_EXECollection_Adventure_Rare_Set9)

	PreCreateString_7014		= GetSStringInfo(LAN_EXECollection_Adventure_Legend_Set3)

	PreCreateString_7015		= GetSStringInfo(LAN_EXECollection_Adventure_Legend_Set6)

	PreCreateString_7016		= GetSStringInfo(LAN_EXECollection_Adventure_Legend_Set9)

	PreCreateString_7017		= GetSStringInfo(LAN_EXECollection_Adventure_Ultimate_Set3)

	PreCreateString_7018		= GetSStringInfo(LAN_EXECollection_Adventure_Ultimate_Set6)

	PreCreateString_7019		= GetSStringInfo(LAN_EXECollection_Adventure_Ultimate_Set9)

	PreCreateString_7020		= GetSStringInfo(LAN_EXECollection_Rocker_Normal_Set3)

	PreCreateString_7021		= GetSStringInfo(LAN_EXECollection_Rocker_Normal_Set6)

	PreCreateString_7022		= GetSStringInfo(LAN_EXECollection_Rocker_Normal_Set9)

	PreCreateString_7023		= GetSStringInfo(LAN_EXECollection_Rocker_High_Set3)

	PreCreateString_7024		= GetSStringInfo(LAN_EXECollection_Rocker_High_Set6)

	PreCreateString_7025		= GetSStringInfo(LAN_EXECollection_Rocker_High_Set9)

	PreCreateString_7026		= GetSStringInfo(LAN_EXECollection_Rocker_Unique_Set3)

	PreCreateString_7027		= GetSStringInfo(LAN_EXECollection_Rocker_Unique_Set6)

	PreCreateString_7028		= GetSStringInfo(LAN_EXECollection_Rocker_Unique_Set9)

	PreCreateString_7029		= GetSStringInfo(LAN_EXECollection_Rocker_Rare_Set3)

	PreCreateString_7030		= GetSStringInfo(LAN_EXECollection_Rocker_Rare_Set6)

	PreCreateString_7031		= GetSStringInfo(LAN_EXECollection_Rocker_Rare_Set9)

	PreCreateString_7032		= GetSStringInfo(LAN_EXECollection_Rocker_Legend_Set3)

	PreCreateString_7033		= GetSStringInfo(LAN_EXECollection_Rocker_Legend_Set6)

	PreCreateString_7034		= GetSStringInfo(LAN_EXECollection_Rocker_Legend_Set9)

	PreCreateString_7035		= GetSStringInfo(LAN_EXECollection_Rocker_Ultimate_Set3)

	PreCreateString_7036		= GetSStringInfo(LAN_EXECollection_Rocker_Ultimate_Set6)

	PreCreateString_7037		= GetSStringInfo(LAN_EXECollection_Rocker_Ultimate_Set9)

	PreCreateString_7038		= GetSStringInfo(LAN_EXECollection_Cow_Normal_Set3)

	PreCreateString_7039		= GetSStringInfo(LAN_EXECollection_Cow_Normal_Set6)

	PreCreateString_7040		= GetSStringInfo(LAN_EXECollection_Cow_Normal_Set9)

	PreCreateString_7041		= GetSStringInfo(LAN_EXECollection_Cow_High_Set3)

	PreCreateString_7042		= GetSStringInfo(LAN_EXECollection_Cow_High_Set6)

	PreCreateString_7043		= GetSStringInfo(LAN_EXECollection_Cow_High_Set9)

	PreCreateString_7044		= GetSStringInfo(LAN_EXECollection_Cow_Unique_Set3)

	PreCreateString_7045		= GetSStringInfo(LAN_EXECollection_Cow_Unique_Set6)

	PreCreateString_7046		= GetSStringInfo(LAN_EXECollection_Cow_Unique_Set9)

	PreCreateString_7047		= GetSStringInfo(LAN_EXECollection_Cow_Rare_Set3)

	PreCreateString_7048		= GetSStringInfo(LAN_EXECollection_Cow_Rare_Set6)

	PreCreateString_7049		= GetSStringInfo(LAN_EXECollection_Cow_Rare_Set9)

	PreCreateString_7050		= GetSStringInfo(LAN_EXECollection_Cow_Legend_Set3)

	PreCreateString_7051		= GetSStringInfo(LAN_EXECollection_Cow_Legend_Set6)

	PreCreateString_7052		= GetSStringInfo(LAN_EXECollection_Cow_Legend_Set9)

	PreCreateString_7053		= GetSStringInfo(LAN_EXECollection_Cow_Ultimate_Set3)

	PreCreateString_7054		= GetSStringInfo(LAN_EXECollection_Cow_Ultimate_Set6)

	PreCreateString_7055		= GetSStringInfo(LAN_EXECollection_Cow_Ultimate_Set9)

	PreCreateString_7056		= GetSStringInfo(LAN_EXECollection_Pierrot_Normal_Set3)

	PreCreateString_7057		= GetSStringInfo(LAN_EXECollection_Pierrot_Normal_Set6)

	PreCreateString_7058		= GetSStringInfo(LAN_EXECollection_Pierrot_Normal_Set9)

	PreCreateString_7059		= GetSStringInfo(LAN_EXECollection_Pierrot_High_Set3)

	PreCreateString_7060		= GetSStringInfo(LAN_EXECollection_Pierrot_High_Set6)

	PreCreateString_7061		= GetSStringInfo(LAN_EXECollection_Pierrot_High_Set9)

	PreCreateString_7062		= GetSStringInfo(LAN_EXECollection_Pierrot_Unique_Set3)

	PreCreateString_7063		= GetSStringInfo(LAN_EXECollection_Pierrot_Unique_Set6)

	PreCreateString_7064		= GetSStringInfo(LAN_EXECollection_Pierrot_Unique_Set9)

	PreCreateString_7065		= GetSStringInfo(LAN_EXECollection_Pierrot_Rare_Set3)

	PreCreateString_7066		= GetSStringInfo(LAN_EXECollection_Pierrot_Rare_Set6)

	PreCreateString_7067		= GetSStringInfo(LAN_EXECollection_Pierrot_Rare_Set9)

	PreCreateString_7068		= GetSStringInfo(LAN_EXECollection_Pierrot_Legend_Set3)

	PreCreateString_7069		= GetSStringInfo(LAN_EXECollection_Pierrot_Legend_Set6)

	PreCreateString_7070		= GetSStringInfo(LAN_EXECollection_Pierrot_Legend_Set9)

	PreCreateString_7071		= GetSStringInfo(LAN_EXECollection_Pierrot_Ultimate_Set3)

	PreCreateString_7072		= GetSStringInfo(LAN_EXECollection_Pierrot_Ultimate_Set6)

	PreCreateString_7073		= GetSStringInfo(LAN_EXECollection_Pierrot_Ultimate_Set9)

	PreCreateString_7074		= GetSStringInfo(LAN_EXECollection_Inventor_Normal_Set3)

	PreCreateString_7075		= GetSStringInfo(LAN_EXECollection_Inventor_Normal_Set6)

	PreCreateString_7076		= GetSStringInfo(LAN_EXECollection_Inventor_Normal_Set9)

	PreCreateString_7077		= GetSStringInfo(LAN_EXECollection_Inventor_High_Set3)

	PreCreateString_7078		= GetSStringInfo(LAN_EXECollection_Inventor_High_Set6)

	PreCreateString_7079		= GetSStringInfo(LAN_EXECollection_Inventor_High_Set9)

	PreCreateString_7080		= GetSStringInfo(LAN_EXECollection_Inventor_Unique_Set3)

	PreCreateString_7081		= GetSStringInfo(LAN_EXECollection_Inventor_Unique_Set6)

	PreCreateString_7082		= GetSStringInfo(LAN_EXECollection_Inventor_Unique_Set9)

	PreCreateString_7083		= GetSStringInfo(LAN_EXECollection_Inventor_Rare_Set3)

	PreCreateString_7084		= GetSStringInfo(LAN_EXECollection_Inventor_Rare_Set6)

	PreCreateString_7085		= GetSStringInfo(LAN_EXECollection_Inventor_Rare_Set9)

	PreCreateString_7086		= GetSStringInfo(LAN_EXECollection_Inventor_Legend_Set3)

	PreCreateString_7087		= GetSStringInfo(LAN_EXECollection_Inventor_Legend_Set6)

	PreCreateString_7088		= GetSStringInfo(LAN_EXECollection_Inventor_Legend_Set9)

	PreCreateString_7089		= GetSStringInfo(LAN_EXECollection_Inventor_Ultimate_Set3)

	PreCreateString_7090		= GetSStringInfo(LAN_EXECollection_Inventor_Ultimate_Set6)

	PreCreateString_7091		= GetSStringInfo(LAN_EXECollection_Inventor_Ultimate_Set9)

	PreCreateString_7093		= GetSStringInfo(LAN_EXECollection_General_Normal_Set3)

	PreCreateString_7094		= GetSStringInfo(LAN_EXECollection_General_Normal_Set6)

	PreCreateString_7095		= GetSStringInfo(LAN_EXECollection_General_Normal_Set9)

	PreCreateString_7096		= GetSStringInfo(LAN_EXECollection_General_High_Set3)

	PreCreateString_7097		= GetSStringInfo(LAN_EXECollection_General_High_Set6)

	PreCreateString_7098		= GetSStringInfo(LAN_EXECollection_General_High_Set9)

	PreCreateString_7099		= GetSStringInfo(LAN_EXECollection_General_Unique_Set3)

	PreCreateString_7100		= GetSStringInfo(LAN_EXECollection_General_Unique_Set6)

	PreCreateString_7101		= GetSStringInfo(LAN_EXECollection_General_Unique_Set9)

	PreCreateString_7102		= GetSStringInfo(LAN_EXECollection_General_Rare_Set3)

	PreCreateString_7103		= GetSStringInfo(LAN_EXECollection_General_Rare_Set6)

	PreCreateString_7104		= GetSStringInfo(LAN_EXECollection_General_Rare_Set9)

	PreCreateString_7105		= GetSStringInfo(LAN_EXECollection_General_Legend_Set3)

	PreCreateString_7106		= GetSStringInfo(LAN_EXECollection_General_Legend_Set6)

	PreCreateString_7107		= GetSStringInfo(LAN_EXECollection_General_Legend_Set9)

	PreCreateString_7108		= GetSStringInfo(LAN_EXECollection_General_Ultimate_Set3)

	PreCreateString_7109		= GetSStringInfo(LAN_EXECollection_General_Ultimate_Set6)

	PreCreateString_7110		= GetSStringInfo(LAN_EXECollection_General_Ultimate_Set9)

	PreCreateString_7112		= GetSStringInfo(LAN_EXECollection_Golden_Shark_Set3)

	PreCreateString_7113		= GetSStringInfo(LAN_EXECollection_Shinobi_Unique_Set3)

	PreCreateString_7114		= GetSStringInfo(LAN_EXECollection_Shinobi_Unique_Set6)

	PreCreateString_7115		= GetSStringInfo(LAN_EXECollection_Shinobi_Unique_Set9)

	PreCreateString_7116		= GetSStringInfo(LAN_EXECollection_Galaxy6_Legend_Set3)

	PreCreateString_7117		= GetSStringInfo(LAN_EXECollection_Galaxy6_Legend_Set6)

	PreCreateString_7118		= GetSStringInfo(LAN_EXECollection_Galaxy6_Legend_Set9)

	PreCreateString_7119		= GetSStringInfo(LAN_EXECollection_Genocide_Legend_Set3)

	PreCreateString_7120		= GetSStringInfo(LAN_EXECollection_Genocide_Legend_Set6)

	PreCreateString_7121		= GetSStringInfo(LAN_EXECollection_Genocide_Legend_Set9)

	PreCreateString_7122		= GetSStringInfo(LAN_EXECollection_Overload_Legend_Set3)

	PreCreateString_7123		= GetSStringInfo(LAN_EXECollection_Overload_Legend_Set6)

	PreCreateString_7124		= GetSStringInfo(LAN_EXECollection_Overload_Legend_Set9)

	PreCreateString_7125		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Unique_Set3)

	PreCreateString_7126		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Unique_Set6)

	PreCreateString_7127		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Unique_Set9)

	PreCreateString_7128		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Rare_Set3)

	PreCreateString_7129		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Rare_Set6)

	PreCreateString_7130		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Rare_Set9)

	PreCreateString_7131		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Legend_Set3)

	PreCreateString_7132		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Legend_Set6)

	PreCreateString_7133		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Legend_Set9)

	PreCreateString_7134		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Ultimate_Set3)

	PreCreateString_7135		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Ultimate_Set6)

	PreCreateString_7136		= GetSStringInfo(LAN_EXECollection_MonkeyKing_Ultimate_Set9)

	PreCreateString_7137		= GetSStringInfo(LAN_EXECollection_MomySet_Legend_Set3)

	PreCreateString_7138		= GetSStringInfo(LAN_EXECollection_MomySet_Legend_Set6)

	PreCreateString_7139		= GetSStringInfo(LAN_EXECollection_RomanSet_Legend_Set3)

	PreCreateString_7140		= GetSStringInfo(LAN_EXECollection_GolemSet_High_Set3)

	PreCreateString_7141		= GetSStringInfo(LAN_EXECollection_GolemSet_High_Set6)

	PreCreateString_7142		= GetSStringInfo(LAN_EXECollection_GolemSet_High_Set9)

	PreCreateString_7143		= GetSStringInfo(LAN_EXECollection_GolemSet_Unique_Set3)

	PreCreateString_7144		= GetSStringInfo(LAN_EXECollection_GolemSet_Unique_Set6)

	PreCreateString_7145		= GetSStringInfo(LAN_EXECollection_GolemSet_Unique_Set9)

	PreCreateString_7146		= GetSStringInfo(LAN_EXECollection_GolemSet_Rare_Set3)

	PreCreateString_7147		= GetSStringInfo(LAN_EXECollection_GolemSet_Rare_Set6)

	PreCreateString_7148		= GetSStringInfo(LAN_EXECollection_GolemSet_Rare_Set9)

	PreCreateString_7149		= GetSStringInfo(LAN_EXECollection_GolemSet_Legend_Set3)

	PreCreateString_7150		= GetSStringInfo(LAN_EXECollection_GolemSet_Legend_Set6)

	PreCreateString_7151		= GetSStringInfo(LAN_EXECollection_GolemSet_Legend_Set9)

	PreCreateString_7152		= GetSStringInfo(LAN_EXECollection_GolemSet_Ultimate_Set3)

	PreCreateString_7153		= GetSStringInfo(LAN_EXECollection_GolemSet_Ultimate_Set6)

	PreCreateString_7154		= GetSStringInfo(LAN_EXECollection_GolemSet_Ultimate_Set9)

	PreCreateString_7155		= GetSStringInfo(LAN_EXECollection_HunterSet_High_Set3)

	PreCreateString_7156		= GetSStringInfo(LAN_EXECollection_HunterSet_High_Set6)

	PreCreateString_7157		= GetSStringInfo(LAN_EXECollection_HunterSet_High_Set9)

	PreCreateString_7158		= GetSStringInfo(LAN_EXECollection_HunterSet_Unique_Set3)

	PreCreateString_7159		= GetSStringInfo(LAN_EXECollection_HunterSet_Unique_Set6)

	PreCreateString_7160		= GetSStringInfo(LAN_EXECollection_HunterSet_Unique_Set9)

	PreCreateString_7161		= GetSStringInfo(LAN_EXECollection_HunterSet_Rare_Set3)

	PreCreateString_7162		= GetSStringInfo(LAN_EXECollection_HunterSet_Rare_Set6)

	PreCreateString_7163		= GetSStringInfo(LAN_EXECollection_HunterSet_Rare_Set9)

	PreCreateString_7164		= GetSStringInfo(LAN_EXECollection_HunterSet_Legend_Set3)

	PreCreateString_7165		= GetSStringInfo(LAN_EXECollection_HunterSet_Legend_Set6)

	PreCreateString_7166		= GetSStringInfo(LAN_EXECollection_HunterSet_Legend_Set9)

	PreCreateString_7167		= GetSStringInfo(LAN_USER_ID_LOCKED)

	PreCreateString_7168		= GetSStringInfo(LAN_EXECollection_CyberTronSet_Legend_Set4)

	PreCreateString_7169		= GetSStringInfo(LAN_EXECollection_ForestSet_Unique_Set3)

	PreCreateString_7170		= GetSStringInfo(LAN_EXECollection_ForestSet_Unique_Set6)

	PreCreateString_7171		= GetSStringInfo(LAN_EXECollection_ForestSet_Unique_Set9)

	PreCreateString_7172		= GetSStringInfo(LAN_EXECollection_MagicianSet_Unique_Set3)

	PreCreateString_7173		= GetSStringInfo(LAN_EXECollection_MagicianSet_Unique_Set6)

	PreCreateString_7174		= GetSStringInfo(LAN_EXECollection_MagicianSet_Unique_Set9)

	PreCreateString_7175		= GetSStringInfo(LAN_EXECollection_HalloweenSet1_Rare_Set3)

	PreCreateString_7176		= GetSStringInfo(LAN_EXECollection_HalloweenSet1_Rare_Set6)

	PreCreateString_7177		= GetSStringInfo(LAN_EXECollection_HalloweenSet1_Rare_Set9)

	PreCreateString_7178		= GetSStringInfo(LAN_EXECollection_HalloweenSet2_Legend_Set3)

	PreCreateString_7179		= GetSStringInfo(LAN_EXECollection_HalloweenSet3_Rare_Set4)

	PreCreateString_7180		= GetSStringInfo(LAN_EXECollection_HalloweenSet4_Legend_Set4)

	PreCreateString_7181		= GetSStringInfo(LAN_EXECollection_FarmerSet_Legend_Set3)

	PreCreateString_7182		= GetSStringInfo(LAN_EXECollection_FarmerSet_Legend_Set6)

	PreCreateString_7183		= GetSStringInfo(LAN_EXECollection_FarmerSet_Legend_Set9)

	PreCreateString_7184		= GetSStringInfo(LAN_EXECollection_FarmerSet_Rare_Set3)

	PreCreateString_7185		= GetSStringInfo(LAN_EXECollection_FarmerSet_Rare_Set6)

	PreCreateString_7186		= GetSStringInfo(LAN_EXECollection_FarmerSet_Rare_Set9)

	PreCreateString_7187		= GetSStringInfo(LAN_EXECollection_SamuraiSet_Unique_Set3)

	PreCreateString_7188		= GetSStringInfo(LAN_EXECollection_SamuraiSet_Unique_Set6)

	PreCreateString_7189		= GetSStringInfo(LAN_EXECollection_SamuraiSet_Unique_Set9)

	PreCreateString_7190		= GetSStringInfo(LAN_EXECollection_RaiderSet_Unique_Set3)

	PreCreateString_7191		= GetSStringInfo(LAN_EXECollection_RaiderSet_Unique_Set6)

	PreCreateString_7192		= GetSStringInfo(LAN_EXECollection_RaiderSet_Unique_Set9)

	PreCreateString_7193		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set3)

	PreCreateString_7194		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set6)

	PreCreateString_7195		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7196		= GetSStringInfo(LAN_EXECollection_MochiSet_Set3)

	PreCreateString_7197		= GetSStringInfo(LAN_EXECollection_PirateSet_Rare_Set3)

	PreCreateString_7198		= GetSStringInfo(LAN_EXECollection_PirateSet_Rare_Set6)

	PreCreateString_7199		= GetSStringInfo(LAN_EXECollection_PirateSet_Rare_Set9)

	PreCreateString_7200		= GetSStringInfo(LAN_EXECollection_MonkSet_Rare_Set3)

	PreCreateString_7201		= GetSStringInfo(LAN_EXECollection_MonkSet_Rare_Set5)

	PreCreateString_7202		= GetSStringInfo(LAN_EXECollection_CaptainZone4_Ultimate_Set3)

	PreCreateString_7203		= GetSStringInfo(LAN_EXECollection_SpiderSet_Legend_Set3)

	PreCreateString_7204		= GetSStringInfo(LAN_EXECollection_SpiderSet_Legend_Set6)

	PreCreateString_7205		= GetSStringInfo(LAN_EXECollection_SpiderSet_Legend_Set9)

	PreCreateString_7206		= GetSStringInfo(LAN_EXECollection_Zagent_Ultimate_Set3)

	PreCreateString_7207		= GetSStringInfo(LAN_EXECollection_Zagent_Ultimate_Set6)

	PreCreateString_7208		= GetSStringInfo(LAN_EXECollection_Zagent_Ultimate_Set9)

	PreCreateString_7209		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Unique_Set3)

	PreCreateString_7210		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Unique_Set6)

	PreCreateString_7211		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Unique_Set9)

	PreCreateString_7212		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Rare_Set3)

	PreCreateString_7213		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Rare_Set6)

	PreCreateString_7214		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Legend_Set3)

	PreCreateString_7215		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Legend_Set6)

	PreCreateString_7216		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Ultimate_Set3)

	PreCreateString_7217		= GetSStringInfo(LAN_EXECollection_DarkAvenger_Ultimate_Set6)

	PreCreateString_7218		= GetSStringInfo(LAN_EXECollection_DeathScythe_Unique_Set3)

	PreCreateString_7219		= GetSStringInfo(LAN_EXECollection_DeathScythe_Unique_Set6)

	PreCreateString_7220		= GetSStringInfo(LAN_EXECollection_DeathScythe_Unique_Set9)

	PreCreateString_7221		= GetSStringInfo(LAN_EXECollection_DeathScythe_Rare_Set3)

	PreCreateString_7222		= GetSStringInfo(LAN_EXECollection_DeathScythe_Rare_Set6)

	PreCreateString_7223		= GetSStringInfo(LAN_EXECollection_DeathScythe_Legend_Set3)

	PreCreateString_7224		= GetSStringInfo(LAN_EXECollection_DeathScythe_Legend_Set6)

	PreCreateString_7225		= GetSStringInfo(LAN_EXECollection_DeathScythe_Ultimate_Set3)

	PreCreateString_7226		= GetSStringInfo(LAN_EXECollection_DeathScythe_Ultimate_Set6)

	PreCreateString_7227		= GetSStringInfo(LAN_EXECollection_GoldFirer_Unique_Set3)

	PreCreateString_7228		= GetSStringInfo(LAN_EXECollection_GoldFirer_Unique_Set6)

	PreCreateString_7229		= GetSStringInfo(LAN_EXECollection_GoldFirer_Unique_Set9)

	PreCreateString_7230		= GetSStringInfo(LAN_EXECollection_GoldFirer_Rare_Set3)

	PreCreateString_7231		= GetSStringInfo(LAN_EXECollection_GoldFirer_Rare_Set6)

	PreCreateString_7232		= GetSStringInfo(LAN_EXECollection_GoldFirer_Legend_Set3)

	PreCreateString_7233		= GetSStringInfo(LAN_EXECollection_GoldFirer_Legend_Set6)

	PreCreateString_7234		= GetSStringInfo(LAN_EXECollection_GoldFirer_Ultimate_Set3)

	PreCreateString_7235		= GetSStringInfo(LAN_EXECollection_GoldFirer_Ultimate_Set6)

	PreCreateString_7236		= GetSStringInfo(LAN_NPC_NAME_029)

	PreCreateString_7237		= GetSStringInfo(LAN_EVENTQUEST_GAMBLER_029)

	PreCreateString_7238		= GetSStringInfo(LAN_NPC_FUNCTION_029)

	PreCreateString_7239		= GetSStringInfo(LAN_EXECollection_BlazeSet_Unique_Set3)

	PreCreateString_7240		= GetSStringInfo(LAN_EXECollection_BlazeSet_Unique_Set6)

	PreCreateString_7241		= GetSStringInfo(LAN_EXECollection_BlazeSet_Unique_Set9)

	PreCreateString_7242		= GetSStringInfo(LAN_EXECollection_BlazeSet_Rare_Set3)

	PreCreateString_7243		= GetSStringInfo(LAN_EXECollection_BlazeSet_Rare_Set6)

	PreCreateString_7244		= GetSStringInfo(LAN_EXECollection_BlazeSet_Legend_Set3)

	PreCreateString_7245		= GetSStringInfo(LAN_EXECollection_BlazeSet_Legend_Set6)

	PreCreateString_7246		= GetSStringInfo(LAN_EXECollection_BlazeSet_Ultimate_Set3)

	PreCreateString_7247		= GetSStringInfo(LAN_EXECollection_BlazeSet_Ultimate_Set6)

	PreCreateString_7248		= GetSStringInfo(LAN_EXECollection_Inventor_Ultimate_Set9)

	PreCreateString_7249		= GetSStringInfo(LAN_EXECollection_DeathScythe_Legend_Set3)

	PreCreateString_7250		= GetSStringInfo(LAN_EXECollection_HalloweenSet1_Rare_Set6)

	PreCreateString_7251		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set6)

	PreCreateString_7252		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7253		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7254		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7255		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7256		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7257		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7258		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7259		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7260		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7261		= GetSStringInfo(LAN_EXECollection_UnicornSet_Legend_Set9)

	PreCreateString_7262		= GetSStringInfo(LAN_TRADE_CHAT_002)
	
-- Start Maxion
	PreCreateString_8000		= GetSStringInfo(LAN_LUA_RANKING_INVITE)